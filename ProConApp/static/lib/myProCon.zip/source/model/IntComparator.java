/*    */ package source.model;
/*    */ 
/*    */ public class IntComparator
/*    */ {
/*    */   public final int compare(Object pFirst, Object pSecond)
/*    */   {
/*  5 */     double aFirstWeight = ((MutObjNew)pFirst).getMuinf12();
/*  6 */     double aSecondWeight = ((MutObjNew)pSecond).getMuinf12();
/*  7 */     double diff = aFirstWeight - aSecondWeight;
/*  8 */     if (diff > 0.0D)
/*  9 */       return -1;
/* 10 */     if (diff < 0.0D) {
/* 11 */       return 1;
/*    */     }
/* 13 */     return 0;
/*    */   }
/*    */ }
