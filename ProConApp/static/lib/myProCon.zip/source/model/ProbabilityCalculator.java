/*     */ package source.model;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileReader;
/*     */ import java.io.PrintStream;
import java.text.DecimalFormat;
import java.text.NumberFormat;
/*     */ import java.util.ArrayList;

/*     */ import source.view.GroupChooser;

/*     */ import java.io.File;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;

/*     */ public class ProbabilityCalculator
/*     */ {
/* 896 */   public static final char[] RESIDUE = { 'A', 'C', 'D', 'E', 'F', 'G', 'H', 
/* 897 */     'I', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'Y', 
/* 898 */     '-' };
/*     */ 
/* 899 */   public static final String[] FULL_RESIDUE = { "Alanine", "Cysteine", "Aspartic acid", "Glutamic acid", 
/* 900 */     "Phenylalanine", "Glycine", "Histidine", "Isoleucine", 
/* 901 */     "Lysine", "Leucine", "Methionine", "Asparagine", "Proline", "Glutamine", 
/* 902 */     "Arginine", "Serine", "Threonine", "Valine", "Tryptophan", "Tyrosine", "gap" };
/*     */ 
/* 904 */   public static final String[] TRI_RESIDUE = { "ALA", "CYS", "ASP", "GLU", "PHE", "GLY", "HIS", "ILE", "LYS", 
/* 905 */     "LEU", "MET", "ASN", "PRO", "GLN", "ARG", "SER", "THR", "VAL", "TRP", "TYR" };
/*     */ 
/* 908 */   public static final char[] residue = { 'a', 'c', 'd', 'e', 'f', 'g', 'h', 
/* 909 */     'i', 'k', 'l', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'y', 
/* 910 */     '-' };
/*     */ 
/* 912 */   public static final char[] aa_pc = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 
/* 913 */     'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o' };
/*     */   private String fileFASTA;
/*     */   private boolean available;
/*     */   private int sequenceNumber;
/*     */   private int residusNumber;
/* 919 */   private final double log20 = 2.99573D;
/*     */   private RankProbaa[][] rpaa;
/*     */   private double[][] freqaa;
/*     */   private double[][] prob6aa;
/*     */   private double[][] freq6aa;
/*     */   private double[] entropy0;
/*     */   private double[] entropy1;
/*     */   private byte[][] seqTmp;
/*     */   private char[][] seq;
/*     */   private ArrayList<String> nameArray;
/*     */   private int reference;
/*     */   private double gappercent;
/*     */   private double pvalue1;
/*     */   private double pvalue2;
/*     */   private int numberofgroup;
/*     */   private int[] group;
/*     */   private boolean defaultgroup;
/* 943 */   static final char[] locator = { '-', 'C', 'F', 'I', 'L', 'M', 'V', 'W', 
/* 944 */     'Y', 'A', 'T', 'D', 'E', 'G', 'P', 'N', 'Q', 'S', 'H', 'R', 'K' };
/*     */   private String[] groupnames;
/*     */ 
/*     */   public ProbabilityCalculator()
/*     */   {
/*  13 */     this.gappercent = 0.1D;
/*  14 */     this.pvalue1 = 0.01D;
/*  15 */     this.pvalue2 = 0.05D;
/*  16 */     this.reference = 0;
/*  17 */     this.available = true;
/*  18 */     this.defaultgroup = true;
/*  19 */     this.numberofgroup = 6;
/*  20 */     this.group = new int[] { 1, 0, 2, 2, 0, 3, 5, 0, 5, 0, 0, 4, 3, 4, 5, 4, 1, 0, 0, 0, 6 };
/*  21 */     this.groupnames = GroupChooser.physicochemical;
/*     */   }
/*     */ 
/*     */   public ProbabilityCalculator(String file) throws Exception
/*     */   {
/*  26 */     this.gappercent = 0.1D;
/*  27 */     this.pvalue1 = 0.01D;
/*  28 */     this.pvalue2 = 0.05D;
/*  29 */     this.reference = 0;
/*  30 */     this.available = true;
/*  31 */     this.defaultgroup = true;
/*  32 */     this.numberofgroup = 6;
/*  33 */     this.group = new int[] { 1, 0, 2, 2, 0, 3, 5, 0, 5, 0, 0, 4, 3, 4, 5, 4, 1, 0, 0, 0, 6 };
/*  34 */     this.groupnames = GroupChooser.physicochemical;
/*     */ 
/*  36 */     this.fileFASTA = file;
/*  37 */     this.residusNumber = calculateResNumber();
/*  38 */     System.out.println(" residusNumber = " + this.residusNumber);
/*  39 */     if (this.residusNumber <= 0) {
/*  40 */       this.available = false;
/*     */     }
/*  42 */     System.out.println("residusNumber =" + this.residusNumber);
/*     */     try
/*     */     {
/*  45 */       this.rpaa = new RankProbaa[this.residusNumber][21];
/*     */ 
/*  47 */       this.prob6aa = new double[this.residusNumber][7];
/*     */ 
/*  49 */       for (int i = 0; i < this.residusNumber; i++) {
/*  50 */         for (int j = 0; j < 21; j++) {
/*  51 */           this.rpaa[i][j] = new RankProbaa();
/*  52 */           this.rpaa[i][j].setProbaa(0.0D);
/*  53 */           this.rpaa[i][j].setRankaa(RESIDUE[j]);
/*     */         }
/*     */ 
/*  62 */         for (int j = 0; j < 7; j++)
/*  63 */           this.prob6aa[i][j] = 0.0D;
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/*  67 */       this.available = false;
/*  68 */       System.out.println("Exception:  " + e);
/*     */     }
/*     */     try
/*     */     {
/*  72 */       this.sequenceNumber = 0;
/*     */ 
/*  75 */       this.seqTmp = new byte[4000][this.residusNumber];
/*     */ 
/*  83 */       this.nameArray = new ArrayList();
/*     */ 
/*  85 */       int index = 0; int sindex = 0;
/*  86 */       BufferedReader reader = new BufferedReader(
/*  87 */         new FileReader(this.fileFASTA));
/*  88 */       String line = new String();
/*  89 */       this.available = false;
/*  90 */       while ((line = reader.readLine()) != null)
/*     */       {
/*  92 */         while (index < line.length()) {
/*  93 */           char c = line.charAt(index++);
/*  94 */           if (c == '>') {
/*  95 */             this.available = true;
/*  96 */             this.sequenceNumber += 1;
/*  97 */             this.nameArray.add(line);
/*  98 */             sindex = 0;
/*  99 */             break;
/*     */           }
/*     */ 
/* 102 */           this.seqTmp[(this.sequenceNumber - 1)][sindex] = chartobyte(c);
/*     */ 
/* 104 */           switch (bytetochar(chartobyte(c))) {
/*     */           case 'S':
/* 106 */             this.rpaa[sindex][15].add();
/*     */ 
/* 114 */             this.prob6aa[sindex][4] += 1.0D;
/*     */ 
/* 116 */             break;
/*     */           case 'L':
/* 119 */             this.rpaa[sindex][9].add();
/*     */ 
/* 126 */             this.prob6aa[sindex][0] += 1.0D;
/*     */ 
/* 128 */             break;
/*     */           case 'A':
/* 131 */             this.rpaa[sindex][0].add();
/*     */ 
/* 139 */             this.prob6aa[sindex][1] += 1.0D;
/*     */ 
/* 141 */             break;
/*     */           case 'G':
/* 144 */             this.rpaa[sindex][5].add();
/*     */ 
/* 152 */             this.prob6aa[sindex][3] += 1.0D;
/*     */ 
/* 154 */             break;
/*     */           case 'K':
/* 157 */             this.rpaa[sindex][8].add();
/*     */ 
/* 165 */             this.prob6aa[sindex][5] += 1.0D;
/*     */ 
/* 167 */             break;
/*     */           case 'V':
/* 170 */             this.rpaa[sindex][17].add();
/*     */ 
/* 178 */             this.prob6aa[sindex][0] += 1.0D;
/*     */ 
/* 180 */             break;
/*     */           case 'T':
/* 183 */             this.rpaa[sindex][16].add();
/*     */ 
/* 191 */             this.prob6aa[sindex][1] += 1.0D;
/*     */ 
/* 193 */             break;
/*     */           case 'D':
/* 196 */             this.rpaa[sindex][2].add();
/*     */ 
/* 204 */             this.prob6aa[sindex][2] += 1.0D;
/*     */ 
/* 206 */             break;
/*     */           case 'E':
/* 209 */             this.rpaa[sindex][3].add();
/*     */ 
/* 216 */             this.prob6aa[sindex][2] += 1.0D;
/*     */ 
/* 218 */             break;
/*     */           case 'P':
/* 221 */             this.rpaa[sindex][12].add();
/*     */ 
/* 227 */             this.prob6aa[sindex][3] += 1.0D;
/*     */ 
/* 229 */             break;
/*     */           case 'N':
/* 232 */             this.rpaa[sindex][11].add();
/*     */ 
/* 239 */             this.prob6aa[sindex][4] += 1.0D;
/*     */ 
/* 241 */             break;
/*     */           case 'R':
/* 244 */             this.rpaa[sindex][14].add();
/*     */ 
/* 251 */             this.prob6aa[sindex][5] += 1.0D;
/*     */ 
/* 253 */             break;
/*     */           case 'F':
/* 256 */             this.rpaa[sindex][4].add();
/*     */ 
/* 263 */             this.prob6aa[sindex][0] += 1.0D;
/*     */ 
/* 265 */             break;
/*     */           case 'I':
/* 268 */             this.rpaa[sindex][7].add();
/*     */ 
/* 275 */             this.prob6aa[sindex][0] += 1.0D;
/*     */ 
/* 277 */             break;
/*     */           case 'Q':
/* 280 */             this.rpaa[sindex][13].add();
/*     */ 
/* 286 */             this.prob6aa[sindex][4] += 1.0D;
/* 287 */             break;
/*     */           case 'Y':
/* 290 */             this.rpaa[sindex][19].add();
/*     */ 
/* 298 */             this.prob6aa[sindex][0] += 1.0D;
/*     */ 
/* 300 */             break;
/*     */           case 'C':
/* 303 */             this.rpaa[sindex][1].add();
/*     */ 
/* 310 */             this.prob6aa[sindex][0] += 1.0D;
/* 311 */             break;
/*     */           case 'H':
/* 314 */             this.rpaa[sindex][6].add();
/*     */ 
/* 323 */             this.prob6aa[sindex][5] += 1.0D;
/*     */ 
/* 325 */             break;
/*     */           case 'M':
/* 328 */             this.rpaa[sindex][10].add();
/*     */ 
/* 334 */             this.prob6aa[sindex][0] += 1.0D;
/*     */ 
/* 336 */             break;
/*     */           case 'W':
/* 339 */             this.rpaa[sindex][18].add();
/*     */ 
/* 347 */             this.prob6aa[sindex][0] += 1.0D;
/*     */ 
/* 349 */             break;
/*     */           case '-':
/* 352 */             this.rpaa[sindex][20].add();
/*     */ 
/* 356 */             this.prob6aa[sindex][6] += 1.0D;
/* 357 */             break;
/*     */           case '.':
/* 361 */             this.rpaa[sindex][20].add();
/*     */ 
/* 365 */             this.prob6aa[sindex][6] += 1.0D;
/* 366 */             break;
/*     */           case 'X':
/* 369 */             this.rpaa[sindex][20].add();
/*     */ 
/* 373 */             this.prob6aa[sindex][6] += 1.0D;
/* 374 */             break;
/*     */           case '/':
/*     */           case '0':
/*     */           case '1':
/*     */           case '2':
/*     */           case '3':
/*     */           case '4':
/*     */           case '5':
/*     */           case '6':
/*     */           case '7':
/*     */           case '8':
/*     */           case '9':
/*     */           case ':':
/*     */           case ';':
/*     */           case '<':
/*     */           case '=':
/*     */           case '>':
/*     */           case '?':
/*     */           case '@':
/*     */           case 'B':
/*     */           case 'J':
/*     */           case 'O':
/*     */           case 'U':
/*     */           default:
/* 378 */             this.rpaa[sindex][20].add();
/*     */ 
/* 382 */             this.prob6aa[sindex][6] += 1.0D;
/*     */           }
/*     */ 
/* 385 */           sindex++;
/*     */         }
/*     */ 
/* 388 */         index = 0;
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 392 */       this.available = false;
/* 393 */       System.out.println("virhe " + e);
/*     */     }
/*     */ 
/* 399 */     calculateEntropy();
/*     */ 
/* 401 */     this.freqaa = new double[this.residusNumber][21];
/* 402 */     for (int i = 0; i < this.residusNumber; i++) {
/* 403 */       for (int j = 0; j < 21; j++) {
/* 404 */         this.freqaa[i][j] = this.rpaa[i][j].getProbaa();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 409 */     this.freq6aa = new double[this.residusNumber][7];
/* 410 */     for (int i = 0; i < this.residusNumber; i++) {
/* 411 */       for (int j = 0; j < 7; j++) {
/* 412 */         this.freq6aa[i][j] = (this.prob6aa[i][j] / this.sequenceNumber);
/*     */       }
/*     */     }
/*     */ 
/* 416 */     this.seq = new char[this.sequenceNumber][this.residusNumber];
/* 417 */     for (int i = 0; i < this.sequenceNumber; i++)
/* 418 */       for (int j = 0; j < this.residusNumber; j++)
/* 419 */         this.seq[i][j] = bytetochar(this.seqTmp[i][j]);
/*     */   }
/*     */ 
/*     */   public char[][] getSeq()
/*     */   {
/* 437 */     return this.seq;
/*     */   }
/*     */ 
/*     */   public ArrayList<String> getSeqNames()
/*     */   {
/* 446 */     return this.nameArray;
/*     */   }
/*     */ 
/*     */   public void displaySeq() {
/* 450 */     for (int i = 0; i < this.sequenceNumber; i++) {
/* 451 */       System.out.println("\nsequence" + i + ":");
/* 452 */       for (int j = 0; j < this.residusNumber; j++)
/* 453 */         System.out.print(this.seq[i][j]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public char[] getRepseq()
/*     */   {
/* 463 */     char[] Repseq = new char[this.residusNumber];
/* 464 */     for (int i = 0; i < this.residusNumber; i++)
/* 465 */       Repseq[i] = this.seq[0][i];
/* 466 */     return Repseq;
/*     */   }
/*     */ 
/*     */   private int calculateResNumber()
/*     */   {
/*     */     try
/*     */     {
/* 477 */       if (this.fileFASTA != null) {
/* 478 */         BufferedReader reader = new BufferedReader(new FileReader(
/* 479 */           this.fileFASTA));
/*     */ 
/* 481 */         String line = new String();
/* 482 */         int line_index = 0;
/* 483 */         int residue_index = 0;
/*     */ 
/* 485 */         while ((line = reader.readLine()) != null)
/*     */         {
/* 488 */           while (line_index < line.length())
/*     */           {
/* 490 */             char c = line.charAt(line_index++);
/* 491 */             if (c == '>') {
/* 492 */               this.sequenceNumber += 1;
/* 493 */               if ((this.sequenceNumber > 0) && 
/* 494 */                 (residue_index > 0))
/*     */               {
/* 496 */                 return residue_index;
/*     */               }
/* 498 */               residue_index = 0;
/* 499 */               break;
/*     */             }
/*     */ 
/* 502 */             residue_index++;
/*     */           }
/*     */ 
/* 505 */           line_index = 0;
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 511 */       System.out
/* 512 */         .println("calculate Number of Residues in each sequence exception: " + 
/* 513 */         e);
/*     */     }
/*     */ 
/* 516 */     return 0;
/*     */   }
/*     */ 
/*     */   public void calculateEntropy() {
/* 520 */     this.entropy0 = new double[this.residusNumber];
/* 521 */     this.entropy1 = new double[this.residusNumber];
/*     */ 
/* 523 */     for (int i = 0; i < this.residusNumber; i++) {
/* 524 */       this.entropy0[i] = 2.99573D;
/* 525 */       this.entropy1[i] = 2.99573D;
/* 526 */       for (int j = 0; j < 21; j++) {
/* 527 */         if ((this.rpaa[i][j].getProbaa() > 0.0D) && (j != 20)) {
/* 528 */           this.entropy0[i] += entropyCalc(this.rpaa[i][j].getProbaa(), 
/* 529 */             this.sequenceNumber, this.rpaa[i][20].getProbaa());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 534 */       for (int j = 0; j < 6; j++)
/* 535 */         if (this.prob6aa[i][j] > 0.0D)
/* 536 */           this.entropy1[i] += simpilifiedEntropyCalc(this.prob6aa[i][j], 
/* 537 */             this.sequenceNumber, this.prob6aa[i][6], 6);
/*     */     }
/*     */   }
/*     */ 
/*     */   private double entropyCalc(double probaa, double seqnumber, double probaa20)
/*     */   {
/* 549 */     double tmp = 0.0D;
/* 550 */     double retval = 0.0D;
/* 551 */     tmp = probaa / (seqnumber - probaa20);
/* 552 */     retval = tmp * Math.log(tmp);
/* 553 */     return retval;
/*     */   }
/*     */ 
/*     */   private double simpilifiedEntropyCalc(double prob6aa, double seqnumber, double prob6aa6, int numberofgroup)
/*     */   {
/* 558 */     double tmp = 0.0D;
/* 559 */     double retval = 0.0D;
/* 560 */     tmp = prob6aa / (seqnumber - prob6aa6);
/* 561 */     retval = Math.log(20.0D) / Math.log(numberofgroup) * tmp * Math.log(tmp);
/* 562 */     return retval;
/*     */   }
/*     */ 
/*     */   public void reCalculate()
/*     */   {
/* 595 */     this.prob6aa = new double[this.residusNumber][this.numberofgroup + 1];
/*     */ 
/* 597 */     for (int i = 0; i < this.residusNumber; i++)
/*     */     {
/* 599 */       for (int j = 0; j <= this.numberofgroup; j++) {
/* 600 */         this.prob6aa[i][j] = 0.0D;
/*     */       }
/*     */     }
/*     */ 
/* 604 */     for (int k = 0; k < this.residusNumber; k++) {
/* 605 */       for (int i = 0; i < 21; i++) {
/* 606 */         for (int j = 0; j <= this.numberofgroup; j++) {
/* 607 */           if (this.group[i] == j) {
/* 608 */             this.prob6aa[k][j] += this.rpaa[k][i].getProbaa();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 614 */     this.entropy1 = new double[this.residusNumber];
/*     */ 
/* 616 */     for (int i = 0; i < this.residusNumber; i++) {
/* 617 */       this.entropy1[i] = 2.99573D;
/*     */ 
/* 619 */       for (int j = 0; j < this.numberofgroup; j++)
/*     */       {
/* 622 */         if (this.prob6aa[i][j] > 0.0D) {
/* 623 */           this.entropy1[i] += simpilifiedEntropyCalc(this.prob6aa[i][j], 
/* 624 */             this.sequenceNumber, this.prob6aa[i][this.numberofgroup], this.numberofgroup);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 631 */     this.freq6aa = new double[this.residusNumber][this.numberofgroup + 1];
/* 632 */     for (int i = 0; i < this.residusNumber; i++)
/* 633 */       for (int j = 0; j < this.numberofgroup + 1; j++)
/* 634 */         this.freq6aa[i][j] = (this.prob6aa[i][j] / this.sequenceNumber);
/*     */   }
/*     */ 
/*     */   public int getSeqNumber()
/*     */   {
/* 646 */     return this.sequenceNumber;
/*     */   }
/*     */ 
/*     */   public int getResNumber() {
/* 650 */     return this.residusNumber;
/*     */   }
/*     */ 
/*     */   public RankProbaa[][] getProbaa() {
/* 654 */     return this.rpaa;
/*     */   }
/*     */ 
/*     */   public double[][] getFreqaa() {
/* 658 */     return this.freqaa;
/*     */   }
/*     */ 
/*     */   public double[][] getFreq6aa() {
/* 662 */     return this.freq6aa;
/*     */   }
/*     */ 
/*     */   public double[][] getProb6aa()
/*     */   {
/* 667 */     return this.prob6aa;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/*     */     try {
/* 672 */       ProbabilityCalculator pc = new ProbabilityCalculator("D:/2015-8/data/HSAN/70995319.unaligned.aligned");
/*     */ 
/* 674 */       String s = pc.getReferenceSequence();
/* 675 */       System.out.println(s);






	File writename = new File("D:/2015-8/data/HSAN/70995319.information"); // ���·�������û����Ҫ����һ���µ�output��txt�ļ�
writename.createNewFile(); // �������ļ�
BufferedWriter out = new BufferedWriter(new FileWriter(writename));

double[] information = pc.getEntropy0();
double[] information2 = pc.getEntropy1();

for(int i=0;i<information.length;i++){
	int residue =i+1;
	
	NumberFormat formater = DecimalFormat.getInstance();
		formater.setMaximumFractionDigits(3);
			String rt = formater.format(information[i]);
			String rt2 = formater.format(information2[i]);
out.write(residue+" "+rt+" "+rt2+"\n"); // \r\n��Ϊ����
}
out.flush(); // �ѻ���������ѹ���ļ�
out.close(); // ���ǵùر��ļ�









                 
/*     */     }
/*     */     catch (Exception e)
/*     */     {e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public double[] getEntropy0()
/*     */   {
/* 694 */     return this.entropy0;
/*     */   }
/*     */ 
/*     */   public double[] getEntropy1() {
/* 698 */     return this.entropy1;
/*     */   }
/*     */ 
/*     */   public void setReference(int reference) {
/* 702 */     this.reference = reference;
/*     */   }
/*     */ 
/*     */   public int getReference() {
/* 706 */     return this.reference;
/*     */   }
/*     */ 
/*     */   public String getReferenceSequence() {
/* 710 */     String referenceString = new String();
/* 711 */     char[][] sequence = getSeq();
/* 712 */     char[] sequenceline = sequence[this.reference];
/* 713 */     for (char c : sequenceline)
/* 714 */       if (c != '-') referenceString = referenceString + Character.toString(c);
/* 715 */     return referenceString;
/*     */   }
/*     */ 
/*     */   public String calculateSite(int site)
/*     */   {
/* 720 */     String siteString = new String();
/* 721 */     if (getSeqNames() != null) {
/* 722 */       String SequenceName = (String)getSeqNames().get(this.reference);
/*     */ 
/* 725 */       int start = SequenceName.indexOf("/");
/* 726 */       int end = SequenceName.indexOf("-");
/*     */ 
/* 733 */       int StartSite = 1;
/* 734 */       if (end > start) StartSite = Integer.parseInt(SequenceName.substring(start + 1, 
/* 735 */           end));
/*     */ 
/* 737 */       char[][] sequence = getSeq();
/* 738 */       char[] sequenceline = sequence[this.reference];
/* 739 */       int actualsite = StartSite;
/*     */ 
/* 743 */       for (int i = 0; i < site; i++) {
/* 744 */         if (sequenceline[i] != '-') {
/* 745 */           actualsite++;
/*     */         }
/*     */       }
/* 748 */       siteString = Integer.toString(actualsite) + 
/* 749 */         Character.toString(sequenceline[site]);
/*     */     }
/* 751 */     return siteString;
/*     */   }
/*     */ 
/*     */   public int getReferenceStart() {
/* 755 */     int startSite = 0;
/*     */ 
/* 757 */     if (getSeqNames() != null) {
/* 758 */       String SequenceName = (String)getSeqNames().get(this.reference);
/*     */ 
/* 761 */       int start = SequenceName.indexOf("/");
/* 762 */       int end = SequenceName.indexOf("-");
/*     */ 
/* 769 */       startSite = Integer.parseInt(SequenceName.substring(start + 1, 
/* 770 */         end));
/*     */     }
/* 772 */     return startSite;
/*     */   }
/*     */ 
/*     */   public String getActualSite(int site)
/*     */   {
/* 777 */     String siteString = new String();
/* 778 */     if (getSeqNames() != null) {
/* 779 */       String SequenceName = (String)getSeqNames().get(this.reference);
/*     */ 
/* 782 */       int start = SequenceName.indexOf("/");
/* 783 */       int end = SequenceName.indexOf("-");
/*     */ 
/* 790 */       int StartSite = Integer.parseInt(SequenceName.substring(start + 1, 
/* 791 */         end));
/*     */ 
/* 793 */       char[][] sequence = getSeq();
/* 794 */       char[] sequenceline = sequence[this.reference];
/* 795 */       int actualsite = StartSite;
/* 796 */       for (int i = 0; i < site; i++) {
/* 797 */         if (sequenceline[i] != '-') {
/* 798 */           actualsite++;
/*     */         }
/*     */       }
/* 801 */       siteString = Integer.toString(actualsite);
/*     */     }
/* 803 */     return siteString;
/*     */   }
/*     */ 
/*     */   public void setGapPercent(double p) {
/* 807 */     this.gappercent = p;
/*     */   }
/*     */ 
/*     */   public double getGapPercent() {
/* 811 */     return this.gappercent;
/*     */   }
/*     */ 
/*     */   public void setPValue1(double p1) {
/* 815 */     this.pvalue1 = p1;
/*     */   }
/*     */ 
/*     */   public double getPValue1() {
/* 819 */     return this.pvalue1;
/*     */   }
/*     */ 
/*     */   public void setPValue2(double p2) {
/* 823 */     this.pvalue2 = p2;
/*     */   }
/*     */ 
/*     */   public double getPValue2() {
/* 827 */     return this.pvalue2;
/*     */   }
/*     */ 
/*     */   public boolean getAvailable() {
/* 831 */     return this.available;
/*     */   }
/*     */ 
/*     */   public int[] getGroup() {
/* 835 */     return this.group;
/*     */   }
/*     */ 
/*     */   public void setGroup(int[] group) {
/* 839 */     this.group = group;
/*     */   }
/*     */ 
/*     */   public boolean getDefault() {
/* 843 */     return this.defaultgroup;
/*     */   }
/*     */ 
/*     */   public void setDefault(boolean defaultgroup) {
/* 847 */     this.defaultgroup = defaultgroup;
/*     */   }
/*     */ 
/*     */   public void setDefaultGroup() {
/* 851 */     this.numberofgroup = 6;
/* 852 */     this.group = new int[] { 1, 0, 2, 2, 0, 3, 5, 0, 5, 0, 0, 4, 3, 4, 5, 4, 1, 0, 0, 0, 6 };
/*     */   }
/*     */ 
/*     */   public int getNumberofgroup() {
/* 856 */     return this.numberofgroup;
/*     */   }
/*     */ 
/*     */   public void setNumberofgroup(int number) {
/* 860 */     this.numberofgroup = number;
/*     */   }
/*     */ 
/*     */   public String[] getGroupNames() {
/* 864 */     return this.groupnames;
/*     */   }
/*     */ 
/*     */   public void setGroupNames(String[] groupnames) {
/* 868 */     this.groupnames = groupnames;
/*     */   }
/*     */ 
/*     */   private byte chartobyte(char c)
/*     */   {
/* 875 */     byte b = -1;
/* 876 */     for (int i = 0; i < RESIDUE.length; i++) {
/* 877 */       if ((c == RESIDUE[i]) || (c == residue[i])) b = (byte)i;
/*     */ 
/*     */     }
/*     */ 
/* 881 */     if (c == '.') b = 20;
/*     */ 
/* 883 */     return b;
/*     */   }
/*     */ 
/*     */   private char bytetochar(byte b)
/*     */   {
/* 888 */     if ((b >= 0) && (b < RESIDUE.length))
/* 889 */       return RESIDUE[b];
/* 890 */     return '-';
/*     */   }
/*     */ }

