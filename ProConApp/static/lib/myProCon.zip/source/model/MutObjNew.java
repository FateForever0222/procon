/*    */ package source.model;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class MutObjNew
/*    */ {
/*    */   private ArrayList muinf;
/*    */   private double muinf12;
/*    */   private int site1;
/*    */   private int site2;
/*    */ 
/*    */   public MutObjNew()
/*    */   {
/*  7 */     this.muinf = new ArrayList();
/*    */   }
/*    */ 
/*    */   public void setMuinf12(double muinf12) {
/* 11 */     this.muinf12 = muinf12;
/*    */   }
/*    */ 
/*    */   public void setSite1(int site1) {
/* 15 */     this.site1 = site1;
/*    */   }
/*    */ 
/*    */   public void setSite2(int site2) {
/* 19 */     this.site2 = site2;
/*    */   }
/*    */ 
/*    */   public void setMuinf(ArrayList muinf) {
/* 23 */     this.muinf = muinf;
/*    */   }
/*    */ 
/*    */   public void iniMuinf() {
/* 27 */     this.muinf = new ArrayList();
/*    */   }
/*    */ 
/*    */   public void setMuinf(int i, int j, float value) {
/* 31 */     MutInfo mutinfo = new MutInfo(i, j, value);
/* 32 */     this.muinf.add(mutinfo);
/*    */   }
/*    */ 
/*    */   public double getMuinf12() {
/* 36 */     return this.muinf12;
/*    */   }
/*    */ 
/*    */   public int getSite1() {
/* 40 */     return this.site1;
/*    */   }
/*    */ 
/*    */   public int getSite2() {
/* 44 */     return this.site2;
/*    */   }
/*    */ 
/*    */   public ArrayList getMuinf() {
/* 48 */     return this.muinf;
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.model.MutObjNew
 * JD-Core Version:    0.6.2
 */