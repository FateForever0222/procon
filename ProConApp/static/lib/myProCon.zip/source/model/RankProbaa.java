/*    */ package source.model;
/*    */ 
/*    */ public class RankProbaa
/*    */ {
/*    */   private double probaa;
/*    */   private char rankaa;
/*    */ 
/*    */   public void setProbaa(double probaa)
/*    */   {
/*  6 */     this.probaa = probaa;
/*    */   }
/*    */ 
/*    */   public void calProbaa(int seqNumber) {
/* 10 */     this.probaa /= seqNumber;
/*    */   }
/*    */ 
/*    */   public double getProbaa()
/*    */   {
/* 15 */     return this.probaa;
/*    */   }
/*    */ 
/*    */   public void setRankaa(char rankaa) {
/* 19 */     this.rankaa = rankaa;
/*    */   }
/*    */ 
/*    */   public char getRankaa() {
/* 23 */     return this.rankaa;
/*    */   }
/*    */ 
/*    */   public void add() {
/* 27 */     this.probaa += 1.0D;
/*    */   }
/*    */ }

