/*     */ package source.model;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ import org.biojava.bio.structure.Structure;
/*     */ import org.biojava.bio.structure.io.PDBFileReader;
/*     */ import org.jmol.adapter.smarter.SmarterJmolAdapter;
/*     */ import org.jmol.api.JmolAdapter;
/*     */ import org.jmol.api.JmolSimpleViewer;
/*     */ 
/*     */ public class SimpleJmolExample
/*     */ {
/*     */   JmolSimpleViewer viewer;
/*     */   Structure structure;
/*     */   JmolPanel jmolPanel;
/*     */   JFrame frame;
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/*  27 */       PDBFileReader pdbr = new PDBFileReader();
/*  28 */       pdbr.setPath("D:/");
/*     */ 
/*  30 */       String pdbCode = "2WOZ";
/*     */ 
/*  32 */       Structure struc = pdbr.getStructureById(pdbCode);
/*     */ 
/*  34 */       SimpleJmolExample ex = new SimpleJmolExample();
/*  35 */       ex.setStructure(struc);
/*     */     }
/*     */     catch (Exception e) {
/*  38 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public SimpleJmolExample() {
/*  43 */     this.frame = new JFrame();
/*  44 */     this.frame.addWindowListener(new ApplicationCloser());
/*  45 */     Container contentPane = this.frame.getContentPane();
/*  46 */     this.jmolPanel = new JmolPanel();
/*     */ 
/*  48 */     this.jmolPanel.setPreferredSize(new Dimension(200, 200));
/*  49 */     contentPane.add(this.jmolPanel);
/*     */ 
/*  51 */     this.frame.pack();
/*  52 */     this.frame.setVisible(true);
/*     */   }
/*     */ 
/*     */   public void setStructure(Structure s)
/*     */   {
/*  58 */     this.frame.setName(s.getPDBCode());
/*     */ 
/*  63 */     String pdb = s.toPDB();
/*     */ 
/*  65 */     this.structure = s;
/*  66 */     JmolSimpleViewer viewer = this.jmolPanel.getViewer();
/*     */ 
/*  75 */     viewer.openStringInline(pdb);
/*  76 */     viewer
/*  77 */       .evalString("select *; spacefill off; wireframe off; backbone 0.4;  ");
/*  78 */     viewer.evalString("color chain;  ");
/*  79 */     this.viewer = viewer;
/*     */   }
/*     */ 
/*     */   public void setTitle(String label)
/*     */   {
/*  84 */     this.frame.setTitle(label);
/*     */   }
/*     */ 
/*     */   public JmolSimpleViewer getViewer()
/*     */   {
/*  89 */     return this.jmolPanel.getViewer();
/*     */   }
/*     */ 
/*     */   static class ApplicationCloser extends WindowAdapter {
/*     */     public void windowClosing(WindowEvent e) {
/*  94 */       System.exit(0);
/*     */     }
/*     */   }
/*     */ 
/*     */   static class JmolPanel extends JPanel
/*     */   {
/*     */     private static final long serialVersionUID = -3661941083797644242L;
/*     */     JmolSimpleViewer viewer;
/*     */     JmolAdapter adapter;
/* 120 */     final Dimension currentSize = new Dimension();
/* 121 */     final Rectangle rectClip = new Rectangle();
/*     */ 
/*     */     JmolPanel()
/*     */     {
/* 107 */       this.adapter = new SmarterJmolAdapter();
/* 108 */       this.viewer = JmolSimpleViewer.allocateSimpleViewer(this, this.adapter);
/*     */     }
/*     */ 
/*     */     public JmolSimpleViewer getViewer()
/*     */     {
/* 113 */       return this.viewer;
/*     */     }
/*     */ 
/*     */     public void executeCmd(String rasmolScript) {
/* 117 */       this.viewer.evalString(rasmolScript);
/*     */     }
/*     */ 
/*     */     public void paint(Graphics g)
/*     */     {
/* 124 */       getSize(this.currentSize);
/* 125 */       g.getClipBounds(this.rectClip);
/* 126 */       this.viewer.renderScreenImage(g, this.currentSize, this.rectClip);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.model.SimpleJmolExample
 * JD-Core Version:    0.6.2
 */