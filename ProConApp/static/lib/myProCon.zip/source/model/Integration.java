/*    */ package source.model;
/*    */ 
/*    */ import java.awt.Container;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Rectangle;
/*    */ import java.awt.event.WindowAdapter;
/*    */ import java.awt.event.WindowEvent;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JPanel;
/*    */ import org.jmol.adapter.smarter.SmarterJmolAdapter;
/*    */ import org.jmol.api.JmolAdapter;
/*    */ import org.jmol.api.JmolSimpleViewer;
/*    */ import org.jmol.util.Logger;
/*    */ 
/*    */ public class Integration
/*    */ {
/*    */   static final String strXyzHOH = "3\nwater\nO  0.0 0.0 0.0\nH  0.76923955 -0.59357141 0.0\nH -0.76923955 -0.59357141 0.0\n";
/*    */   static final String strScript = "delay; move 360 0 0 0 0 0 0 0 4;";
/*    */ 
/*    */   public static void main(String[] argv)
/*    */   {
/* 35 */     JFrame frame = new JFrame("Hello");
/* 36 */     frame.addWindowListener(new ApplicationCloser());
/* 37 */     Container contentPane = frame.getContentPane();
/* 38 */     JmolPanel jmolPanel = new JmolPanel();
/* 39 */     contentPane.add(jmolPanel);
/* 40 */     frame.setSize(300, 300);
/* 41 */     frame.setVisible(true);
/*    */ 
/* 43 */     JmolSimpleViewer viewer = jmolPanel.getViewer();
/*    */ 
/* 49 */     String strError = viewer.openFile("d:/5pti.pdb");
/*    */ 
/* 51 */     viewer.openStringInline("3\nwater\nO  0.0 0.0 0.0\nH  0.76923955 -0.59357141 0.0\nH -0.76923955 -0.59357141 0.0\n");
/*    */ 
/* 53 */     if (strError == null)
/* 54 */       viewer.evalString("delay; move 360 0 0 0 0 0 0 0 4;");
/*    */     else
/* 56 */       Logger.error(strError);
/*    */   }
/*    */ 
/*    */   static class ApplicationCloser extends WindowAdapter
/*    */   {
/*    */     public void windowClosing(WindowEvent e)
/*    */     {
/* 67 */       System.exit(0);
/*    */     }
/*    */   }
/*    */ 
/*    */   static class JmolPanel extends JPanel
/*    */   {
/*    */     JmolSimpleViewer viewer;
/*    */     JmolAdapter adapter;
/* 84 */     final Dimension currentSize = new Dimension();
/* 85 */     final Rectangle rectClip = new Rectangle();
/*    */ 
/*    */     JmolPanel()
/*    */     {
/* 76 */       this.adapter = new SmarterJmolAdapter();
/* 77 */       this.viewer = JmolSimpleViewer.allocateSimpleViewer(this, this.adapter);
/*    */     }
/*    */ 
/*    */     public JmolSimpleViewer getViewer() {
/* 81 */       return this.viewer;
/*    */     }
/*    */ 
/*    */     public void paint(Graphics g)
/*    */     {
/* 88 */       getSize(this.currentSize);
/* 89 */       g.getClipBounds(this.rectClip);
/* 90 */       this.viewer.renderScreenImage(g, this.currentSize, this.rectClip);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.model.Integration
 * JD-Core Version:    0.6.2
 */