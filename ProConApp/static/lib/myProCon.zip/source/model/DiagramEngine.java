/*     */ package source.model;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Writer;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import source.view.TripletListPanel;
/*     */ 
/*     */ public class DiagramEngine
/*     */ {
/*     */   private TripletListPanel listpanel;
/*     */   private ArrayList<MyLink> linklist;
/*     */   private ArrayList<MyLink> mulinklistP1;
/*     */   private ArrayList<MyLink> mulinklistP2;
/*     */   private ArrayList<MyNode> nodelist;
/*     */   private ArrayList<MyNode> munodelistP1;
/*     */   private ArrayList<MyNode> munodelistP2;
/*     */   private OutputStream outputStream;
/*     */ 
/*     */   public DiagramEngine(TripletListPanel listpanel)
/*     */   {
/*  11 */     this.listpanel = listpanel;
/*     */   }
/*     */ 
/*     */   public void calculateTripletNodes()
/*     */   {
/*  21 */     ArrayList displaylist = this.listpanel.getDisplayList();
/*     */ 
/*  23 */     MutualInformation mi = this.listpanel.getMutualInformation();
/*  24 */     this.nodelist = new ArrayList();
/*  25 */     this.linklist = new ArrayList();
/*     */ 
/*  27 */     boolean flag1 = false;
/*  28 */     boolean flag2 = false;
/*  29 */     boolean flag3 = false;
/*     */ 
/*  31 */     for (int i = 0; i < displaylist.size(); i++) {
/*  32 */       Triplet tp = (Triplet)displaylist.get(i);
/*     */ 
/*  34 */       flag1 = false;
/*  35 */       flag2 = false;
/*  36 */       flag3 = false;
/*     */ 
/*  38 */       MyNode node1 = new MyNode(tp.getS1());
/*  39 */       MyNode node2 = new MyNode(tp.getS2());
/*  40 */       MyNode node3 = new MyNode(tp.getS3());
/*     */       MyNode node;
/*  42 */       if (this.nodelist.size() != 0) {
/*  43 */         for (int j = 0; j < this.nodelist.size(); j++)
/*     */         {
/*  45 */           node = (MyNode)this.nodelist.get(j);
/*  46 */           if (node.getSite() == tp.getS1()) {
/*  47 */             flag1 = true;
/*  48 */             node1 = node;
/*  49 */           } else if (node.getSite() == tp.getS2()) {
/*  50 */             flag2 = true;
/*  51 */             node2 = node;
/*  52 */           } else if (node.getSite() == tp.getS3()) {
/*  53 */             flag3 = true;
/*  54 */             node3 = node;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  59 */       if (!flag1)
/*     */       {
/*  61 */         this.nodelist.add(node1);
/*     */       }
/*  63 */       if (!flag2)
/*     */       {
/*  65 */         this.nodelist.add(node2);
/*     */       }
/*  67 */       if (!flag3)
/*     */       {
/*  69 */         this.nodelist.add(node3);
/*     */       }
/*     */ 
/*  72 */       flag1 = false;
/*  73 */       flag2 = false;
/*  74 */       flag3 = false;
/*     */ 
/*  76 */       for (MyLink link : this.linklist) {
/*  77 */         if (((node1.getSite() == link.getNode1().getSite()) && 
/*  78 */           (node2
/*  78 */           .getSite() == link.getNode2().getSite())) || (
/*  79 */           (node1.getSite() == link.getNode2().getSite()) && 
/*  80 */           (node2
/*  80 */           .getSite() == link.getNode1().getSite()))) {
/*  81 */           flag1 = true;
/*     */         }
/*  83 */         if (((node1.getSite() == link.getNode1().getSite()) && 
/*  84 */           (node3
/*  84 */           .getSite() == link.getNode2().getSite())) || (
/*  85 */           (node1.getSite() == link.getNode2().getSite()) && 
/*  86 */           (node3
/*  86 */           .getSite() == link.getNode1().getSite()))) {
/*  87 */           flag2 = true;
/*     */         }
/*  89 */         if (((node2.getSite() == link.getNode1().getSite()) && 
/*  90 */           (node3
/*  90 */           .getSite() == link.getNode2().getSite())) || (
/*  91 */           (node2.getSite() == link.getNode2().getSite()) && 
/*  92 */           (node3
/*  92 */           .getSite() == link.getNode1().getSite()))) {
/*  93 */           flag3 = true;
/*     */         }
/*     */       }
/*  96 */       if (!flag1) {
/*  97 */         MyLink link1 = new MyLink(node1, node2);
/*  98 */         this.linklist.add(link1);
/*     */       }
/*     */ 
/* 101 */       if (!flag2) {
/* 102 */         MyLink link2 = new MyLink(node1, node3);
/* 103 */         this.linklist.add(link2);
/*     */       }
/* 105 */       if (!flag3) {
/* 106 */         MyLink link3 = new MyLink(node2, node3);
/* 107 */         this.linklist.add(link3);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void calculateMuNodes()
/*     */   {
/* 117 */     MutualInformation mi = this.listpanel.getMutualInformation();
/*     */ 
/* 119 */     this.munodelistP1 = new ArrayList();
/* 120 */     this.mulinklistP1 = new ArrayList();
/*     */ 
/* 122 */     this.munodelistP2 = new ArrayList();
/* 123 */     this.mulinklistP2 = new ArrayList();
/*     */ 
/* 125 */     boolean flag1 = false;
/* 126 */     boolean flag2 = false;
/*     */ 
/* 128 */     if (mi != null)
/*     */     {
/* 131 */       ArrayList mutlistP1 = mi.getListP1();
/* 132 */       ArrayList mutlistP2 = mi.getListP2();
/*     */ 
/* 134 */       for (int i = 0; i < mutlistP1.size(); i++) {
/* 135 */         MyNode node1 = new MyNode();
/* 136 */         MyNode node2 = new MyNode();
/*     */ 
/* 138 */         flag1 = false;
/* 139 */         flag2 = false;
/*     */ 
/* 141 */         for (int j = 0; j < this.munodelistP1.size(); j++) {
/* 142 */           MyNode nodej = (MyNode)this.munodelistP1.get(j);
/* 143 */           if (nodej.getSite() == ((MutObjNew)mutlistP1.get(i)).getSite1()) {
/* 144 */             node1 = nodej;
/* 145 */             flag1 = true;
/*     */           }
/*     */ 
/* 148 */           if (nodej.getSite() == ((MutObjNew)mutlistP1.get(i)).getSite2()) {
/* 149 */             node2 = nodej;
/* 150 */             flag2 = true;
/*     */           }
/*     */         }
/*     */ 
/* 154 */         if (!flag1) {
/* 155 */           node1 = new MyNode(((MutObjNew)mutlistP1.get(i)).getSite1());
/* 156 */           this.munodelistP1.add(node1);
/*     */         }
/*     */ 
/* 159 */         if (!flag2) {
/* 160 */           node2 = new MyNode(((MutObjNew)mutlistP1.get(i)).getSite2());
/* 161 */           this.munodelistP1.add(node2);
/*     */         }
/*     */ 
/* 164 */         MyLink link = new MyLink(node1, node2, ((MutObjNew)mutlistP1.get(i)).getMuinf12());
/* 165 */         this.mulinklistP1.add(link);
/*     */       }
/*     */ 
/* 168 */       System.out.println("munodelistP1.size = " + this.munodelistP1.size());
/*     */ 
/* 170 */       for (int i = 0; i < mutlistP2.size(); i++) {
/* 171 */         MyNode node1 = new MyNode();
/* 172 */         MyNode node2 = new MyNode();
/*     */ 
/* 174 */         flag1 = false;
/* 175 */         flag2 = false;
/*     */ 
/* 177 */         for (int j = 0; j < this.munodelistP2.size(); j++) {
/* 178 */           MyNode nodej = (MyNode)this.munodelistP2.get(j);
/* 179 */           if (nodej.getSite() == ((MutObjNew)mutlistP2.get(i)).getSite1()) {
/* 180 */             node1 = nodej;
/* 181 */             flag1 = true;
/*     */           }
/*     */ 
/* 184 */           if (nodej.getSite() == ((MutObjNew)mutlistP2.get(i)).getSite2()) {
/* 185 */             node2 = nodej;
/* 186 */             flag2 = true;
/*     */           }
/*     */         }
/*     */ 
/* 190 */         if (!flag1) {
/* 191 */           node1 = new MyNode(((MutObjNew)mutlistP2.get(i)).getSite1());
/* 192 */           this.munodelistP2.add(node1);
/*     */         }
/*     */ 
/* 195 */         if (!flag2) {
/* 196 */           node2 = new MyNode(((MutObjNew)mutlistP2.get(i)).getSite2());
/* 197 */           this.munodelistP2.add(node2);
/*     */         }
/*     */ 
/* 200 */         MyLink link = new MyLink(node1, node2, ((MutObjNew)mutlistP2.get(i)).getMuinf12());
/* 201 */         this.mulinklistP2.add(link);
/*     */       }
/*     */ 
/* 204 */       System.out.println("munodelistP2.size = " + this.munodelistP2.size());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void generateDiagram() throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 212 */       ProbabilityCalculator pc = this.listpanel.getPc();
/* 213 */       File directory = new File("..");
/*     */ 
/* 215 */       if (System.getProperty("os.name").substring(0, 7).equals("Windows")) {
/* 216 */         this.outputStream = new FileOutputStream(directory
/* 217 */           .getCanonicalPath() + 
/* 218 */           "\\output\\Triplets.dot");
/*     */       }
/*     */       else {
/* 221 */         this.outputStream = new FileOutputStream(directory
/* 222 */           .getCanonicalPath() + 
/* 223 */           "/output/Triplets.dot");
/*     */       }
/* 225 */       Writer writer = new OutputStreamWriter(this.outputStream, "utf-8");
/* 226 */       String cLineStr = "graph G {\r\n";
/* 227 */       cLineStr = cLineStr + " node [fontsize = 11, height = .02]\r\n";
/* 228 */       cLineStr = cLineStr + " edge [fontsize = 9, color = red]\r\n";
/*     */ 
/* 230 */       if ((this.linklist.size() != 0) && (this.linklist.size() < 100)) {
/* 231 */         for (MyLink link : this.linklist) {
/* 232 */           MyNode node1 = link.getNode1();
/* 233 */           MyNode node2 = link.getNode2();
/* 234 */           cLineStr = cLineStr + "\"" + pc.calculateSite(node1.getSite()) + "\"" + 
/* 235 */             " -- " + "\"" + pc.calculateSite(node2.getSite()) + 
/* 236 */             "\"" + ";\r\n";
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 250 */       cLineStr = cLineStr + "}";
/* 251 */       writer.write(cLineStr);
/* 252 */       writer.close();
/*     */ 
/* 254 */       if (System.getProperty("os.name").substring(0, 7).equals("Windows")) {
/* 255 */         String cLine = " \"" + directory.getCanonicalPath() + 
/* 256 */           "\\bin\\Graphviz2.24\\bin\\dot.exe\" -Tpng -o " + "\"" + 
/* 257 */           directory.getCanonicalPath() + 
/* 258 */           "\\output\\Triplets.png\" -Kdot " + "\"" + 
/* 259 */           directory.getCanonicalPath() + "\\output\\Triplets.dot\"";
/*     */ 
/* 261 */         System.out.println("cmd /c " + cLine);
/* 262 */         Process p = Runtime.getRuntime().exec(cLine);
/* 263 */         p.waitFor();
/* 264 */         p.destroy();
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 270 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void generateMuDiagram() throws Exception {
/*     */     try {
/* 276 */       ProbabilityCalculator pc = this.listpanel.getPc();
/* 277 */       File directory = new File("..");
/*     */ 
/* 282 */       if (System.getProperty("os.name").substring(0, 7).equals("Windows")) {
/* 283 */         this.outputStream = new FileOutputStream(directory
/* 284 */           .getCanonicalPath() + 
/* 285 */           "\\output\\pairs(P value smaller than P1).dot");
/*     */       }
/*     */       else {
/* 288 */         this.outputStream = new FileOutputStream(directory
/* 289 */           .getCanonicalPath() + 
/* 290 */           "/output/pairs(P<P1).dot");
/*     */       }
/* 292 */       Writer writer = new OutputStreamWriter(this.outputStream, "utf-8");
/* 293 */       String cLineStr = "graph G {\r\n";
/* 294 */       cLineStr = cLineStr + " node [fontsize = 11, height = .02]\r\n";
/* 295 */       cLineStr = cLineStr + " edge [fontsize = 9, color = blue]\r\n";
/* 296 */       if ((this.mulinklistP1.size() != 0) && (this.mulinklistP1.size() < 100)) {
/* 297 */         for (MyLink link : this.mulinklistP1) {
/* 298 */           MyNode node1 = link.getNode1();
/* 299 */           MyNode node2 = link.getNode2();
/*     */ 
/* 301 */           NumberFormat formater = 
/* 302 */             DecimalFormat.getInstance();
/* 303 */           formater.setMaximumFractionDigits(2);
/* 304 */           String rt = formater.format(link.getmuinfo());
/*     */ 
/* 306 */           cLineStr = cLineStr + "\"" + pc.calculateSite(node1.getSite()) + "\"" + 
/* 307 */             " -- " + "\"" + pc.calculateSite(node2.getSite()) + 
/* 308 */             "\"";
/* 309 */           cLineStr = cLineStr + " [label = \"" + rt + "\"];\r\n";
/*     */         }
/*     */       }
/*     */ 
/* 313 */       cLineStr = cLineStr + "}";
/* 314 */       writer.write(cLineStr);
/* 315 */       writer.close();
/*     */       Object p;
/* 316 */       if (System.getProperty("os.name").substring(0, 7).equals("Windows")) {
/* 317 */         String cLine = " \"" + directory.getCanonicalPath() + 
/* 318 */           "\\bin\\Graphviz2.24\\bin\\dot.exe\" -Tpng -o " + "\"" + 
/* 319 */           directory.getCanonicalPath() + 
/* 320 */           "\\output\\pairs(P value smaller than P1).png\" -Kdot " + "\"" + 
/* 321 */           directory.getCanonicalPath() + "\\output\\pairs(P value smaller than P1).dot\"";
/*     */ 
/* 327 */         p = Runtime.getRuntime().exec(cLine);
/* 328 */         ((Process)p).waitFor();
/* 329 */         ((Process)p).destroy();
/* 330 */         System.out.println(cLine);
/*     */       }
/*     */ 
/* 335 */       if (System.getProperty("os.name").substring(0, 7).equals("Windows")) {
/* 336 */         this.outputStream = new FileOutputStream(directory.getCanonicalPath() + 
/* 337 */           "\\output\\pairs(P value between P1 and P2).dot");
/*     */       }
/*     */       else {
/* 340 */         this.outputStream = new FileOutputStream(directory
/* 341 */           .getCanonicalPath() + 
/* 342 */           "/output/pairs(P1<P<P2).dot");
/*     */       }
/*     */ 
/* 345 */       writer = new OutputStreamWriter(this.outputStream, "utf-8");
/* 346 */       cLineStr = "graph G {\r\n";
/* 347 */       cLineStr = cLineStr + " node [fontsize = 11, height = .02]\r\n";
/* 348 */       cLineStr = cLineStr + " edge [fontsize = 9, color = blue]\r\n";
/* 349 */       if ((this.mulinklistP2.size() != 0) && (this.mulinklistP2.size() < 100)) {
/* 350 */         for (p = this.mulinklistP2.iterator(); ((Iterator)p).hasNext(); ) { MyLink link = (MyLink)((Iterator)p).next();
/* 351 */           MyNode node1 = link.getNode1();
/* 352 */           MyNode node2 = link.getNode2();
/*     */ 
/* 354 */           NumberFormat formater = 
/* 355 */             DecimalFormat.getInstance();
/* 356 */           formater.setMaximumFractionDigits(2);
/* 357 */           String rt = formater.format(link.getmuinfo());
/*     */ 
/* 359 */           cLineStr = cLineStr + "\"" + pc.calculateSite(node1.getSite()) + "\"" + 
/* 360 */             " -- " + "\"" + pc.calculateSite(node2.getSite()) + 
/* 361 */             "\"";
/* 362 */           cLineStr = cLineStr + " [label = \"" + rt + "\"];\r\n";
/*     */         }
/*     */       }
/*     */ 
/* 366 */       cLineStr = cLineStr + "}";
/* 367 */       writer.write(cLineStr);
/* 368 */       writer.close();
/* 369 */       if (System.getProperty("os.name").substring(0, 7).equals("Windows")) {
/* 370 */         String cLine = " \"" + directory.getCanonicalPath() + 
/* 371 */           "\\bin\\Graphviz2.24\\bin\\dot.exe\" -Tpng -o " + "\"" + 
/* 372 */           directory.getCanonicalPath() + 
/* 373 */           "\\output\\pairs(P value between P1 and P2).png\" -Kdot " + "\"" + 
/* 374 */           directory.getCanonicalPath() + "\\output\\pairs(P value between P1 and P2).dot\"";
/*     */ 
/* 380 */         Process pr = Runtime.getRuntime().exec(cLine);
/* 381 */         pr.waitFor();
/* 382 */         pr.destroy();
/* 383 */         System.out.println(cLine);
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 388 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

