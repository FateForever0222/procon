/*    */ package source.model;
/*    */ 
/*    */ public class Triplet
/*    */ {
/*    */   private short s1;
/*    */   private short s2;
/*    */   private short s3;
/*    */ 
/*    */   public short getS1()
/*    */   {
/*  6 */     return this.s1;
/*    */   }
/*    */ 
/*    */   public void setS1(short s) {
/* 10 */     this.s1 = s;
/*    */   }
/*    */ 
/*    */   public short getS2() {
/* 14 */     return this.s2;
/*    */   }
/*    */ 
/*    */   public void setS2(short s) {
/* 18 */     this.s2 = s;
/*    */   }
/*    */ 
/*    */   public short getS3() {
/* 22 */     return this.s3;
/*    */   }
/*    */ 
/*    */   public void setS3(short s) {
/* 26 */     this.s3 = s;
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.model.Triplet
 * JD-Core Version:    0.6.2
 */