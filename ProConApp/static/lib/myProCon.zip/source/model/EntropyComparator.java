/*    */ package source.model;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ 
/*    */ public class EntropyComparator
/*    */   implements Comparator
/*    */ {
/*    */   public final int compare(Object pFirst, Object pSecond)
/*    */   {
/*  7 */     double aFirstWeight = ((EntropyInformation)pFirst).getEntropy();
/*  8 */     double aSecondWeight = ((EntropyInformation)pSecond).getEntropy();
/*  9 */     double diff = aFirstWeight - aSecondWeight;
/* 10 */     if (diff > 0.0D)
/* 11 */       return -1;
/* 12 */     if (diff < 0.0D) {
/* 13 */       return 1;
/*    */     }
/* 15 */     return 0;
/*    */   }
/*    */ }

