/*    */ package source.model;
/*    */ 
/*    */ public class HashTable
/*    */ {
/*  4 */   int[] residue = new int[21];
/*  5 */   final char[] locator = { '-', 'C', 'F', 'I', 'L', 'M', 'V', 'W', 'Y', 'A', 
/*  6 */     'T', 'D', 'E', 'G', 'P', 'N', 'Q', 'S', 'H', 'R', 'K' };
/*    */ 
/*    */   public void add(char a)
/*    */   {
/*  9 */     this.residue[location(a)] += 1;
/*    */   }
/*    */ 
/*    */   public int[] get() {
/* 13 */     return this.residue;
/*    */   }
/*    */ 
/*    */   private int location(char a) {
/* 17 */     for (int i = 0; i < 21; i++) {
/* 18 */       if (a == this.locator[i]) {
/* 19 */         return i;
/*    */       }
/*    */     }
/* 22 */     return -1;
/*    */   }
/*    */ }
