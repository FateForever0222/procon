/*    */ package source.model;
/*    */ 
/*    */ public class EntropyInformation
/*    */ {
/*    */   private double entropy;
/*    */   private String site;
/*    */   private int position;
/*    */ 
/*    */   public EntropyInformation(int position, String site, double entropy)
/*    */   {
/*  6 */     this.position = position;
/*  7 */     this.site = site;
/*  8 */     this.entropy = entropy;
/*    */   }
/*    */ 
/*    */   public double getEntropy() {
/* 12 */     return this.entropy;
/*    */   }
/*    */ 
/*    */   public int getPosition() {
/* 16 */     return this.position;
/*    */   }
/*    */ 
/*    */   public String getSite() {
/* 20 */     return this.site;
/*    */   }
/*    */ }

