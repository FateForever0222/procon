/*    */ package source.model;
/*    */ 
/*    */ public class MyNode
/*    */ {
/*    */   private int site;
/*    */   private int x;
/*    */   private int y;
/*    */ 
/*    */   public MyNode()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MyNode(int site)
/*    */   {
/*  9 */     this.site = site;
/*    */   }
/*    */ 
/*    */   public MyNode(int site, int x, int y)
/*    */   {
/* 14 */     this.site = site;
/* 15 */     this.x = x;
/* 16 */     this.y = y;
/*    */   }
/*    */ 
/*    */   public void setSite(int site) {
/* 20 */     this.site = site;
/*    */   }
/*    */ 
/*    */   public void setPosition(int x, int y) {
/* 24 */     this.x = x;
/* 25 */     this.y = y;
/*    */   }
/*    */ 
/*    */   public int getSite() {
/* 29 */     return this.site;
/*    */   }
/*    */ 
/*    */   public int getX() {
/* 33 */     return this.x;
/*    */   }
/*    */ 
/*    */   public int getY() {
/* 37 */     return this.y;
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.model.MyNode
 * JD-Core Version:    0.6.2
 */