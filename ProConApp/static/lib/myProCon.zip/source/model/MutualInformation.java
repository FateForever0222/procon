/*     */ package source.model;
/*     */ 
/*     */ import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.text.NumberFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public class MutualInformation
/*     */ {
/*     */   private boolean groupflag;
/*     */   private int[] group;
/*     */   private double gpercent;
/*     */   private double p1;
/*     */   private double p2;
/*     */   private char[][] seq;
/*     */   private double[][] mutuinf;
/*     */   private ProbabilityCalculator proCalc;
/*     */   private int residusNumber;
/*     */   private int sequenceNumber;
/*     */   private int groupNumber;
/*     */   private int numberOfPairs;
/*     */   private double[][] probprob;
/*     */   private double paraml;
/*     */   private double maxmuinf;
/*     */   private double minmuinf;
/*     */   private double aveMuinf;
/*     */   private double standdev;
/*     */   private int numOfLessGap;
/*     */   private int numOfMuInCal;
/*     */   private int kkEstimate;
/*     */   private int topnum;
/*     */   private double[][] freqaa;
/*     */   private MutObjNew[] mutObj;
/*     */   private ArrayList<MutObjNew> List;
/*     */   private ArrayList<MutObjNew> ListP1;
/*     */   private ArrayList<MutObjNew> ListP2;
/*     */   private int[] grouptable;
/*     */   private final int[] ltable;
/*     */ 
/*     */   public MutualInformation(ProbabilityCalculator proCalc, double gapPercent, double p1, double p2)
/*     */   {
/*  11 */     	this.ltable =
/* 747 */       new int[] { 0, -1, 1, 2, 3, 4, 5, 6, 7, -1, 8, 9, 10, 11, -1, 12, 13, 14, 15, 16, -1, 17, 18, -1, 19, -1, -1, -1, -1, -1 };
				this.proCalc = proCalc;
				this.p1 = p1;
				this.p2 = p2;
				this.groupflag = true;
				this.seq = proCalc.getSeq();
				this.gpercent = gapPercent;
				this.residusNumber = proCalc.getResNumber();
				this.sequenceNumber = proCalc.getSeqNumber();
				this.paraml = (this.sequenceNumber * gapPercent);
				this.numberOfPairs = (this.residusNumber * this.residusNumber / 2);
				this.mutuinf = new double[this.residusNumber][this.residusNumber];
				for (int i = 0; i < this.residusNumber; i++)
					for (int j = 0; j < this.residusNumber; j++)
						this.mutuinf[i][j] = 0.0D;
/* 747 */     	this.freqaa = proCalc.getFreqaa();
				this.aveMuinf = 0.0D;
				this.standdev = 0.0D;
				this.numOfLessGap = 0;
				this.kkEstimate = 0;
				for (int i = 0; i < this.residusNumber; i++) {
					if (this.freqaa[i][20] < this.paraml)
						this.numOfLessGap += 1;
					for (int j = i + 1; j < this.residusNumber; j++)
						if ((this.freqaa[i][20] < this.paraml) && (this.freqaa[j][20] < this.paraml))
							this.kkEstimate += 1;
/*     */     	}
/* 747 */     	this.mutObj = new MutObjNew[this.kkEstimate];
				System.out.println("kkEstimate =" + this.kkEstimate);
				for (int i = 0; i < this.kkEstimate; i++) {
					this.mutObj[i] = new MutObjNew();
					this.mutObj[i].setMuinf12(0.0D);
					this.mutObj[i].setSite1(0);
					this.mutObj[i].setSite2(0);
				}
				this.numOfMuInCal = 0;
				double numnogapTmp = 0.0D;
				this.probprob = new double[20][20];
				double[][] probmutuTmp = new double[20][20];
				for (int i = 0; i < this.residusNumber; i++)
					for (int j = i + 1; j < this.residusNumber; j++) {
						double numnogap = this.sequenceNumber;
						if ((this.freqaa[i][20] < this.paraml) && (this.freqaa[j][20] < this.paraml)) {
							for (int ii = 0; ii < 20; ii++) for (int jj = 0; jj < 20; jj++) {
								this.probprob[ii][jj] = 0.0D; probmutuTmp[ii][jj] = 0.0D;
							}
							for (int k = 0; k < this.sequenceNumber; k++)
								if ((this.seq[k][j] == '-') || (this.seq[k][i] == '-')) {
									numnogap -= 1.0D;
								}
								else {
									int ii = this.ltable[(this.seq[k][i] - 'A')];
									int jj = this.ltable[(this.seq[k][j] - 'A')];
									if ((ii >= 0) && (jj >= 0))
										this.probprob[ii][jj] += 1.0D;
									else if (ii < 0)
										System.out.println("symbol " + this.seq[k][i] + " is not included in 20 AAs or gap(-)");
									else if (jj < 0)
										System.out.println("symbol " + this.seq[k][j] + " is not included in 20 AAs or gap(-)");
								}
/* 747 */           numnogapTmp = 1.0D / numnogap; 

				for (int ii = 0; ii < 20; ii++) 
					for (int jj = 0; jj < 20; jj++) 
						if (this.probprob[ii][jj] != 0.0D) {
							//if (this.freqaa[i][ii] != 0.0D) 
								//this.freqaa[j][jj]; 
								double A = this.probprob[ii][jj] * numnogapTmp; 
								double B = this.probprob[ii][jj] * numnogap; 
								probmutuTmp[ii][jj] = probMutuCalc(A, B, this.freqaa[i][ii], this.freqaa[j][jj]); 
								this.mutObj[this.numOfMuInCal].setMuinf(ii, jj, (float)probmutuTmp[ii][jj]); 
								if (probmutuTmp[ii][jj] >= 40.0D) 
									System.out.println("numOfMuInCal =" + this.numOfMuInCal + "; i = " + i + ";  j = " + j + "; probmutuTmp[" + ii + "][" + jj + "] = " + probmutuTmp[ii][jj]); 
									this.mutuinf[i][j] += probmutuTmp[ii][jj]; 
							}  
/* 747 */             if (this.mutuinf[i][j] > 0.0D);
/* 747 */             this.mutObj[this.numOfMuInCal].setSite1(i); 
					  this.mutObj[this.numOfMuInCal].setSite2(j); 
					  this.mutObj[this.numOfMuInCal].setMuinf12(this.mutuinf[i][j]); 
					  this.aveMuinf += this.mutuinf[i][j]; this.numOfMuInCal += 1; 
					  } 
					} 
				this.aveMuinf /= this.numOfMuInCal; 
				Arrays.sort(this.mutObj, new MutuComparator()); 
				ArrayList max = this.mutObj[0].getMuinf(); 
				this.maxmuinf = this.mutObj[0].getMuinf12(); 
				this.minmuinf = this.mutObj[(this.mutObj.length - 1)].getMuinf12(); System.out.println("max is between site " + (this.mutObj[0].getSite1() + 1) + "and site" + (this.mutObj[0].getSite2() + 1) + "max = " + this.maxmuinf); 
				System.out.println("min is between site " + (this.mutObj[(this.mutObj.length - 1)].getSite1() + 1) + "and site" + (this.mutObj[(this.mutObj.length - 1)].getSite2() + 1) + "min = " + this.minmuinf); 
				System.out.println("ave = " + this.aveMuinf); int rest = this.numOfMuInCal % 4; for (int i = 0; i < rest; i++) this.standdev += (this.mutObj[i].getMuinf12() - this.aveMuinf) * (this.mutObj[i].getMuinf12() - this.aveMuinf) / (this.numOfMuInCal - 1); System.out.println("numOfMuInCal = " + this.numOfMuInCal + "; standdev = " + this.standdev); 
				for (int i = rest; i < this.numOfMuInCal; i += 4) {
					this.standdev += (this.mutObj[(i + 0)].getMuinf12() - this.aveMuinf) * (this.mutObj[(i + 0)].getMuinf12() - this.aveMuinf) / (this.numOfMuInCal - 1); 
					this.standdev += (this.mutObj[(i + 1)].getMuinf12() - this.aveMuinf) * (this.mutObj[(i + 1)].getMuinf12() - this.aveMuinf) / (this.numOfMuInCal - 1); 
					this.standdev += (this.mutObj[(i + 2)].getMuinf12() - this.aveMuinf) * (this.mutObj[(i + 2)].getMuinf12() - this.aveMuinf) / (this.numOfMuInCal - 1); 
					this.standdev += (this.mutObj[(i + 3)].getMuinf12() - this.aveMuinf) * (this.mutObj[(i + 3)].getMuinf12() - this.aveMuinf) / (this.numOfMuInCal - 1); 
					} 
				this.standdev = Math.sqrt(this.standdev); System.out.println("standdev = " + this.standdev); 
				double limitP1 = this.aveMuinf + this.standdev * getZvalue1(this.p1); double limitP2 = this.aveMuinf + this.standdev * getZvalue2(this.p2); this.ListP1 = new ArrayList(); 
				this.ListP2 = new ArrayList(); this.List = new ArrayList(); 
				
				int i=0;
				for (; this.mutObj[i].getMuinf12() > limitP2; i++) { 
					this.List.add(this.mutObj[i]); 
					if (this.mutObj[i].getMuinf12() > limitP1) 
					this.ListP1.add(this.mutObj[i]); 
					else this.ListP2.add(this.mutObj[i]);  
				} 
				
				this.topnum = i;
/*     */   }
/*     */ 
/*     */   public MutualInformation(ProbabilityCalculator proCalc, double gapPercent, double p1, double p2, boolean groupflag)
/*     */   {
/* 270 */     this.ltable = 
/* 747 */       new int[] { 0, -1, 1, 2, 3, 4, 5, 6, 7, -1, 8, 9, 10, 11, -1, 12, 13, 14, 15, 16, -1, 17, 18, -1, 19, -1, -1, -1, -1, -1 }; 
			  this.proCalc = proCalc; 
			  this.p1 = p1; 
			  this.p2 = p2; 
			  this.groupflag = groupflag; 
			  this.seq = proCalc.getSeq(); 
			  this.gpercent = gapPercent; 
			  this.residusNumber = proCalc.getResNumber(); 
			  this.sequenceNumber = proCalc.getSeqNumber(); 
			  this.group = proCalc.getGroup(); 
			  this.grouptable = new int[30]; 
			  
			  for (int i = 0; i < 30; i++) 
				  this.grouptable[i] = -1; 
			  
			  for (int i = 0; i < ProbabilityCalculator.RESIDUE.length - 1; i++) 
				  this.grouptable[(ProbabilityCalculator.RESIDUE[i] - 'A')] = this.group[i]; 
			  for (int i = 0; i < 30; i++) 
				  System.out.print(" " + this.grouptable[i]); System.out.println();
			  this.paraml = (this.sequenceNumber * gapPercent);
				  
			  this.numberOfPairs = (this.residusNumber * this.residusNumber / 2); 
			  this.mutuinf = new double[this.residusNumber][this.residusNumber]; 
			  for (int i = 0; i < this.residusNumber; i++) 
				  for (int j = 0; j < this.residusNumber; j++) 
					  this.mutuinf[i][j] = 0.0D; 
/* 747 */     this.freqaa = proCalc.getProb6aa(); 
			  this.groupNumber = proCalc.getNumberofgroup(); 
			  System.out.println("number of group = " + this.groupNumber); 
			  this.aveMuinf = 0.0D; 
			  this.standdev = 0.0D; 
			  this.numOfLessGap = 0; 
			  this.kkEstimate = 0;
			  for (int i = 0; i < this.residusNumber; i++) { 
				  if (this.freqaa[i][this.groupNumber] < this.paraml) 
					  this.numOfLessGap += 1; 
				  for (int j = i + 1; j < this.residusNumber; j++) 
					  if ((this.freqaa[i][this.groupNumber] < this.paraml) && (this.freqaa[j][this.groupNumber] < this.paraml)) 
						  this.kkEstimate += 1;  
/*     */     }
/* 747 */     
			  this.mutObj = new MutObjNew[this.kkEstimate]; 
			  System.out.println("kkEstimate =" + this.kkEstimate); 
			  for (int i = 0; i < this.kkEstimate; i++) { 
				  this.mutObj[i] = new MutObjNew(); 
				  this.mutObj[i].setMuinf12(0.0D); 
				  this.mutObj[i].setSite1(0); 
				  this.mutObj[i].setSite2(0); 
			 } 
			  this.numOfMuInCal = 0; 
			  double numnogapTmp = 0.0D; 
			  this.probprob = new double[this.groupNumber][this.groupNumber]; 
			  double[][] probmutuTmp = new double[this.groupNumber][this.groupNumber];

			  for (int i = 0; i < this.residusNumber; i++) 
				  for (int j = i + 1; j < this.residusNumber; j++) { 
					  double numnogap = this.sequenceNumber; 
					  if ((this.freqaa[i][this.groupNumber] < this.paraml) && (this.freqaa[j][this.groupNumber] < this.paraml)) { 
						  for (int ii = 0; ii < this.groupNumber; ii++) 
							  for (int jj = 0; jj < this.groupNumber; jj++) { 
								  this.probprob[ii][jj] = 0.0D; probmutuTmp[ii][jj] = 0.0D; 
								  } 
						  for (int k = 0; k < this.sequenceNumber; k++) 
							  if ((this.seq[k][j] == '-') || (this.seq[k][i] == '-')) { 
								  numnogap -= 1.0D; 
								  } 
							  else { 
								  int ii = this.grouptable[(this.seq[k][i] - 'A')]; 
								  int jj = this.grouptable[(this.seq[k][j] - 'A')]; 
								  if ((ii >= 0) && (jj >= 0)) this.probprob[ii][jj] += 1.0D; 
								  else if (ii < 0)
								  	System.out.println("symbol " + this.seq[k][i] + " is not included in 20 AAs or gap(-)");
								  else if (jj < 0)
								  	System.out.println("symbol " + this.seq[k][j] + " is not included in 20 AAs or gap(-)");
								  } 
/* 747 */           	numnogapTmp = 1.0D / numnogap;
						for (int ii = 0; ii < this.groupNumber; ii++) 
							for (int jj = 0; jj < this.groupNumber; jj++) 
								if (this.probprob[ii][jj] != 0.0D) { 
									//if (this.freqaa[i][ii] != 0.0D) this.freqaa[j][jj]; 
										double A = this.probprob[ii][jj] * numnogapTmp; 
										double B = this.probprob[ii][jj] * numnogap;
										System.out.println(this.freqaa[i][ii]);
										System.out.println(this.freqaa[j][jj]);
										probmutuTmp[ii][jj] = probMutuCalc(A, B, this.freqaa[i][ii], this.freqaa[j][jj]); 
										this.mutObj[this.numOfMuInCal].setMuinf(ii, jj, (float)probmutuTmp[ii][jj]); 
										if (probmutuTmp[ii][jj] >= 40.0D) 
											System.out.println("numOfMuInCal =" + this.numOfMuInCal + "; i = " + i + ";  j = " + j + "; probmutuTmp[" + ii + "][" + jj + "] = " + probmutuTmp[ii][jj]); 
										this.mutuinf[i][j] += probmutuTmp[ii][jj]; 
										}  
/* 747 */           if (this.mutuinf[i][j] > 0.0D) {
/* 747 */           	this.mutObj[this.numOfMuInCal].setSite1(i); 
						this.mutObj[this.numOfMuInCal].setSite2(j); 
						this.mutObj[this.numOfMuInCal].setMuinf12(this.mutuinf[i][j]); 
						this.aveMuinf += this.mutuinf[i][j]; this.numOfMuInCal += 1;
					}
					} 
				  } 
			  this.aveMuinf /= this.numOfMuInCal; 
			  Arrays.sort(this.mutObj, new MutuComparator()); 
			  ArrayList max = this.mutObj[0].getMuinf(); 
			  this.maxmuinf = this.mutObj[0].getMuinf12(); 
			  this.minmuinf = this.mutObj[(this.mutObj.length - 1)].getMuinf12(); 
			  System.out.println("max is between site " + (this.mutObj[0].getSite1() + 1) + "and site" + (this.mutObj[0].getSite2() + 1) + "max = " + this.maxmuinf); 
			  System.out.println("min is between site " + (this.mutObj[(this.mutObj.length - 1)].getSite1() + 1) + "and site" + (this.mutObj[(this.mutObj.length - 1)].getSite2() + 1) + "min = " + this.minmuinf); 
			  System.out.println("ave = " + this.aveMuinf); 
			  
			  int rest = this.numOfMuInCal % 4; 
			  for (int i = 0; i < rest; i++) 
				  this.standdev += (this.mutObj[i].getMuinf12() - this.aveMuinf) * (this.mutObj[i].getMuinf12() - this.aveMuinf) / (this.numOfMuInCal - 1); 
			  System.out.println("numOfMuInCal = " + this.numOfMuInCal + "; standdev = " + this.standdev); 
			  for (int i = rest; i < this.numOfMuInCal; i += 4) { 
				  this.standdev += (this.mutObj[(i + 0)].getMuinf12() - this.aveMuinf) * (this.mutObj[(i + 0)].getMuinf12() - this.aveMuinf) / (this.numOfMuInCal - 1); 
				  this.standdev += (this.mutObj[(i + 1)].getMuinf12() - this.aveMuinf) * (this.mutObj[(i + 1)].getMuinf12() - this.aveMuinf) / (this.numOfMuInCal - 1); 
				  this.standdev += (this.mutObj[(i + 2)].getMuinf12() - this.aveMuinf) * (this.mutObj[(i + 2)].getMuinf12() - this.aveMuinf) / (this.numOfMuInCal - 1); 
				  this.standdev += (this.mutObj[(i + 3)].getMuinf12() - this.aveMuinf) * (this.mutObj[(i + 3)].getMuinf12() - this.aveMuinf) / (this.numOfMuInCal - 1); 
				  } 
			  
			  this.standdev = Math.sqrt(this.standdev); 
			  System.out.println("standdev = " + this.standdev); 
			  double limitP1 = this.aveMuinf + this.standdev * getZvalue1(this.p1); 
			  double limitP2 = this.aveMuinf + this.standdev * getZvalue2(this.p2); 
			  this.ListP1 = new ArrayList(); this.ListP2 = new ArrayList(); 
			  this.List = new ArrayList(); 
			  
			  int i=0;
			  for (; this.mutObj[i].getMuinf12() > limitP2; i++) { 
				  this.List.add(this.mutObj[i]); 
				  if (this.mutObj[i].getMuinf12() > limitP1) this.ListP1.add(this.mutObj[i]); 
				  else this.ListP2.add(this.mutObj[i]);  
				  }
			  
			  this.topnum = i;
/*     */   }
/*     */ 
/*     */   public ArrayList<MutObjNew> getListP1()
/*     */   {
/* 570 */     return this.ListP1;
/*     */   }
/*     */ 
/*     */   public ArrayList<MutObjNew> getListP2() {
/* 574 */     return this.ListP2;
/*     */   }
/*     */ 
/*     */   public ArrayList<MutObjNew> getList() {
/* 578 */     return this.List;
/*     */   }
/*     */ 
/*     */   private double probMutuCalc(double A, double B, double freqaaiii, double freqaajjj)
/*     */   {
/* 583 */     return A * A * 1000.0D * Math.log(B / (freqaaiii * freqaajjj));
/*     */   }
/*     */ 
/*     */   private double getZvalue1(double pvalue1)
/*     */   {
/* 588 */     double zvalue1 = 0.0D;
/* 589 */     if (pvalue1 == 1.E-005D)
/* 590 */       zvalue1 = 4.25D;
/* 591 */     else if (pvalue1 == 5.E-005D)
/* 592 */       zvalue1 = 3.88D;
/* 593 */     else if (pvalue1 == 0.0001D)
/* 594 */       zvalue1 = 3.7D;
/* 595 */     else if (pvalue1 == 0.0005D)
/* 596 */       zvalue1 = 3.3D;
/* 597 */     else if (pvalue1 == 0.001D)
/* 598 */       zvalue1 = 3.1D;
/* 599 */     else if (pvalue1 == 0.002D)
/* 600 */       zvalue1 = 2.88D;
/* 601 */     else if (pvalue1 == 0.003D)
/* 602 */       zvalue1 = 2.75D;
/* 603 */     else if (pvalue1 == 0.004D)
/* 604 */       zvalue1 = 2.65D;
/* 605 */     else if (pvalue1 == 0.005D)
/* 606 */       zvalue1 = 2.58D;
/* 607 */     else if (pvalue1 == 0.01D)
/* 608 */       zvalue1 = 2.33D;
/* 609 */     else if (pvalue1 == 0.012D)
/* 610 */       zvalue1 = 2.26D;
/* 611 */     else if (pvalue1 == 0.014D)
/* 612 */       zvalue1 = 2.2D;
/* 613 */     else if (pvalue1 == 0.015D) {
/* 614 */       zvalue1 = 2.17D;
/*     */     }
/* 616 */     return zvalue1;
/*     */   }
/*     */ 
/*     */   private double getZvalue2(double pvalue2) {
/* 620 */     double zvalue2 = 0.0D;
/* 621 */     if (pvalue2 == 0.016D)
/* 622 */       zvalue2 = 2.14D;
/* 623 */     else if (pvalue2 == 0.017D)
/* 624 */       zvalue2 = 2.12D;
/* 625 */     else if (pvalue2 == 0.018D)
/* 626 */       zvalue2 = 2.1D;
/* 627 */     else if (pvalue2 == 0.019D)
/* 628 */       zvalue2 = 2.08D;
/* 629 */     else if (pvalue2 == 0.02D)
/* 630 */       zvalue2 = 2.06D;
/* 631 */     else if (pvalue2 == 0.03D)
/* 632 */       zvalue2 = 1.88D;
/* 633 */     else if (pvalue2 == 0.04D)
/* 634 */       zvalue2 = 1.75D;
/* 635 */     else if (pvalue2 == 0.05D) {
/* 636 */       zvalue2 = 1.65D;
/*     */     }
/* 638 */     return zvalue2;
/*     */   }
/*     */ 
/*     */   public void getMutuInfo() {
/* 642 */     for (int i = 0; i < this.residusNumber; i++)
/* 643 */       for (int j = 0; j < this.residusNumber; j++)
/* 644 */         System.out.println("i= " + i + " j = " + j + " " + 
/* 645 */           this.mutuinf[i][j]);
/*     */   }
/*     */ 
/*     */   public double getGpercent()
/*     */   {
/* 651 */     return this.gpercent;
/*     */   }
/*     */ 
/*     */   public int getResidusNumber() {
/* 655 */     return this.residusNumber;
/*     */   }
/*     */ 
/*     */   public int getNumOfMuInCal()
/*     */   {
/* 660 */     return this.numOfMuInCal;
/*     */   }
/*     */ 
/*     */   public int getNumOfLessGap()
/*     */   {
/* 665 */     return this.numOfLessGap;
/*     */   }
/*     */ 
/*     */   public int getTopnum() {
/* 669 */     return this.topnum;
/*     */   }
/*     */ 
/*     */   public MutObjNew[] getMutObj() {
/* 673 */     return this.mutObj;
/*     */   }
/*     */ 
/*     */   public boolean getGroupFlag() {
/* 677 */     return this.groupflag;
/*     */   }
/*     */ 
/*     */   public void rankMuInfo() {
/* 681 */     Arrays.sort(this.mutObj, new MutuComparator());
/*     */ 
/* 685 */     this.maxmuinf = this.mutObj[0].getMuinf12();
/* 686 */     this.minmuinf = this.mutObj[(this.mutObj.length - 1)].getMuinf12();
/*     */ 
/* 688 */     System.out.println("max = " + this.maxmuinf + " min = " + this.minmuinf);
/* 689 */     System.out.println("ave = " + this.aveMuinf);
/* 690 */     System.out.println("standdev = " + this.standdev);
/*     */   }
/*     */   public static void main(String[] args) {
/*     */     try {
	      
	             String[] allgi={"4826734",
	            		"189181666",
	            		"171846278",
	            		"294862261",
	            		"169790969",
	            		"4506113",
	            		"4506163",
	            		"156105679",
	            		"34147513",
	            		"4507091",
	            		"4507109",
	            		"6678271",
	            		"4507725",
	            		"4759302",
	            		"6005942"};
	            
	            for (int j =0;j<allgi.length;j++){
	            String gi =allgi[j];
/* 694 */       ProbabilityCalculator pc = new ProbabilityCalculator("E:/Eclipse/data/"+gi+".unaligned.aligned");
/*     */ 
/* 698 */      // MutualInformation mi = new MutualInformation(pc, 0.3D, 0.01D, 0.05D, false);
				MutualInformation mi = new MutualInformation(pc, 0.3D, 0.01D, 0.05D);
/* 699 */      System.out
/* 700 */         .println("The number of sites used for mutuinf calculated is: " + 
/* 701 */        mi.getNumOfLessGap());
/* 702 */       System.out.println("The number of mutual information calculated is: " + 
/* 703 */         mi.getNumOfMuInCal());
/* 704 */       System.out.println("the topnum is: " + mi.getTopnum());
/* 705 */       System.out.println("P1 list = " + mi.getListP1().size());
/* 706 */       System.out.println("P2 list = " + mi.getListP2().size());

				File writename0 = new File("E:/Eclipse/data/test/"+gi+".information"); // 相对路径，如果没有则要建立一个新的output。txt文件
				writename0.createNewFile(); // 创建新文件
				BufferedWriter out0 = new BufferedWriter(new FileWriter(writename0));
				
				double[] information = pc.getEntropy0();
				double[] information2 = pc.getEntropy1();
				
				for(int i=0;i<information.length;i++){
					int residue =i+1;
					
					NumberFormat formater = DecimalFormat.getInstance();
						formater.setMaximumFractionDigits(3);
							String rt020 = formater.format(information[i]);
							String rt006 = formater.format(information2[i]);
				out0.write(residue+" "+rt020+" "+rt006+"\n"); // \r\n即为换行
				}
				out0.flush(); // 把缓存区内容压入文件
				out0.close(); // 最后记得关闭文件



					File writename = new File("E:/Eclipse/data/test/"+gi+".mi20"); // 相对路径，如果没有则要建立一个新的output。txt文件
					writename.createNewFile(); // 创建新文件
					BufferedWriter out = new BufferedWriter(new FileWriter(writename));
					
					ArrayList MIlist = mi.getListP1();
					
					int position1=0;
					int position2=0;
					NumberFormat formater = DecimalFormat.getInstance();
					formater.setMaximumFractionDigits(2);
					
					for(int i=0;i<MIlist.size();i++){
						MutObjNew MO = (MutObjNew) MIlist.get(i);
						String rt = formater.format(MO.getMuinf12());
						
						position1=	MO.getSite1()+1;
						position2=	MO.getSite2()+1;
						out.write(position1+" "+position2+" "+rt+"\n"); // \r\n即为换行
					}
					out.flush(); // 把缓存区内容压入文件
					out.close(); // 最后记得关闭文件
					
					

					 MutualInformation mi6 = new MutualInformation(pc, 0.3D, 0.01D, 0.05D, false);
					 File writename6 = new File("E:/Eclipse/data/test/"+gi+".mi6"); // 相对路径，如果没有则要建立一个新的output。txt文件
						writename6.createNewFile(); // 创建新文件
						BufferedWriter out6 = new BufferedWriter(new FileWriter(writename6));
						
						ArrayList MIlist6 = mi6.getListP1();
						
						int position16=0;
						int position26=0;
						
						
						for(int i=0;i<MIlist6.size();i++){
							MutObjNew MO6 = (MutObjNew) MIlist6.get(i);
							
							
									String rt6 = formater.format(MO6.getMuinf12());
							
									position16=	MO6.getSite1()+1;
									position26=	MO6.getSite2()+1;
						out6.write(position16+" "+position26+" "+rt6+"\n"); // \r\n即为换行
						}
						out6.flush(); // 把缓存区内容压入文件
						out6.close(); // 最后记得关闭文件
	            }

/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.model.MutualInformation
 * JD-Core Version:    0.6.2
 */