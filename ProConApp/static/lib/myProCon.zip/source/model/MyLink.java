/*    */ package source.model;
/*    */ 
/*    */ public class MyLink
/*    */ {
/*    */   private MyNode node1;
/*    */   private MyNode node2;
/*    */   private double muinfo;
/*    */ 
/*    */   public MyLink(MyNode node1, MyNode node2)
/*    */   {
/*  6 */     this.node1 = node1;
/*  7 */     this.node2 = node2;
/*    */   }
/*    */ 
/*    */   public MyLink(MyNode node1, MyNode node2, double muinfo) {
/* 11 */     this.node1 = node1;
/* 12 */     this.node2 = node2;
/* 13 */     this.muinfo = muinfo;
/*    */   }
/*    */ 
/*    */   public MyNode getNode1() {
/* 17 */     return this.node1;
/*    */   }
/*    */ 
/*    */   public MyNode getNode2() {
/* 21 */     return this.node2;
/*    */   }
/*    */ 
/*    */   public double getmuinfo() {
/* 25 */     return this.muinfo;
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.model.MyLink
 * JD-Core Version:    0.6.2
 */