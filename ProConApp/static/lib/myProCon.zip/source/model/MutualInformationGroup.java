/*     */ package source.model;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public class MutualInformationGroup
/*     */ {
/*     */   private int[] group;
/*     */   private double gpercent;
/*     */   private double p1;
/*     */   private double p2;
/*     */   private char[][] seq;
/*     */   private double[][] mutuinf;
/*     */   private ProbabilityCalculator proCalc;
/*     */   private int residusNumber;
/*     */   private int sequenceNumber;
/*     */   private int groupNumber;
/*     */   private int numberOfPairs;
/*     */   private double[][] probprob;
/*     */   private double paraml;
/*     */   private double maxmuinf;
/*     */   private double minmuinf;
/*     */   private double aveMuinf;
/*     */   private double standdev;
/*     */   private int numOfLessGap;
/*     */   private int numOfMuInCal;
/*     */   private int kkEstimate;
/*     */   private int topnum;
/*     */   private double[][] freqaa;
/*     */   private MutObjNew[] mutObj;
/*     */   private ArrayList<MutObjNew> List;
/*     */   private ArrayList<MutObjNew> ListP1;
/*     */   private ArrayList<MutObjNew> ListP2;
/*     */   private int[] grouptable;
/*     */   private final int[] ltable;
/*     */ 
/*     */   public MutualInformationGroup(ProbabilityCalculator proCalc, double gapPercent, double p1, double p2)
/*     */   {
/*   8 */     this.ltable = 
/* 476 */       new int[] { 0, -1, 1, 2, 3, 4, 5, 6, 7, -1, 8, 9, 10, 11, -1, 12, 13, 14, 15, 16, -1, 17, 18, -1, 19, -1, -1, -1, -1, -1 }; 
				this.proCalc = proCalc; this.p1 = p1; 
				this.p2 = p2; 
				this.seq = proCalc.getSeq(); 
				this.gpercent = gapPercent; 
				this.residusNumber = proCalc.getResNumber(); 
				this.sequenceNumber = proCalc.getSeqNumber(); 
				this.group = proCalc.getGroup(); 
				this.grouptable = new int[30]; 
				for (int i = 0; i < 30; i++) this.grouptable[i] = -1; 
				for (int i = 0; i < ProbabilityCalculator.RESIDUE.length - 1; i++) this.grouptable[(ProbabilityCalculator.RESIDUE[i] - 'A')] = this.group[i]; 
				for (int i = 0; i < 30; i++) System.out.print(" " + this.grouptable[i]); System.out.println(); 
				this.paraml = (this.sequenceNumber * gapPercent); 
				this.numberOfPairs = (this.residusNumber * this.residusNumber / 2); 
				this.mutuinf = new double[this.residusNumber][this.residusNumber]; 
				for (int i = 0; i < this.residusNumber; i++) 
					for (int j = 0; j < this.residusNumber; j++) this.mutuinf[i][j] = 0.0D; 
				
/* 476 */       this.freqaa = proCalc.getProb6aa(); 
				this.groupNumber = proCalc.getNumberofgroup(); 
				System.out.println("number of group = " + this.groupNumber); 
				this.aveMuinf = 0.0D; 
				this.standdev = 0.0D; 
				this.numOfLessGap = 0;
				this.kkEstimate = 0; 
				for (int i = 0; i < this.residusNumber; i++) {
					if (this.freqaa[i][this.groupNumber] < this.paraml) this.numOfLessGap += 1; 
					for (int j = i + 1; j < this.residusNumber; j++) 
						if ((this.freqaa[i][this.groupNumber] < this.paraml) && (this.freqaa[j][this.groupNumber] < this.paraml)) this.kkEstimate += 1;  
/*     */        }
/* 476 */     
				this.mutObj = new MutObjNew[this.kkEstimate]; 
				System.out.println("kkEstimate =" + this.kkEstimate); 
				for (int i = 0; i < this.kkEstimate; i++) { 
					this.mutObj[i] = new MutObjNew(); 
					this.mutObj[i].setMuinf12(0.0D); 
					this.mutObj[i].setSite1(0); 
					this.mutObj[i].setSite2(0); 
					} 
				this.numOfMuInCal = 0;
				double numnogapTmp = 0.0D; 
				this.probprob = new double[this.groupNumber][this.groupNumber]; 
				double[][] probmutuTmp = new double[this.groupNumber][this.groupNumber]; 
				for (int i = 0; i < this.residusNumber; i++) 
					for (int j = i + 1; j < this.residusNumber; j++) { 
						double numnogap = this.sequenceNumber; 
						if ((this.freqaa[i][this.groupNumber] < this.paraml) && (this.freqaa[j][this.groupNumber] < this.paraml)) { 
							for (int ii = 0; ii < this.groupNumber; ii++) 
								for (int jj = 0; jj < this.groupNumber; jj++) { 
									this.probprob[ii][jj] = 0.0D; 
									probmutuTmp[ii][jj] = 0.0D; 
									} 
							for (int k = 0; k < this.sequenceNumber; k++) 
								if ((this.seq[k][j] == '-') || (this.seq[k][i] == '-')) { 
									numnogap -= 1.0D; 
									} 
								else { 
									int ii = this.grouptable[(this.seq[k][i] - 'A')]; 
									int jj = this.grouptable[(this.seq[k][j] - 'A')]; 
									if ((ii >= 0) && (jj >= 0)) 
										this.probprob[ii][jj] += 1.0D; 
									else if (ii < 0) 
										System.out.println("symbol " + this.seq[k][i] + " is not included in 20 AAs or gap(-)"); 
										else if (jj < 0) 
											System.out.println("symbol " + this.seq[k][j] + " is not included in 20 AAs or gap(-)");  
									} 
/* 476 */           
							numnogapTmp = 1.0D / numnogap; 
							for (int ii = 0; ii < this.groupNumber; ii++) 
								for (int jj = 0; jj < this.groupNumber; jj++) 
									if (this.probprob[ii][jj] != 0.0D) { 
										//if (this.freqaa[i][ii] != 0.0D) this.freqaa[j][jj]; 
										double A = this.probprob[ii][jj] * numnogapTmp; 
										double B = this.probprob[ii][jj] * numnogap; 
										probmutuTmp[ii][jj] = probMutuCalc(A, B, this.freqaa[i][ii], this.freqaa[j][jj]); this.mutObj[this.numOfMuInCal].setMuinf(ii, jj, (float)probmutuTmp[ii][jj]);
										if (probmutuTmp[ii][jj] >= 40.0D) 
											System.out.println("numOfMuInCal =" + this.numOfMuInCal + "; i = " + i + ";  j = " + j + "; probmutuTmp[" + ii + "][" + jj + "] = " + probmutuTmp[ii][jj]); this.mutuinf[i][j] += probmutuTmp[ii][jj]; 
											}  
/* 476 */           if (this.mutuinf[i][j] > 0.0D);
/* 476 */           this.mutObj[this.numOfMuInCal].setSite1(i); 
					this.mutObj[this.numOfMuInCal].setSite2(j); 
					this.mutObj[this.numOfMuInCal].setMuinf12(this.mutuinf[i][j]); 
					this.aveMuinf += this.mutuinf[i][j]; this.numOfMuInCal += 1; 
					} 
				} 
				this.aveMuinf /= this.numOfMuInCal; 
				Arrays.sort(this.mutObj, new MutuComparator()); ArrayList max = this.mutObj[0].getMuinf(); this.maxmuinf = this.mutObj[0].getMuinf12(); this.minmuinf = this.mutObj[(this.mutObj.length - 1)].getMuinf12(); 
				System.out.println("max is between site " + (this.mutObj[0].getSite1() + 1) + "and site" + (this.mutObj[0].getSite2() + 1) + "max = " + this.maxmuinf); 
				System.out.println("min is between site " + (this.mutObj[(this.mutObj.length - 1)].getSite1() + 1) + "and site" + (this.mutObj[(this.mutObj.length - 1)].getSite2() + 1) + "min = " + this.minmuinf); 
				System.out.println("ave = " + this.aveMuinf); int rest = this.numOfMuInCal % 4; 
				for (int i = 0; i < rest; i++) 
					this.standdev += (this.mutObj[i].getMuinf12() - this.aveMuinf) * (this.mutObj[i].getMuinf12() - this.aveMuinf) / (this.numOfMuInCal - 1); 
				System.out.println("numOfMuInCal = " + this.numOfMuInCal + "; standdev = " + this.standdev); 
				for (int i = rest; i < this.numOfMuInCal; i += 4) { 
					this.standdev += (this.mutObj[(i + 0)].getMuinf12() - this.aveMuinf) * (this.mutObj[(i + 0)].getMuinf12() - this.aveMuinf) / (this.numOfMuInCal - 1); 
					this.standdev += (this.mutObj[(i + 1)].getMuinf12() - this.aveMuinf) * (this.mutObj[(i + 1)].getMuinf12() - this.aveMuinf) / (this.numOfMuInCal - 1); 
					this.standdev += (this.mutObj[(i + 2)].getMuinf12() - this.aveMuinf) * (this.mutObj[(i + 2)].getMuinf12() - this.aveMuinf) / (this.numOfMuInCal - 1); 
					this.standdev += (this.mutObj[(i + 3)].getMuinf12() - this.aveMuinf) * (this.mutObj[(i + 3)].getMuinf12() - this.aveMuinf) / (this.numOfMuInCal - 1); 
					} 
				
				this.standdev = Math.sqrt(this.standdev); 
				System.out.println("standdev = " + this.standdev); 
				double limitP1 = this.aveMuinf + this.standdev * getZvalue1(this.p1); 
				double limitP2 = this.aveMuinf + this.standdev * getZvalue2(this.p2); 
				this.ListP1 = new ArrayList();
				this.ListP2 = new ArrayList(); this.List = new ArrayList(); 
				
				int i=0;
				for (; this.mutObj[i].getMuinf12() > limitP2; i++) { 
					this.List.add(this.mutObj[i]); 
					if (this.mutObj[i].getMuinf12() > limitP1) 
						this.ListP1.add(this.mutObj[i]); 
					else this.ListP2.add(this.mutObj[i]);  
				} 
				
				this.topnum = i;
/*     */   }
/*     */ 
/*     */   public ArrayList<MutObjNew> getListP1()
/*     */   {
/* 305 */     return this.ListP1;
/*     */   }
/*     */ 
/*     */   public ArrayList<MutObjNew> getListP2() {
/* 309 */     return this.ListP2;
/*     */   }
/*     */ 
/*     */   public ArrayList<MutObjNew> getList() {
/* 313 */     return this.List;
/*     */   }
/*     */ 
/*     */   private double probMutuCalc(double A, double B, double freqaaiii, double freqaajjj)
/*     */   {
/* 318 */     return A * A * 1000.0D * Math.log(B / (freqaaiii * freqaajjj));
/*     */   }
/*     */ 
/*     */   private double getZvalue1(double pvalue1)
/*     */   {
/* 323 */     double zvalue1 = 0.0D;
/* 324 */     if (pvalue1 == 1.E-005D)
/* 325 */       zvalue1 = 4.25D;
/* 326 */     else if (pvalue1 == 5.E-005D)
/* 327 */       zvalue1 = 3.88D;
/* 328 */     else if (pvalue1 == 0.0001D)
/* 329 */       zvalue1 = 3.7D;
/* 330 */     else if (pvalue1 == 0.0005D)
/* 331 */       zvalue1 = 3.3D;
/* 332 */     else if (pvalue1 == 0.001D)
/* 333 */       zvalue1 = 3.1D;
/* 334 */     else if (pvalue1 == 0.002D)
/* 335 */       zvalue1 = 2.88D;
/* 336 */     else if (pvalue1 == 0.003D)
/* 337 */       zvalue1 = 2.75D;
/* 338 */     else if (pvalue1 == 0.004D)
/* 339 */       zvalue1 = 2.65D;
/* 340 */     else if (pvalue1 == 0.005D)
/* 341 */       zvalue1 = 2.58D;
/* 342 */     else if (pvalue1 == 0.01D)
/* 343 */       zvalue1 = 2.33D;
/* 344 */     else if (pvalue1 == 0.012D)
/* 345 */       zvalue1 = 2.26D;
/* 346 */     else if (pvalue1 == 0.014D)
/* 347 */       zvalue1 = 2.2D;
/* 348 */     else if (pvalue1 == 0.015D) {
/* 349 */       zvalue1 = 2.17D;
/*     */     }
/* 351 */     return zvalue1;
/*     */   }
/*     */ 
/*     */   private double getZvalue2(double pvalue2) {
/* 355 */     double zvalue2 = 0.0D;
/* 356 */     if (pvalue2 == 0.016D)
/* 357 */       zvalue2 = 2.14D;
/* 358 */     else if (pvalue2 == 0.017D)
/* 359 */       zvalue2 = 2.12D;
/* 360 */     else if (pvalue2 == 0.018D)
/* 361 */       zvalue2 = 2.1D;
/* 362 */     else if (pvalue2 == 0.019D)
/* 363 */       zvalue2 = 2.08D;
/* 364 */     else if (pvalue2 == 0.02D)
/* 365 */       zvalue2 = 2.06D;
/* 366 */     else if (pvalue2 == 0.03D)
/* 367 */       zvalue2 = 1.88D;
/* 368 */     else if (pvalue2 == 0.04D)
/* 369 */       zvalue2 = 1.75D;
/* 370 */     else if (pvalue2 == 0.05D) {
/* 371 */       zvalue2 = 1.65D;
/*     */     }
/* 373 */     return zvalue2;
/*     */   }
/*     */ 
/*     */   public void getMutuInfo() {
/* 377 */     for (int i = 0; i < this.residusNumber; i++)
/* 378 */       for (int j = 0; j < this.residusNumber; j++)
/* 379 */         System.out.println("i= " + i + " j = " + j + " " + 
/* 380 */           this.mutuinf[i][j]);
/*     */   }
/*     */ 
/*     */   public double getGpercent()
/*     */   {
/* 386 */     return this.gpercent;
/*     */   }
/*     */ 
/*     */   public int getResidusNumber() {
/* 390 */     return this.residusNumber;
/*     */   }
/*     */ 
/*     */   public int getNumOfMuInCal()
/*     */   {
/* 395 */     return this.numOfMuInCal;
/*     */   }
/*     */ 
/*     */   public int getNumOfLessGap()
/*     */   {
/* 400 */     return this.numOfLessGap;
/*     */   }
/*     */ 
/*     */   public int getTopnum() {
/* 404 */     return this.topnum;
/*     */   }
/*     */ 
/*     */   public MutObjNew[] getMutObj() {
/* 408 */     return this.mutObj;
/*     */   }
/*     */ 
/*     */   public void rankMuInfo() {
/* 412 */     Arrays.sort(this.mutObj, new MutuComparator());
/*     */ 
/* 416 */     this.maxmuinf = this.mutObj[0].getMuinf12();
/* 417 */     this.minmuinf = this.mutObj[(this.mutObj.length - 1)].getMuinf12();
/*     */ 
/* 419 */     System.out.println("max = " + this.maxmuinf + " min = " + this.minmuinf);
/* 420 */     System.out.println("ave = " + this.aveMuinf);
/* 421 */     System.out.println("standdev = " + this.standdev);
/*     */   }
/*     */   public static void main(String[] args) {
/*     */     try {
/* 425 */       ProbabilityCalculator pc = new ProbabilityCalculator("source/input.txt");
/*     */ 
/* 430 */       MutualInformationGroup mi = new MutualInformationGroup(pc, 0.3D, 0.01D, 0.05D);
/* 431 */       System.out
/* 432 */         .println("The number of sites used for mutuinf calculated is: " + 
/* 433 */         mi.getNumOfLessGap());
/* 434 */       System.out.println("The number of mutual information calculated is: " + 
/* 435 */         mi.getNumOfMuInCal());
/* 436 */       System.out.println("the topnum is: " + mi.getTopnum());
/* 437 */       System.out.println("P1 list = " + mi.getListP1().size());
/* 438 */       System.out.println("P2 list = " + mi.getListP2().size());
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.model.MutualInformationGroup
 * JD-Core Version:    0.6.2
 */