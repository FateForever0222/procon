package source.model;

import java.util.ArrayList;
import java.util.Arrays;

public class TripletFinder {

	/**
	 * @param args
	 */

	public TripletFinder(MutualInformation mi) {

		topnum = mi.getTopnum();
		System.out.println(" topnum =" + topnum);

		resnum = mi.getResidusNumber();
		numOfMuInCal = mi.getNumOfMuInCal();
		// System.out.println("numOfMuInCal ="+ numOfMuInCal );
		mutObj = mi.getMutObj();

		ms = new MuiSite[resnum];
		for (int i = 0; i < resnum; i++)
			ms[i] = new MuiSite();
		// System.out.println("ms["+i+"] = " + ms[i].getSizeofj());

		int[] sizeofsitej = new int[resnum];

		for (int i = 0; i < resnum; i++) {
			sizeofsitej[i] = 0;
		}

		int totalmemory = 0;

		for (int i = 0; i < topnum; i++) {
			++sizeofsitej[(int) mutObj[i].getSite1()];
			++totalmemory;
		}

		// for(int i = 0; i < sizeofsitej.length; i++)
		// System.out.println("sizeofsitej[" + i +"] = " + sizeofsitej[i]);

		initMuiSite(sizeofsitej, totalmemory);

		for (int i = 0; i < topnum; i++) {
			addms(mutObj[i].getSite1(), mutObj[i].getSite2());

		}

		int sj = 0;
		for (int i = 0; i < resnum; i++) {
			sj = ms[i].getSizeofj();
			Arrays.sort(ms[i].getSitej(), 0, ms[i].getSitej().length);
		}
		/*
		 * for(int i=0; i<resnum; i++){ System.out.println("ms["+i+"].sizeofj="
		 * + ms[i].getSizeofj());
		 * 
		 * for (int j=0; j<ms[i].getSitej().length;j++){
		 * System.out.println("ms["+i+"].sitej["+j+"]=" + ms[i].getSitej()[j]);
		 * } }
		 */

		tpsize = (int) (((resnum * resnum * resnum) - 3 * (resnum * resnum) + 2 * resnum) / 6 * 0.002);
		System.out
				.println("(allocated memory for number of triplets )tpsize = "
						+ tpsize);// ok

		tps = new ArrayList(); // not accurate

		numoftriplets = 0;
		int key;
		int esite;
		int col1 = 0, col2 = 0;
		int keytmp = 0;

		// indexes are i,j,k,l.
		// i,j pass through columns.
		// k,l pass through rows. in i column.
		// site1 is now implicitly used as the index i.

		for (int i = 0; i < resnum; i++) {
			// If there are no values in the rows of column ms[i] we do not have
			// triplets here. Continue to next column.
			if (ms[i].getSizeofj() == 0)
				continue;

			// j passes through all the columns on the right hand side of index
			// i.
			for (int j = i + 1; j < resnum; j++) {

				// k passes through the row elements of column i.
				for (int k = 0; k < ms[i].getSizeofj(); k++) {

					// System.out.println("k="+k+"; ms["+i+"].sizeofj ="
					// +ms[i].getSizeofj());

					// If element i,k matches the index j and number of rows in
					// column j are > 0 we will check for triplets.
					if (ms[i].getSitej()[k] == j && ms[j].getSizeofj() > 0) {

						// Starting to check the next element after i,k in
						// column i.
						// That is l=k+1, and loops through each element in the
						// rows of the i column.
						for (int l = k + 1; l < ms[i].getSizeofj(); l++) {

							// The key to check for is one of the elements below
							// k. or l = k+1.
							key = ms[i].getSitej()[l];

							// if(k<=1)System.out.println("k="+k+"; key = "+
							// key); //ok

							// Resetting the search area by setting topos to the
							// number of elements in column j.

							// if(k<=1)System.out.println("keytmp = " + keytmp +
							// "; key = " + key);// test for keytmp and key

							if (keytmp != key) {

								topos = ms[j].getSizeofj();

								// if(i==10&&j==11)System.out.println("k="+k+"; l="+l+"; topos="+ms[j].getSitej()[topos]);

								keytmp = key;
							}

							// Resetting search area when the i column has
							// changed.
							if (col1 != i) {
								col1 = i; // New column, point the searched
											// values to the first element in
											// the new array to be searched.
								frompos = 0; // ms[j].getSitej().length;
								// System.out.println(" i= "+i+"; j= " + j+
								// "; k= "+k+"; l= "+l+"; frompos = " +frompos);
								// //yyang test
								topos = ms[j].getSizeofj();
							}

							// Resetting search area when the j column has
							// changed.
							if (col2 != j) {
								col2 = j; // New column, point the searched
											// values to the first element in
											// the new array to be searched.
								frompos = 0; // ms[j].getSitej().length;
								topos = ms[j].getSizeofj();
							}

							// if(i<3&&j<10) System.out.println(" i= "+i+"; j= "
							// + j+ "; k= "+k+"; l= "+l+"; topos = " + topos +
							// "; frompos = " +frompos);

							pdiff = frompos; // Number of elements that has been
												// searched through.

							// Using exponential search to find the key or
							// narrow search area for Binary search.

							// if(j<=3)
							// System.out.println("i="+i+"; j="+j+"; k="+k+"; l="+l+
							// "; sitej.length = " + ms[j].getSitej().length
							// +"; pdiff = "
							// +pdiff+"; ms[j].getSizeofj()= "+ms[j].getSizeofj()+"; key="+key);

							esite = expSearch(ms[j].getSitej(), pdiff,
									ms[j].getSizeofj(), key);// ???

							// if(j<=3)
							// System.out.println("i="+i+"; j="+j+"; k="+k+"; l="+l+"; pdiff = "
							// +pdiff+"; key = "+ key +";esite = " + esite);//ok

							pdiff = frompos; // Number of elements that has been
												// searched through.
							pdiff1 = topos; // Number of elements left to search
											// for the key in.

							// If esite < 0 we have not found the element.
							// Trying binary search on the area specified by
							// expSearch.
							if (esite <= 0) {
								if (pdiff1 <= 0) { // If number of elements left
													// to search through <= 0
													// then we have notified
													// that the key cannot be
													// found in that array.
									continue;
								} else {
									esite = binSearch(ms[j].getSitej(), pdiff,
											pdiff1, key);
									// if(j<=3)
									// System.out.println("i="+i+"; j="+j+"; k="+k+"; l="+l+"; pdiff = "
									// +pdiff+"; pdiff1 = " + pdiff1+"; key = "+
									// key +";esite = " + esite);
								}
							}

							// if(j<=3)
							// System.out.println("i="+i+"; j="+j+"; k="+k+"; l="+l+"; pdiff = "
							// +pdiff+"; pdiff1 = " + pdiff1+"; key = "+ key
							// +";esite = " + esite);
							// If esite > 0 then we have found the last element
							// which is related to i, j.
							// We have found a triplet.

							if (esite > 0) {
								// System.out.println("tpsize1 = " + tpsize +
								// "numoftriplets = " + numoftriplets);
								if (numoftriplets >= (tpsize)) {
									tpsize = tpsize
											+ (int) (((resnum * resnum * resnum)
													- 3 * (resnum * resnum) + 2 * resnum) / 6 * (0.002 + (0.05 * mi
													.getGpercent())));
									System.out.println("tpsize2 = " + tpsize);

								}

								// Storing the triplet positions in the Triplet
								// datastructure.
								Triplet tp = new Triplet();
								tp.setS1((short) i);
								tp.setS2((short) j);
								tp.setS3((short) esite);

								tps.add(tp);
								numoftriplets++;
							}

						}
					}
				}
			}
		}
	}

	public void displayresult() {

		System.out.println("Attention!!!!" + "numoftriplets= " + numoftriplets);

		// for(int i = 0; i< numoftriplets; i++){
		// System.out.println("i= " + i + ";  s1= " + tp[i].getS1()+"; s2= " +
		// tp[i].getS2()+"; s3= " + tp[i].getS3());
		// }

	}

	private void initMuiSite(int[] sizeofsitej, int totalmemory) {
		int counter = 0;

		System.out.println("totalmemory = " + totalmemory);
		for (int i = 0; i < resnum; i++) {

			ms[i].setSizeofj(0);
			// System.out.println("ms["+i+"] = " + ms[i].getSizeofj());

			ms[i].initSitej(sizeofsitej[i]);

			for (int j = counter; j < sizeofsitej[i]; j++) {
				ms[i].setSitej(j, 0);
				// System.out.println("ms["+i+"].sitej["+j+"] = "+ms[i].getSitej()[j]
				// );//ok
			}
			counter += sizeofsitej[i];
		}
	}

	private void addms(int site1, int site2) {
		ms[site1].setSitej(ms[site1].getSizeofj(), site2);
		ms[site1].setSizeofj(ms[site1].getSizeofj() + 1);
	}

	// Search method that searches exponential valued indexes (0,1,2,4,8,16...)
	private int expSearch(int[] sortedArray, int first, int last, int key) {
		// sortedArray: An array of sorted integers.
		// first: The first position within the array to start the search from.
		// last: The last position to end the search at.
		// key: The value to search for within the array.

		int retval = -1;
		// j,l exponential indexes.
		int j = 0; // The current exponential index.
		int l = 0; // The previous exponential index.
		// jt, lt exponential indexes + the first position within an area to be
		// searched.
		int jt = 0; // The current exponential index + first,
		int lt = 0; // lt=previous position we have searched through.

		for (int i = first; i < last - 1; i++) {
			// l,j index, lt,jt index+first
			l = j;
			lt = j + first;
			// Start the exponential incrementation when i>first+1.
			// This means that we get the correct exponential incrementation of
			// the index.
			// if first=1, i=0 then j = j*2, where j=0;
			// if first=1, i=1 then j = j, where j=1;
			// if first=1, i=2 then j = j*2, where j=1 becoming j=2;
			// if first=1, i=3 then j = j*2, where j=2 becoming j=4;
			if (i != (first + 1)) {
				j = j << 1;
			}
			// Setting jt to the actual search index, where first is constant
			// within this scope, and j incremented by 0,1,2,4,8.
			jt = j + first;

			// Setting j=1 to start the exponential incrementation.
			if (i == first) {
				j = 1;
			}
			// Safety check, if the area to search for is invalid break
			// immediately.
			if (first > last - 1) {
				retval = -1;
				break;
			}
			// If the search index has been incremented above the upper bound we
			// have finished the search and need to exit.
			if (jt > (last - 1)) {
				retval = -1;
				break;
			}

			// If sortedArray[j] == key then we have found a key in the array
			// and will benefit from the fast search of expSearch.
			// Storing the next position where the value was found into frompos
			// for continous search of other values.
			// No information about the upper limit for next search, setting
			// topos to the length of the array.
			if (sortedArray[jt] == key) {
				retval = sortedArray[jt];
				frompos = jt + 1;
				topos = last;
				// frompos = sortedArray.length + jt + 1;
				// topos = sortedArray.length + last;
				break;
			}
			// If we have not found a match and the key is less than the current
			// array position this means we cannot find the value continuing the
			// search.
			else if (key < sortedArray[jt]) {
				// if j is zero, then we will store the last index checked into
				// frompos for further search.
				// Now we should not search this array, using the current key,
				// anymore. Knowing that no value in this array may match the
				// key.
				// To not search with binSearch, return an invalid search area
				// containing <0 elements to search through.
				if (jt == first) { // or j = 0
					retval = -1;
					frompos = first;
					topos = last;
					// frompos = sortedArray.length + first;
					// topos = sortedArray.length + last;
					break;
				}
				// if lt>first means we will need to continue the search between
				// an area 2^(i-1) and 2^i.
				// Or if the new search area does not contain any values
				if (lt > first) { // Continue with binsearch between 2^(i-1) <
									// key < 2^(i)
					retval = -1;
					// If there are positions between 2^(i-1) and 2^i.
					// Adding one position from last exponential index because
					// we already checked this position
					// Decreasing one position from current index position since
					// we checked this one already.
					if ((jt - lt) > 1) {
						frompos = lt + 1;
						topos = jt;
						// frompos = sortedArray.length + lt+1;
						// topos = sortedArray.length + jt;
						break;
					}
					// There are no elements between 2^(i-1) and (2^i) (lt and
					// jt) which has not already been searched through or does
					// not exist.
					// Setting an invalid area to search for, which will notify
					// that we do not have more elements to search for.
					else {
						frompos = first;
						topos = 0;

						// frompos = sortedArray.length + first;
						// topos = sortedArray.length;
						break;
					}
				}
			}
		}
		return retval;
	}

	/*
	 * Binary Search, searching for a key in a sorted array from position first
	 * to last
	 */
	private int binSearch(int[] sortedArray, int first, int last, int key) {
		int retval = -1;

		// int[] newArray = new int[last-first];
		// System.arraycopy(sortedArray, first, newArray, 0, last - first);

		int element = Arrays.binarySearch(sortedArray, key);

		if (element >= 0) {
			frompos = element + 1; // If a key is found, return the next
									// position not searched, to continue the
									// search from.
			retval = sortedArray[element];
		}
		return retval;
	}

	public ArrayList getTriplets() {
		return tps;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			ProbabilityCalculator pc = new ProbabilityCalculator(
					"D:/2015-8/data/HSAN/56118210.unaligned.aligned");

			MutualInformation mi = new MutualInformation(pc, 0.3, 0.01, 0.05);
			TripletFinder tf = new TripletFinder(mi);

			ArrayList tpss = tf.getTriplets();
			System.out.println("tps.length = " + tpss.size());

			for (int i = 0; i < tpss.size(); i++) {
				Triplet tp = (Triplet) tpss.get(i);
				//if (i < 100)
					System.out.println("i= " + i + ";  s1= " + tp.getS1()
							+ "; s2= " + tp.getS2() + "; s3= " + tp.getS3());

			}
			tf.displayresult();
		} catch (Exception e) {

		}
	}

	private int resnum;
	private int numOfMuInCal;
	private MutObjNew[] mutObj;
	private MuiSite[] ms;
	private int topnum;
	private int tpsize;
	private int numoftriplets;
	private int topos, frompos, pdiff, pdiff1;
	private ArrayList tps;

}
