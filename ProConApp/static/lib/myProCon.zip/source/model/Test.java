package source.model;

import java.util.ArrayList;

public class Test {
    public static void main(String[] args) throws Exception {
        ProbabilityCalculator a = new ProbabilityCalculator("D:\\ProCon\\model\\4503949.aligned");
        MutualInformation b = new MutualInformation(a, 0.3, 0.01, 0.05, true);
//            double[][] c = a.getProb6aa();
//            for(int i = 0; i < c.length; i++) {
//                for(int j = 0; j < c[i].length; j++) {
//                    System.out.println(c[i][j]);
//                }
//                System.out.println();
//        }
    }
}
