/*    */ package source.model;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.JPanel;
/*    */ import org.jfree.chart.ChartFactory;
/*    */ import org.jfree.chart.ChartPanel;
/*    */ import org.jfree.chart.JFreeChart;
/*    */ import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
/*    */ import org.jfree.chart.plot.CategoryPlot;
/*    */ import org.jfree.chart.plot.PlotOrientation;
/*    */ import org.jfree.chart.renderer.category.StackedBarRenderer;
/*    */ import org.jfree.data.category.CategoryDataset;
/*    */ import org.jfree.data.category.DefaultCategoryDataset;
/*    */ import org.jfree.ui.ApplicationFrame;
/*    */ import org.jfree.ui.RefineryUtilities;
/*    */ 
/*    */ public class StackedBarChartDemo1 extends ApplicationFrame
/*    */ {
/*    */   public StackedBarChartDemo1(String s)
/*    */   {
/* 19 */     super(s);
/* 20 */     JPanel jpanel = createDemoPanel();
/* 21 */     jpanel.setPreferredSize(new Dimension(500, 270));
/* 22 */     setContentPane(jpanel);
/*    */   }
/*    */ 
/*    */   private static CategoryDataset createDataset() {
/* 26 */     DefaultCategoryDataset defaultcategorydataset = new DefaultCategoryDataset();
/* 27 */     defaultcategorydataset.addValue(32.399999999999999D, "Series   1 ", 
/* 28 */       "Category   1 ");
/* 29 */     defaultcategorydataset.addValue(17.800000000000001D, "Series   2 ", 
/* 30 */       "Category   1 ");
/* 31 */     defaultcategorydataset.addValue(27.699999999999999D, "Series   3 ", 
/* 32 */       "Category   1 ");
/* 33 */     defaultcategorydataset.addValue(43.200000000000003D, "Series   1 ", 
/* 34 */       "Category   2 ");
/* 35 */     defaultcategorydataset.addValue(15.6D, "Series   2 ", "Category   2 ");
/* 36 */     defaultcategorydataset.addValue(18.300000000000001D, "Series   3 ", 
/* 37 */       "Category   2 ");
/* 38 */     defaultcategorydataset.addValue(23.0D, "Series   1 ", "Category   3 ");
/* 39 */     defaultcategorydataset.addValue(11.300000000000001D, "Series   2 ", 
/* 40 */       "Category   3 ");
/* 41 */     defaultcategorydataset.addValue(25.5D, "Series   3 ", "Category   3 ");
/* 42 */     defaultcategorydataset.addValue(13.0D, "Series   1 ", "Category   4 ");
/* 43 */     defaultcategorydataset.addValue(11.800000000000001D, "Series   2 ", 
/* 44 */       "Category   4 ");
/* 45 */     defaultcategorydataset.addValue(29.5D, "Series   3 ", "Category   4 ");
/* 46 */     return defaultcategorydataset;
/*    */   }
/*    */ 
/*    */   private static JFreeChart createChart(CategoryDataset categorydataset) {
/* 50 */     JFreeChart jfreechart = ChartFactory.createStackedBarChart(
/* 51 */       "Stacked   Bar   Chart   Demo   1 ", "Category ", "Value ", 
/* 52 */       categorydataset, PlotOrientation.VERTICAL, true, true, false);
/* 53 */     jfreechart.setBackgroundPaint(Color.white);
/* 54 */     CategoryPlot categoryplot = (CategoryPlot)jfreechart.getPlot();
/* 55 */     categoryplot.setBackgroundPaint(Color.lightGray);
/* 56 */     categoryplot.setRangeGridlinePaint(Color.white);
/* 57 */     StackedBarRenderer stackedbarrenderer = (StackedBarRenderer)categoryplot
/* 58 */       .getRenderer();
/* 59 */     stackedbarrenderer.setDrawBarOutline(false);
/* 60 */     stackedbarrenderer.setItemLabelsVisible(true);
/* 61 */     stackedbarrenderer.setSeriesItemLabelGenerator(0, 
/* 62 */       new StandardCategoryItemLabelGenerator());
/* 63 */     return jfreechart;
/*    */   }
/*    */ 
/*    */   public static JPanel createDemoPanel() {
/* 67 */     JFreeChart jfreechart = createChart(createDataset());
/* 68 */     return new ChartPanel(jfreechart);
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) {
/* 72 */     StackedBarChartDemo1 stackedbarchartdemo1 = new StackedBarChartDemo1(
/* 73 */       "Stacked   Bar   Chart   Demo   1 ");
/* 74 */     stackedbarchartdemo1.pack();
/* 75 */     RefineryUtilities.centerFrameOnScreen(stackedbarchartdemo1);
/* 76 */     stackedbarchartdemo1.setVisible(true);
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.model.StackedBarChartDemo1
 * JD-Core Version:    0.6.2
 */