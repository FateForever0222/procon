/*    */ package source.model;
/*    */ 
/*    */ public class RankProbpc
/*    */ {
/*    */   private double probpc;
/*    */   private char rankpc;
/*    */ 
/*    */   public void setProbpc(double probpc)
/*    */   {
/*  5 */     this.probpc = probpc;
/*    */   }
/*    */ 
/*    */   public void calProbpc(int seqNumber) {
/*  9 */     this.probpc /= seqNumber;
/*    */   }
/*    */ 
/*    */   public double getProbpc()
/*    */   {
/* 14 */     return this.probpc;
/*    */   }
/*    */ 
/*    */   public void setRankpc(char rankpc) {
/* 18 */     this.rankpc = rankpc;
/*    */   }
/*    */ 
/*    */   public char getRankpc() {
/* 22 */     return this.rankpc;
/*    */   }
/*    */ 
/*    */   public void add() {
/* 26 */     this.probpc += 1.0D;
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.model.RankProbpc
 * JD-Core Version:    0.6.2
 */