/*    */ package source.model;
/*    */ 
/*    */ public class MuiSite
/*    */ {
/*    */   private int sizeofj;
/*    */   private int[] sitej;
/*    */ 
/*    */   public void setSizeofj(int sizeofj)
/*    */   {
/* 10 */     this.sizeofj = sizeofj;
/*    */   }
/*    */ 
/*    */   public int getSizeofj() {
/* 14 */     return this.sizeofj;
/*    */   }
/*    */ 
/*    */   public int[] getSitej() {
/* 18 */     return this.sitej;
/*    */   }
/*    */ 
/*    */   public void initSitej(int length) {
/* 22 */     this.sitej = new int[length];
/*    */   }
/*    */ 
/*    */   public void setSitej(int position, int value) {
/* 26 */     this.sitej[position] = value;
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.model.MuiSite
 * JD-Core Version:    0.6.2
 */