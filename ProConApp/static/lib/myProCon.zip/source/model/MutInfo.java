/*    */ package source.model;
/*    */ 
/*    */ public class MutInfo
/*    */ {
/*    */   private int residue1;
/*    */   private int residue2;
/*    */   private float info;
/*    */ 
/*    */   public MutInfo(int residue1, int residue2, float info)
/*    */   {
/*  6 */     this.residue1 = residue1;
/*  7 */     this.residue2 = residue2;
/*  8 */     this.info = info;
/*    */   }
/*    */ 
/*    */   public void setMutInfo(int residue1, int residue2, float info) {
/* 12 */     this.residue1 = residue1;
/* 13 */     this.residue2 = residue2;
/* 14 */     this.info = info;
/*    */   }
/*    */ 
/*    */   public int getResidue1() {
/* 18 */     return this.residue1;
/*    */   }
/*    */ 
/*    */   public int getResidue2() {
/* 22 */     return this.residue2;
/*    */   }
/*    */ 
/*    */   public float getInfo() {
/* 26 */     return this.info;
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.model.MutInfo
 * JD-Core Version:    0.6.2
 */