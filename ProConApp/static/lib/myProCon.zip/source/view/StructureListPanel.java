/*     */ package source.view;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.table.TableModel;
/*     */ import source.model.MutObjNew;
/*     */ import source.model.MutualInformation;
/*     */ import source.model.ProbabilityCalculator;
/*     */ import source.model.Triplet;
/*     */ import source.model.TripletFinder;
/*     */ 
/*     */ public class StructureListPanel extends JPanel
/*     */ {
/*     */   private ProbabilityCalculator pc;
/*     */   private StructureDisplayPanel displaypanel;
/*     */   private MutualInformation mi;
/*     */   private TripletFinder tf;
/*     */   private ArrayList displaylist;
/*     */   private JTable table;
/*     */   private JScrollPane pane;
/*     */ 
/*     */   public StructureListPanel(ProbabilityCalculator pc, StructureDisplayPanel spanel)
/*     */   {
/*  29 */     this.pc = pc;
/*  30 */     this.displaypanel = spanel;
/*     */ 
/*  32 */     Object[][] rows = new Object[40][4];
/*  33 */     String[] columns = { "rank", "site1", "site2", "site3" };
/*  34 */     TableModel model = new DefaultTableModel(rows, columns);
/*  35 */     this.table = new JTable(model);
/*     */ 
/*  37 */     this.table.setPreferredScrollableViewportSize(new Dimension(200, 500));
/*     */ 
/*  39 */     Font f = new Font("Serif", 0, 10);
/*  40 */     this.table.setFont(f);
/*     */ 
/*  42 */     this.table.getTableHeader().setFont(new Font("Serif", 0, 10));
/*     */ 
/*  44 */     TableColumn column3 = this.table.getColumnModel().getColumn(3);
/*  45 */     column3.setPreferredWidth(220);
/*     */ 
/*  47 */     this.pane = new JScrollPane(this.table);
/*     */ 
/*  52 */     add(this.pane, "Center");
/*     */   }
/*     */ 
/*     */   public void setMutualInformation(MutualInformation mi)
/*     */   {
/*  57 */     this.mi = mi;
/*  58 */     this.tf = new TripletFinder(mi);
/*     */ 
/*  60 */     displayList();
/*     */   }
/*     */ 
/*     */   public ArrayList getDisplayList()
/*     */   {
/*  65 */     ArrayList displayList = new ArrayList();
/*     */ 
/*  67 */     if ((this.mi != null) && (this.tf != null))
/*     */     {
/*  69 */       MutObjNew[] mutlist = this.mi.getMutObj();
/*     */ 
/*  92 */       ArrayList tripletList = this.tf.getTriplets();
/*     */ 
/*  94 */       this.tf.displayresult();
/*     */ 
/*  96 */       boolean flag1 = true;
/*  97 */       boolean flag2 = true;
/*  98 */       boolean flag3 = true;
/*     */ 
/* 100 */       for (int i = 0; i < tripletList.size(); i++) {
/* 101 */         Triplet tp = (Triplet)tripletList.get(i);
/*     */ 
/* 103 */         int S1 = tp.getS1();
/* 104 */         int S2 = tp.getS2();
/* 105 */         int S3 = tp.getS3();
/* 106 */         flag1 = false;
/* 107 */         flag2 = false;
/* 108 */         flag3 = false;
/*     */ 
/* 110 */         for (int j = 0; j < 32; j++) {
/* 111 */           if (((S1 == mutlist[j].getSite1()) && 
/* 112 */             (S2 == mutlist[j]
/* 112 */             .getSite2())) || (
/* 113 */             (S2 == mutlist[j].getSite1()) && 
/* 114 */             (S1 == mutlist[j]
/* 114 */             .getSite2()))) {
/* 115 */             flag1 = true;
/*     */           }
/* 117 */           if (((S2 == mutlist[j].getSite1()) && 
/* 118 */             (S3 == mutlist[j]
/* 118 */             .getSite2())) || (
/* 119 */             (S3 == mutlist[j].getSite1()) && 
/* 120 */             (S2 == mutlist[j]
/* 120 */             .getSite2()))) {
/* 121 */             flag2 = true;
/*     */           }
/* 123 */           if (((S1 == mutlist[j].getSite1()) && 
/* 124 */             (S3 == mutlist[j]
/* 124 */             .getSite2())) || (
/* 125 */             (S3 == mutlist[j].getSite1()) && 
/* 126 */             (S1 == mutlist[j]
/* 126 */             .getSite2()))) {
/* 127 */             flag3 = true;
/*     */           }
/*     */         }
/* 130 */         if ((flag1) && (flag2) && (flag3)) {
/* 131 */           displayList.add(tp);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 142 */     return displayList;
/*     */   }
/*     */ 
/*     */   public void displayList()
/*     */   {
/* 147 */     this.displaylist = getDisplayList();
/*     */ 
/* 149 */     String[][] rows2 = new String[this.displaylist.size()][4];
/*     */ 
/* 151 */     for (int i = 0; i < this.displaylist.size(); i++)
/*     */     {
/* 153 */       Triplet tp = (Triplet)this.displaylist.get(i);
/*     */ 
/* 155 */       int S1 = tp.getS1();
/* 156 */       int S2 = tp.getS2();
/* 157 */       int S3 = tp.getS3();
/*     */ 
/* 162 */       rows2[i][0] = Integer.toString(i + 1);
/* 163 */       rows2[i][1] = (Integer.toString(S1 + 1) + " " + this.pc.calculateSite(S1));
/* 164 */       rows2[i][2] = (Integer.toString(S2 + 1) + " " + this.pc.calculateSite(S2));
/* 165 */       rows2[i][3] = (Integer.toString(S3 + 1) + " " + this.pc.calculateSite(S3));
/*     */     }
/*     */ 
/* 168 */     String[] columns = { "rank", "site1", "site2", "site3" };
/*     */ 
/* 170 */     TableModel model2 = new DefaultTableModel(rows2, columns) {
/*     */       public boolean isCellEditable(int row, int column) {
/* 172 */         return false;
/*     */       }
/*     */     };
/* 175 */     this.table.setModel(model2);
/*     */ 
/* 177 */     this.table.getTableHeader().setFont(new Font("Serif", 0, 10));
/*     */ 
/* 179 */     this.table.addMouseListener(new MouseAdapter() {
/*     */       public void mouseClicked(MouseEvent e) {
/* 181 */         StructureListPanel.this.tableClickActionPerformedTriplet(StructureListPanel.this.table);
/*     */       }
/*     */     });
/* 185 */     this.pane.removeAll();
/* 186 */     this.table.repaint();
/* 187 */     this.table.updateUI();
/* 188 */     this.pane = new JScrollPane(this.table);
/* 189 */     add(this.pane, "Center");
/*     */   }
/*     */ 
/*     */   public void displayMuList()
/*     */   {
/* 194 */     MutObjNew[] mutlist = this.mi.getMutObj();
/*     */ 
/* 196 */     String[][] rows = new String[40][4];
/*     */ 
/* 198 */     for (int i = 0; i < 32; i++) {
/* 199 */       rows[i][0] = Integer.toString(i + 1);
/* 200 */       rows[i][1] = 
/* 201 */         (Integer.toString(mutlist[i].getSite1() + 1) + " " + 
/* 201 */         this.pc.calculateSite(mutlist[i].getSite1()));
/* 202 */       rows[i][2] = 
/* 203 */         (Integer.toString(mutlist[i].getSite2() + 1) + " " + 
/* 203 */         this.pc.calculateSite(mutlist[i].getSite2()));
/*     */ 
/* 206 */       NumberFormat formater = 
/* 207 */         DecimalFormat.getInstance();
/* 208 */       formater.setMaximumFractionDigits(3);
/* 209 */       String rt = formater.format(mutlist[i].getMuinf12());
/* 210 */       rows[i][3] = rt;
/*     */     }
/*     */ 
/* 213 */     String[] columns = { "rank", "site1", "site2", "mutual information" };
/* 214 */     TableModel model2 = new DefaultTableModel(rows, columns) {
/*     */       public boolean isCellEditable(int row, int column) {
/* 216 */         return false;
/*     */       }
/*     */     };
/* 219 */     this.table = new JTable();
/*     */ 
/* 221 */     this.table.setPreferredScrollableViewportSize(new Dimension(200, 500));
/*     */ 
/* 223 */     Font f = new Font("Serif", 0, 10);
/* 224 */     this.table.setFont(f);
/*     */ 
/* 226 */     this.table.getTableHeader().setFont(new Font("Serif", 0, 10));
/*     */ 
/* 228 */     this.table.setModel(model2);
/*     */ 
/* 230 */     this.table.getTableHeader().setFont(new Font("Serif", 0, 10));
/*     */ 
/* 232 */     TableColumn column0 = this.table.getColumnModel().getColumn(0);
/*     */ 
/* 234 */     TableColumn column3 = this.table.getColumnModel().getColumn(3);
/* 235 */     column3.setPreferredWidth(90);
/*     */ 
/* 241 */     this.table.addMouseListener(new MouseAdapter() {
/*     */       public void mouseClicked(MouseEvent e) {
/* 243 */         StructureListPanel.this.tableClickActionPerformedMutual(StructureListPanel.this.table);
/*     */       }
/*     */     });
/* 247 */     this.table.repaint();
/* 248 */     this.table.updateUI();
/* 249 */     this.pane.removeAll();
/* 250 */     this.pane = new JScrollPane(this.table);
/* 251 */     add(this.pane, "Center");
/*     */   }
/*     */ 
/*     */   public void tableClickActionPerformedTriplet(JTable table)
/*     */   {
/* 257 */     int numRow = table.getSelectedRow();
/*     */ 
/* 259 */     Triplet tp = (Triplet)this.displaylist.get(numRow);
/*     */ 
/* 261 */     this.displaypanel.dispalyTriplet(this.pc.getActualSite(tp.getS1()), this.pc
/* 262 */       .getActualSite(tp.getS2()), this.pc.getActualSite(tp.getS3()));
/*     */   }
/*     */ 
/*     */   public void tableClickActionPerformedMutual(JTable table)
/*     */   {
/* 274 */     int numRow = table.getSelectedRow();
/*     */ 
/* 276 */     MutObjNew mo = this.mi.getMutObj()[numRow];
/*     */ 
/* 278 */     this.displaypanel.displayMutual(this.pc.getActualSite(mo.getSite1()), this.pc
/* 279 */       .getActualSite(mo.getSite2()));
/*     */   }
/*     */ 
/*     */   public void resetPc(ProbabilityCalculator pc)
/*     */   {
/* 290 */     this.pc = pc;
/* 291 */     this.table.repaint();
/*     */   }
/*     */ 
/*     */   public ProbabilityCalculator getPc() {
/* 295 */     return this.pc;
/*     */   }
/*     */ 
/*     */   public MutualInformation getMutualInformation() {
/* 299 */     return this.mi;
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.StructureListPanel
 * JD-Core Version:    0.6.2
 */