/*    */ package source.view;
/*    */ 
/*    */ import java.awt.Font;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import java.io.PrintStream;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ import source.model.ProbabilityCalculator;
/*    */ 
/*    */ public class SequenceHeadPanel extends JPanel
/*    */ {
/*    */   private MutualPanel mutualpanel;
/*    */   private SequenceFootPanel footpanel;
/*    */   private ProbabilityCalculator pc;
/*    */   private SequenceDetailPanel detailpanel;
/*    */ 
/*    */   public SequenceHeadPanel(ProbabilityCalculator pc, MutualPanel mutualpanel, SequenceDetailPanel detailpanel, SequenceFootPanel footpanel)
/*    */   {
/* 19 */     this.pc = pc;
/* 20 */     this.mutualpanel = mutualpanel;
/*    */ 
/* 22 */     this.detailpanel = detailpanel;
/* 23 */     this.footpanel = footpanel;
/*    */ 
/* 25 */     JLabel label = new JLabel(
/* 26 */       "please choose a reference sequence form the talbe list:");
/* 27 */     label.setFont(new Font("Dialog", 1, 18));
/* 28 */     add(label);
/*    */ 
/* 30 */     JButton referenceButton = new JButton(
/* 31 */       "apply current sequence as reference");
/*    */ 
/* 33 */     ReferenceAction referenceAction = new ReferenceAction();
/* 34 */     referenceButton.addActionListener(referenceAction);
/* 35 */     add(referenceButton);
/*    */   }
/*    */ 
/*    */   public void resetPc(ProbabilityCalculator pc)
/*    */   {
/* 54 */     this.pc = pc;
/*    */   }
/*    */ 
/*    */   private class ReferenceAction
/*    */     implements ActionListener
/*    */   {
/*    */     private ReferenceAction()
/*    */     {
/*    */     }
/*    */ 
/*    */     public void actionPerformed(ActionEvent arg0)
/*    */     {
/* 41 */       int reference = SequenceHeadPanel.this.detailpanel.getReference();
/*    */ 
/* 43 */       System.out.println("...reference..." + reference);
/* 44 */       SequenceHeadPanel.this.pc.setReference(reference);
/* 45 */       SequenceHeadPanel.this.footpanel.resetReference(reference);
/* 46 */       SequenceHeadPanel.this.mutualpanel.resetListPanel();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\妗��\SOD1 ���\ProCon-20121023.jar
 * Qualified Name:     source.view.SequenceHeadPanel
 * JD-Core Version:    0.6.2
 */