/*     */package source.view;

/*     */
/*     */import java.awt.BorderLayout;
/*     */
import java.awt.Dimension;
/*     */
import java.awt.Font;
/*     */
import java.awt.GridLayout;
/*     */
import java.awt.event.MouseAdapter;
/*     */
import java.awt.event.MouseEvent;
import java.io.FileOutputStream;
import java.io.OutputStream;
/*     */
import java.text.DecimalFormat;
/*     */
import java.text.NumberFormat;
/*     */
import java.util.ArrayList;
/*     */
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
/*     */
import javax.swing.JPanel;
/*     */
import javax.swing.JScrollPane;
/*     */
import javax.swing.JSeparator;
/*     */
import javax.swing.JTable;
/*     */
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
/*     */
import javax.swing.table.JTableHeader;
/*     */
import javax.swing.table.TableColumn;
/*     */
import javax.swing.table.TableColumnModel;
/*     */
import javax.swing.table.TableModel;

import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
/*     */
import source.model.MutInfo;
/*     */
import source.model.MutObjNew;
/*     */
import source.model.MutualInformation;
/*     */
import source.model.ProbabilityCalculator;

/*     */
/*     */public class MutualListPanel extends JPanel
/*     */{
	/*     */private ProbabilityCalculator pc;
	/*     */private JLabel label1;
	/*     */private JLabel label2;
	/*     */private MutualDetailPanel detailPanel;
	/*     */private MutualDiagramPanel diagramPanel;
	/*     */private MutualInformation mi;
	/*     */private JTable table1;
	/*     */private JTable table2;
	/*     */private JScrollPane pane1;
	/*     */private JScrollPane pane2;
	/*     */private MutObjNew mo;
	/*     */private ArrayList<MutObjNew> p1List;
	/*     */private ArrayList<MutObjNew> p2List;

	private javax.swing.JPopupMenu jPopupMenu_table_save1;
	private javax.swing.JMenuItem jMenuItem_save_excel1;
	private javax.swing.JPopupMenu jPopupMenu_table_save2;
	private javax.swing.JMenuItem jMenuItem_save_excel2;

	/*     */
	/*     */public MutualListPanel(ProbabilityCalculator apc,
			MutualDetailPanel detailPanel, MutualDiagramPanel diagramPanel)
	/*     */{
		/* 35 */this.pc = apc;
		/* 36 */Object[][] rows = new Object[40][4];
		/* 37 */String[] columns = { "rank", "site1", "site2",
				"mutual information" };
		/* 38 */JPanel pane = new JPanel();
		/* 39 */pane.setLayout(new GridLayout(2, 1));
		/*     */
		/* 41 */TableModel model1 = new DefaultTableModel(rows, columns);
		/*     */
		/* 43 */this.table1 = new JTable(model1);
		/*     */
		/* 45 */this.table1.setPreferredScrollableViewportSize(new Dimension(
				200, 230));
		/*     */
		/* 47 */Font f = new Font("Serif", 0, 10);
		/* 48 */this.table1.setFont(f);
		/*     */
		/* 50 */this.table1.getTableHeader().setFont(new Font("Serif", 0, 10));
		/*     */
		/* 52 */TableColumn column3 = this.table1.getColumnModel().getColumn(3);
		/* 53 */column3.setPreferredWidth(220);
		/*     */
		

		jPopupMenu_table_save1 = new javax.swing.JPopupMenu();
		jMenuItem_save_excel1 = new javax.swing.JMenuItem();
		jMenuItem_save_excel1.setText("Save as Excel");
		jMenuItem_save_excel1.addActionListener(new java.awt.event.ActionListener() {
		    public void actionPerformed(java.awt.event.ActionEvent evt) {
		        jMenuItem_save_excelActionPerformed1(evt);
		    }
		});
		jPopupMenu_table_save1.add(jMenuItem_save_excel1);
		table1.setComponentPopupMenu(jPopupMenu_table_save1);

		
		/* 55 */this.pane1 = new JScrollPane(this.table1);
		/*     */
		/* 59 */this.label1 = new JLabel("covariant pairs (p < "+ this.pc.getPValue1() + " )");
		/* 60 */JPanel panel1 = new JPanel();
		/* 61 */panel1.setLayout(new BorderLayout());
		/* 62 */panel1.add(this.label1, "North");
		/* 63 */panel1.add(this.pane1, "Center");
		/*     */
		/* 65 */JSeparator s = new JSeparator(0);
		/* 66 */Dimension ps = s.getPreferredSize();
		/* 67 */s.setPreferredSize(new Dimension(ps.width, 20));
		/* 68 */panel1.add(s, "South");
		/*     */
		/* 70 */pane.add(panel1);
		/*     */
		/* 72 */TableModel model2 = new DefaultTableModel(rows, columns);
		/*     */
		/* 74 */this.table2 = new JTable(model2);
		/*     */
		/* 76 */this.table2.setPreferredScrollableViewportSize(new Dimension(
				200, 230));
		/*     */
		/* 78 */this.table2.setFont(f);
		/*     */
		/* 80 */this.table2.getTableHeader().setFont(new Font("Serif", 0, 10));
		/*     */
		/* 82 */column3 = this.table2.getColumnModel().getColumn(3);
		/*     */
		/* 84 */column3.setPreferredWidth(220);
		
		jPopupMenu_table_save2 = new javax.swing.JPopupMenu();
		jMenuItem_save_excel2 = new javax.swing.JMenuItem();
		jMenuItem_save_excel2.setText("Save as Excel");
		jMenuItem_save_excel2.addActionListener(new java.awt.event.ActionListener() {
		    public void actionPerformed(java.awt.event.ActionEvent evt) {
		        jMenuItem_save_excelActionPerformed2(evt);
		    }
		});
		jPopupMenu_table_save2.add(jMenuItem_save_excel2);
		table2.setComponentPopupMenu(jPopupMenu_table_save2);
		/*     */
		/* 86 */this.pane2 = new JScrollPane(this.table2);
		/*     */
		/* 89 */this.label2 = new JLabel("covariant pairs (p = "
				+ this.pc.getPValue1() + " ~ " +
				/* 90 */this.pc.getPValue2() + " )");
		/* 91 */JPanel panel2 = new JPanel();
		/* 92 */panel2.setLayout(new BorderLayout());
		/* 93 */panel2.add(this.label2, "North");
		/* 94 */panel2.add(this.pane2, "Center");
		/* 95 */pane.add(panel2);
		/*     */
		/* 97 */add(pane, "Center");
		/*     */
		/* 99 */this.detailPanel = detailPanel;
		/* 100 */this.diagramPanel = diagramPanel;
		/*     */}

	/*     */
	/*     */public void resetList()
	/*     */{
		/* 108 */this.p1List = this.mi.getListP1();
		/* 109 */this.p2List = this.mi.getListP2();
		/*  !!!!!NEW   */ int length = this.p1List.size();
		if (this.p1List.size()>4000) length =4000;
		/* 111 */String[][] rows1 = new String[length ][4];//+1
		
		/* 113 */for (int i = 0; i < length; i++) {
			/* 114 */rows1[i][0] = Integer.toString(i + 1);
			/*     */
			/* 118 */rows1[i][1] =
			/* 119 */(Integer.toString(((MutObjNew) this.p1List.get(i))
					.getSite1() + 1) + " " +
			/* 119 */this.pc.calculateSite(((MutObjNew) this.p1List.get(i))
					.getSite1()));
			/* 120 */rows1[i][2] =
			/* 121 */(Integer.toString(((MutObjNew) this.p1List.get(i))
					.getSite2() + 1) + " " +
			/* 121 */this.pc.calculateSite(((MutObjNew) this.p1List.get(i))
					.getSite2()));
			/*     */
			/* 125 */NumberFormat formater =
			/* 126 */DecimalFormat.getInstance();
			/* 127 */formater.setMaximumFractionDigits(3);
			/* 128 */String rt = formater.format(((MutObjNew) this.p1List
					.get(i)).getMuinf12());
			/* 129 */rows1[i][3] = rt;
			/*     */}
		/*     */
		/* 132 */String[] columns = { "rank", "site1", "site2",
				"mutual information" };
		/* 133 */TableModel model1 = new DefaultTableModel(rows1, columns) {
			/*     */public boolean isCellEditable(int row, int column) {
				/* 135 */return false;
				/*     */}
			/*     */
		};
		/* 138 */this.table1.setModel(model1);
		/*     */
		/* 140 */this.table1.getTableHeader().setFont(new Font("Serif", 0, 10));
		/*     */
		/* 142 */TableColumn column0 = this.table1.getColumnModel()
				.getColumn(0);
		/* 143 */column0.setPreferredWidth(30);
		/*     */
		/* 145 */TableColumn column3 = this.table1.getColumnModel()
				.getColumn(3);
		/* 146 */column3.setPreferredWidth(90);
		/*     */
		/* 148 */this.table1.addMouseListener(new MouseAdapter() {
			/*     */public void mouseClicked(MouseEvent e) {
				/* 150 */MutualListPanel.this.tableClickActionPerformed(
						MutualListPanel.this.table1, 1);
				/*     */}
			/*     */
		});
		/* 158 */this.table1.repaint();
		/* 159 */this.table1.updateUI();
		
		
		/*    NEW!!! */ int length2 = this.p2List.size();
	    if(this.p2List.size()>4000) length2 =4000;
		/* 162 */String[][] rows2 = new String[length2][4];
		
		/* 164 */for (int i = 0; i <length2; i++) {
			/* 165 */rows2[i][0] = Integer.toString(i + 1);
			/*     */
			/* 170 */rows2[i][1] =
			/* 171 */(Integer.toString(((MutObjNew) this.p2List.get(i))
					.getSite1() + 1) + " " +
			/* 171 */this.pc.calculateSite(((MutObjNew) this.p2List.get(i))
					.getSite1()));
			/* 172 */rows2[i][2] =
			/* 173 */(Integer.toString(((MutObjNew) this.p2List.get(i))
					.getSite2() + 1) + " " +
			/* 173 */this.pc.calculateSite(((MutObjNew) this.p2List.get(i))
					.getSite2()));
			/*     */
			/* 176 */NumberFormat formater =
			/* 177 */DecimalFormat.getInstance();
			/* 178 */formater.setMaximumFractionDigits(3);
			/* 179 */String rt = formater.format(((MutObjNew) this.p2List
					.get(i)).getMuinf12());
			/* 180 */rows2[i][3] = rt;
			/*     */}
		/*     */
		/* 185 */TableModel model2 = new DefaultTableModel(rows2, columns) {
			/*     */public boolean isCellEditable(int row, int column) {
				/* 187 */return false;
				/*     */}
			/*     */
		};
		/* 190 */this.table2.setModel(model2);
		/*     */
		/* 192 */this.table2.getTableHeader().setFont(new Font("Serif", 0, 10));
		/*     */
		/* 194 */column0 = this.table2.getColumnModel().getColumn(0);
		/* 195 */column0.setPreferredWidth(30);
		/*     */
		/* 197 */column3 = this.table2.getColumnModel().getColumn(3);
		/* 198 */column3.setPreferredWidth(90);
		/*     */
		/* 200 */this.table2.addMouseListener(new MouseAdapter() {
			/*     */public void mouseClicked(MouseEvent e) {
				/* 202 */MutualListPanel.this.tableClickActionPerformed(
						MutualListPanel.this.table2, 2);
				/*     */}
			/*     */
		});
		/* 210 */this.table2.repaint();
		/* 211 */this.table2.updateUI();
		/*     */}

	/*     */
	/*     */public void tableClickActionPerformed(JTable table, int pflag)
	/*     */{
		/* 216 */int numRow = table.getSelectedRow();
		/*     */
		/* 218 */if (pflag == 1)
			/* 219 */this.mo = ((MutObjNew) this.mi.getListP1().get(numRow));
		/*     */else {
			/* 221 */this.mo = ((MutObjNew) this.mi.getListP2().get(numRow));
			/*     */}
		/* 223 */float[][] detail = new float[20][20];
		/* 224 */ArrayList muinfo = this.mo.getMuinf();
		/*     */
		/* 226 */for (int i = 0; i < muinfo.size(); i++) {
			/* 227 */MutInfo mif = (MutInfo) muinfo.get(i);
			/* 228 */detail[mif.getResidue1()][mif.getResidue2()] = mif
					.getInfo();
			/*     */}
		/*     */
		/* 234 */this.detailPanel.resetTable(detail);
		/* 235 */double max = ((MutObjNew) this.p1List.get(0)).getMuinf12();
		/* 236 */this.diagramPanel.resetDetail(this.mo, max);
		/* 237 */this.diagramPanel.repaint();
		/*     */}

	/*     */
	/*     */public void resetPc(ProbabilityCalculator apc)
	/*     */{
		/* 248 */this.pc = apc;
		/* 249 */this.label1.setText("covariant pairs (p < "
				+ this.pc.getPValue1() + " )");
		/* 250 */this.label2.setText("covariant pairs (p = "
				+ this.pc.getPValue1() + " ~ " +
				/* 251 */this.pc.getPValue2() + " )");
		/*     */}

	/*     */
	/*     */public void setMutualInformation(MutualInformation mi)
	/*     */{
		/* 256 */this.mi = mi;
		/* 257 */this.diagramPanel.resetMutualInformation(mi);
		/* 258 */this.detailPanel.resetMutualInformation(mi, this.pc);
		/*     */}

	/*     */
	/*     */public MutualInformation getMutualInformation() {
		/* 262 */return this.mi;
		/*     */}
	
	
	public void create_excel(String outputFile,JTable in_table)
	{
	   TableModel tablemodel =  in_table.getModel();
	   int colcount = tablemodel.getColumnCount();
	   int rowcount = tablemodel.getRowCount();
	   String title[] = new String[colcount];
	   for(int i=0;i<colcount;i++)
	     title[i] = tablemodel.getColumnName(i);

	  if(!outputFile.contains(".xls")&&!outputFile.contains(".xlsx"))
	       outputFile += ".xls";
	  String targetfile = outputFile;// �����excel�ļ���
	  System.out.println(targetfile);
	String worksheet = "List";// �����excel�ļ���������
	WritableWorkbook workbook = null;
	try {
	OutputStream os=new FileOutputStream(targetfile);
	workbook=Workbook.createWorkbook(os);
	WritableSheet sheet = workbook.createSheet(worksheet, 0); // ���ӵ�һ��������
	jxl.write.Label label = null;
	for (int i=0; i<title.length; i++){
	// Label(�к�,�к� ,���� )
	label = new jxl.write.Label(i, 0, title[i]); //�ѱ���ŵ���һ��
	sheet.addCell(label);
	}
	for(int i=0;i<rowcount;i++)
	   for(int j=0;j<colcount;j++)
	    {
	        //data[i][j] = tablemodel.getValueAt(i, j).toString();
	       label = new jxl.write.Label(j, i+1,  tablemodel.getValueAt(i, j).toString()); //j col,i+1 row
	       System.out.println(label+"\n");
	       sheet.addCell(label);
	     }

	workbook.write();
	workbook.close();
	os.close();
	}
	catch (Exception e) {
	e.printStackTrace();
	}

	}

	private void jMenuItem_save_excelActionPerformed1(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_save_execlActionPerformed
	    // TODO add your handling code here:
	    JFileChooser jfilechooser = new JFileChooser();
	    jfilechooser.setDialogType(JFileChooser.SAVE_DIALOG);
	    FileNameExtensionFilter filter = new FileNameExtensionFilter("xls","xlsx");
	    jfilechooser.setFileFilter(filter);
	    //jfilechooser.set
	    jfilechooser.showSaveDialog(null);
	    if(jfilechooser.getSelectedFile().exists())
	    {
	           int choose= JOptionPane.showConfirmDialog(null, "The file did exist!","OOPS",JOptionPane.OK_CANCEL_OPTION);
	            //this.jTextField_batch_file.setForeground(Color.red);
	           if(choose == JOptionPane.YES_OPTION)
	               create_excel(jfilechooser.getSelectedFile().getPath(),this.table1);
	           else
	            return;
	    }
	    else
	    {
	        //File file = jfilechooser.getSelectedFile();
	        create_excel(jfilechooser.getSelectedFile().getPath(),this.table1);
	    }


	}
	
	
	private void jMenuItem_save_excelActionPerformed2(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_save_execlActionPerformed
	    // TODO add your handling code here:
	    JFileChooser jfilechooser = new JFileChooser();
	    jfilechooser.setDialogType(JFileChooser.SAVE_DIALOG);
	    FileNameExtensionFilter filter = new FileNameExtensionFilter("xls","xlsx");
	    jfilechooser.setFileFilter(filter);
	    //jfilechooser.set
	    jfilechooser.showSaveDialog(null);
	    if(jfilechooser.getSelectedFile().exists())
	    {
	           int choose= JOptionPane.showConfirmDialog(null, "The file did exist!","OOPS",JOptionPane.OK_CANCEL_OPTION);
	            //this.jTextField_batch_file.setForeground(Color.red);
	           if(choose == JOptionPane.YES_OPTION)
	               create_excel(jfilechooser.getSelectedFile().getPath(),this.table2);
	           else
	            return;
	    }
	    else
	    {
	        //File file = jfilechooser.getSelectedFile();
	        create_excel(jfilechooser.getSelectedFile().getPath(),this.table2);
	    }


	}
	/*     */
}

