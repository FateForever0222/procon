/*    */ package source.view;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import javax.swing.JPanel;
/*    */ import source.model.ProbabilityCalculator;
/*    */ 
/*    */ public class SequencePanel extends JPanel
/*    */ {
/*    */   private MutualPanel mutualpanel;
/*    */   private ProbabilityCalculator pc;
/*    */   private SequenceHeadPanel headpanel;
/*    */   private SequenceListPanel listpanel;
/*    */   private SequenceDetailPanel detailPanel;
/*    */   private SequenceFootPanel footpanel;
/*    */ 
/*    */   public SequencePanel(MutualPanel mutualpanel, ProbabilityCalculator pc)
/*    */   {
/* 11 */     this.mutualpanel = mutualpanel;
/*    */ 
/* 13 */     this.pc = pc;
/* 14 */     this.detailPanel = new SequenceDetailPanel();
/* 15 */     this.listpanel = new SequenceListPanel(this.detailPanel);
/* 16 */     this.footpanel = new SequenceFootPanel(pc);
/* 17 */     this.headpanel = new SequenceHeadPanel(pc, mutualpanel, this.detailPanel, 
/* 18 */       this.footpanel);
/*    */ 
/* 20 */     setLayout(new BorderLayout());
/* 21 */     add(this.listpanel, "West");
/* 22 */     add(this.detailPanel, "Center");
/* 23 */     add(this.headpanel, "North");
/* 24 */     add(this.footpanel, "South");
/*    */   }
/*    */ 
/*    */   public void resetPc(ProbabilityCalculator pc) {
/* 28 */     this.pc = pc;
/* 29 */     this.listpanel.resetList(pc);
/* 30 */     this.headpanel.resetPc(pc);
/* 31 */     this.detailPanel.repaint();
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.SequencePanel
 * JD-Core Version:    0.6.2
 */