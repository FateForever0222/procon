/*    */ package source.view;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Component;
/*    */ import java.awt.Frame;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JDialog;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JRootPane;
/*    */ import javax.swing.JTextField;
/*    */ import javax.swing.SwingUtilities;
/*    */ import source.model.ProbabilityCalculator;
/*    */ 
/*    */ public class GapPercentChooser extends JPanel
/*    */ {
/*    */   private boolean ok;
/*    */   private ProbabilityCalculator pc;
/*    */   private JTextField gappercent;
/*    */   private JButton okButton;
/*    */   private JDialog dialog;
/*    */ 
/*    */   public GapPercentChooser(ProbabilityCalculator pc)
/*    */   {
/* 20 */     this.pc = pc;
/* 21 */     setLayout(new BorderLayout());
/*    */ 
/* 23 */     JPanel panel = new JPanel();
/* 24 */     JLabel label = new JLabel();
/* 25 */     label.setText("current gap percentage is " + pc.getGapPercent() * 100.0D + 
/* 26 */       "%, Please input a new gap percentage");
/* 27 */     panel.add(label);
/* 28 */     panel.add(this.gappercent = new JTextField("10", 3));
/*    */ 
/* 30 */     panel.add(new JLabel("% "));
/* 31 */     add(panel, "Center");
/*    */ 
/* 33 */     this.okButton = new JButton("Apply");
/* 34 */     this.okButton.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent arg0) {
/* 37 */         GapPercentChooser.this.ok = true;
/* 38 */         GapPercentChooser.this.dialog.setVisible(false);
/*    */       }
/*    */     });
/* 43 */     JButton cancelButton = new JButton("Cancel");
/* 44 */     cancelButton.addActionListener(new ActionListener()
/*    */     {
/*    */       public void actionPerformed(ActionEvent arg0) {
/* 47 */         GapPercentChooser.this.dialog.setVisible(false);
/*    */       }
/*    */     });
/* 52 */     JPanel buttonPanel = new JPanel();
/* 53 */     buttonPanel.add(this.okButton);
/* 54 */     buttonPanel.add(cancelButton);
/* 55 */     add(buttonPanel, "South");
/*    */   }
/*    */ 
/*    */   public double getGapPercent()
/*    */   {
/* 60 */     String pString = this.gappercent.getText();
/* 61 */     return Double.parseDouble(pString) / 100.0D;
/*    */   }
/*    */ 
/*    */   public boolean showDialog(Component parent, String title) {
/* 65 */     this.ok = false;
/*    */ 
/* 67 */     Frame owner = null;
/* 68 */     if ((parent instanceof Frame))
/* 69 */       owner = (Frame)parent;
/*    */     else {
/* 71 */       owner = (Frame)SwingUtilities.getAncestorOfClass(Frame.class, 
/* 72 */         parent);
/*    */     }
/* 74 */     if ((this.dialog == null) || (this.dialog.getOwner() != owner)) {
/* 75 */       this.dialog = new JDialog(owner, true);
/* 76 */       this.dialog.add(this);
/* 77 */       this.dialog.getRootPane().setDefaultButton(this.okButton);
/* 78 */       this.dialog.pack();
/*    */     }
/*    */ 
/* 81 */     this.dialog.setLocation(250, 300);
/* 82 */     this.dialog.setTitle(title);
/* 83 */     this.dialog.setVisible(true);
/*    */ 
/* 85 */     return this.ok;
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.GapPercentChooser
 * JD-Core Version:    0.6.2
 */