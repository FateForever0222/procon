/*     */ package source.view;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.font.TextAttribute;
/*     */ import java.util.HashMap;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import source.controller.RunBrowser;
/*     */ 
/*     */ public class InfoPanel extends JPanel
/*     */ {
/*     */   public InfoPanel()
/*     */   {
/*  32 */     setLayout(new BorderLayout());
/*     */ 
/*  34 */     JPanel contentPanel = new JPanel();
/*  35 */     contentPanel.setLayout(new GridLayout(15, 1));
/*  36 */     contentPanel.add(new JLabel());
/*     */ 
/*  38 */     JLabel titleLabel = new JLabel();
/*  39 */     titleLabel.setFont(new Font("Dialog", 1, 18));
/*  40 */     titleLabel.setText("ProCon Version 2.0 - for Protein Conservation analysis");
/*  41 */     contentPanel.add(titleLabel);
/*     */ 
/*  44 */     JLabel authorLabel = new JLabel();
/*  45 */     authorLabel.setFont(new Font("Dialog", 0, 12));
/*  46 */     authorLabel.setText("Authors: Yang Yang, Andre Norrgard, Mats Aspnas, Jan Westerholm, Mauno Vihinen,and Bairong Shen");
/*  47 */     contentPanel.add(authorLabel);
/*     */ 
/*  50 */     JLabel dateLabel = new JLabel();
/*  51 */     dateLabel.setFont(new Font("Dialog", 0, 12));
/*  52 */     dateLabel.setText("Latest Release Date: Oct, 2015");
/*  53 */     contentPanel.add(dateLabel);
/*     */ 
/*  55 */     JLabel label1 = new JLabel("Visit our website in Soochow University, China:");
/*  56 */    // contentPanel.add(label1);
/*     */ 
/*  58 */     HashMap hm = new HashMap();
/*  59 */     hm.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
/*  60 */     hm.put(TextAttribute.SIZE, Integer.valueOf(12));
/*  61 */     hm.put(TextAttribute.FAMILY, "Dialog");
/*  62 */     Font font = new Font(hm);
/*     */ 
/*  65 */     JLabel linkLabel = new JLabel();
/*  66 */     linkLabel.setFont(font);
/*  67 */     linkLabel.setForeground(Color.BLUE);
/*  68 */     //linkLabel.setText("http://www.sysbio.org.cn/tools/procon.htm");
/*     */ 
/*  70 */     setCursor(new Cursor(12));
/*  71 */     linkLabel.addMouseListener(new MouseAdapter() {
/*     */       public void mouseClicked(MouseEvent e) {
/*     */         try {
/*  74 */           new RunBrowser().runBroswer("http://www.sysbio.org.cn/tools/procon.htm");
/*     */         } catch (Exception ex) {
/*  76 */           ex.printStackTrace();
/*     */         }
/*     */       }
/*     */     });
/*  81 */     contentPanel.add(linkLabel);
/*     */ 
/*  84 */     JLabel label2 = new JLabel("Another mirror is available in University of Tampere, Finland: ");
/*  85 */     //contentPanel.add(label2);
/*     */ 
/*  88 */     JLabel IMTlinkLabel = new JLabel("http://bioinf.uta.fi/ProCon/");
/*  89 */     IMTlinkLabel.setFont(font);
/*  90 */     IMTlinkLabel.setForeground(Color.BLUE);
/*     */ 
/*  93 */     IMTlinkLabel.addMouseListener(new MouseAdapter() {
/*     */       public void mouseClicked(MouseEvent e) {
/*     */         try {
/*  96 */           new RunBrowser().runBroswer("http://bioinf.uta.fi/ProCon/");
/*     */         } catch (Exception ex) {
/*  98 */           ex.printStackTrace();
/*     */         }
/*     */       }
/*     */     });
/* 103 */     //contentPanel.add(IMTlinkLabel);
/*     */ 
/* 106 */     JLabel contactLabel = new JLabel();
/* 107 */     contactLabel.setFont(new Font("Dialog", 0, 12));
/* 108 */     contactLabel.setText("Email: yyang@suda.edu.cn");
/* 109 */     contentPanel.add(contactLabel);
/*     */ 
/* 111 */     contentPanel.add(new JLabel());
/*     */ 
/* 114 */     JLabel sudaLabel = new JLabel();
/* 115 */     sudaLabel.setPreferredSize(new Dimension(300, 30));
/* 116 */     sudaLabel.setFont(new Font("Dialog", 0, 12));
/* 117 */     sudaLabel.setHorizontalAlignment(2);
/*     */ 
/* 119 */     sudaLabel.setText("Center for Systems Biology, Soochow University, Suzhou, China ");
/* 120 */     sudaLabel.setHorizontalAlignment(0);
/*     */ 
/* 122 */     contentPanel.add(sudaLabel);
/*     */ 
/* 125 */     JLabel imtLabel = new JLabel();
/* 126 */     imtLabel.setFont(new Font("Dialog", 0, 12));
/* 127 */     imtLabel.setHorizontalAlignment(2);
/* 128 */     imtLabel.setText("I Protein Structure and Bioinformatics Group, Lund University, Sweden ");
/* 129 */     imtLabel.setHorizontalAlignment(0);
/* 130 */     contentPanel.add(imtLabel);
/*     */ 
/* 133 */     add("Center", contentPanel);
/*     */ 
/* 135 */     LogoPanel logopanel = new LogoPanel();
/*     */ 
/* 137 */     logopanel.setPreferredSize(new Dimension(300, 200));
/*     */ 
/* 139 */     add("West", logopanel);
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.InfoPanel
 * JD-Core Version:    0.6.2
 */