/*     */ package source.view;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Frame;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRootPane;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.SwingUtilities;
/*     */ 
/*     */ public class GroupNameChooser extends JPanel
/*     */ {
/*     */   private int groupnumber;
/*     */   private JTextField[] groupnamesfield;
/*     */   private JButton okButton;
/*     */   private JButton cancelButton;
/*     */   private boolean ok;
/*     */   private JDialog dialog;
/*     */ 
/*     */   public GroupNameChooser(int number)
/*     */   {
/*  22 */     this.groupnumber = number;
/*  23 */     setLayout(new BorderLayout());
/*     */ 
/*  25 */     JPanel panel = new JPanel();
/*  26 */     panel.setLayout(new GridLayout(this.groupnumber, 2));
/*     */ 
/*  28 */     this.groupnamesfield = new JTextField[this.groupnumber];
/*     */ 
/*  30 */     for (int i = 0; i < this.groupnumber; i++) {
/*  31 */       panel.add(new JLabel("group " + Integer.toString(i + 1) + " name:", 0));
/*  32 */       this.groupnamesfield[i] = new JTextField(20);
/*  33 */       panel.add(this.groupnamesfield[i]);
/*     */     }
/*     */ 
/*  36 */     add(panel, "Center");
/*     */ 
/*  38 */     this.okButton = new JButton("apply");
/*  39 */     this.okButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent event)
/*     */       {
/*  43 */         GroupNameChooser.this.ok = true;
/*  44 */         GroupNameChooser.this.dialog.setVisible(false);
/*     */       }
/*     */     });
/*  50 */     this.cancelButton = new JButton("cancel");
/*  51 */     this.cancelButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent event)
/*     */       {
/*  56 */         GroupNameChooser.this.dialog.setVisible(false);
/*     */       }
/*     */     });
/*  62 */     JPanel buttonPanel = new JPanel();
/*  63 */     buttonPanel.add(this.okButton);
/*  64 */     buttonPanel.add(this.cancelButton);
/*  65 */     add(buttonPanel, "South");
/*     */   }
/*     */ 
/*     */   public String[] getGroupNames()
/*     */   {
/*  71 */     String[] groupnames = new String[this.groupnumber];
/*  72 */     for (int i = 0; i < this.groupnumber; i++) {
/*  73 */       if (!this.groupnamesfield[i].getText().equals(""))
/*  74 */         groupnames[i] = this.groupnamesfield[i].getText();
/*  75 */       else groupnames[i] = ("group " + Integer.toString(i + 1));
/*     */     }
/*  77 */     return groupnames;
/*     */   }
/*     */ 
/*     */   public boolean showDialog(Component parent, String title) {
/*  81 */     this.ok = false;
/*     */ 
/*  83 */     Frame owner = null;
/*     */ 
/*  85 */     if ((parent instanceof Frame)) {
/*  86 */       owner = (Frame)parent;
/*     */     }
/*     */     else {
/*  89 */       owner = (Frame)SwingUtilities.getAncestorOfClass(Frame.class, 
/*  90 */         parent);
/*     */     }
/*     */ 
/*  93 */     this.dialog = new JDialog(owner, true);
/*  94 */     this.dialog.add(this);
/*  95 */     this.dialog.getRootPane().setDefaultButton(this.okButton);
/*  96 */     this.dialog.pack();
/*     */ 
/*  99 */     this.dialog.setLocation(250, 200);
/* 100 */     this.dialog.setTitle(title);
/* 101 */     this.dialog.setVisible(true);
/*     */ 
/* 103 */     return this.ok;
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.GroupNameChooser
 * JD-Core Version:    0.6.2
 */