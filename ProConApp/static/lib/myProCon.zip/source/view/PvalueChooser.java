/*     */ package source.view;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Frame;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRootPane;
/*     */ import javax.swing.SwingUtilities;
/*     */ import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class PvalueChooser extends JPanel
/*     */ {
/*     */   private boolean ok;
/*     */   private ProbabilityCalculator pc;
/*     */   private JComboBox pvalue1;
/*     */   private JComboBox pvalue2;
/*     */   private JButton okButton;
/*     */   private JDialog dialog;
/*     */ 
/*     */   public PvalueChooser(ProbabilityCalculator pc)
/*     */   {
/*  23 */     this.pc = pc;
/*     */ 
/*  25 */     setLayout(new BorderLayout());
/*     */ 
/*  27 */     JPanel panel = new JPanel();
/*     */ 
/*  29 */     panel.setLayout(new GridLayout(2, 2));
/*     */ 
/*  31 */     JLabel labelp1 = new JLabel();
/*  32 */     labelp1.setText("current p1 value is " + pc.getPValue1() + 
/*  33 */       ", please input a new p1 value: ");
/*     */ 
/*  35 */     panel.add(labelp1);
/*     */ 
/*  37 */     this.pvalue1 = new JComboBox();
/*  38 */     this.pvalue1.addItem("0.00001");
/*  39 */     this.pvalue1.addItem("0.00005");
/*  40 */     this.pvalue1.addItem("0.0001");
/*  41 */     this.pvalue1.addItem("0.0005");
/*  42 */     this.pvalue1.addItem("0.001");
/*  43 */     this.pvalue1.addItem("0.002");
/*  44 */     this.pvalue1.addItem("0.003");
/*  45 */     this.pvalue1.addItem("0.004");
/*  46 */     this.pvalue1.addItem("0.005");
/*  47 */     this.pvalue1.addItem("0.010");
/*  48 */     this.pvalue1.addItem("0.012");
/*  49 */     this.pvalue1.addItem("0.014");
/*  50 */     this.pvalue1.addItem("0.015");
/*     */ 
/*  52 */     panel.add(this.pvalue1);
/*     */ 
/*  54 */     JLabel labelp2 = new JLabel();
/*  55 */     labelp2.setText("current p2 value is " + pc.getPValue2() + 
/*  56 */       ", please input a new p2 value: ");
/*     */ 
/*  58 */     panel.add(labelp2);
/*     */ 
/*  60 */     this.pvalue2 = new JComboBox();
/*  61 */     this.pvalue2.addItem("0.017");
/*  62 */     this.pvalue2.addItem("0.018");
/*  63 */     this.pvalue2.addItem("0.019");
/*  64 */     this.pvalue2.addItem("0.020");
/*  65 */     this.pvalue2.addItem("0.030");
/*  66 */     this.pvalue2.addItem("0.040");
/*  67 */     this.pvalue2.addItem("0.050");
/*     */ 
/*  69 */     panel.add(this.pvalue2);
/*     */ 
/*  71 */     add(panel, "Center");
/*     */ 
/*  73 */     this.okButton = new JButton("Apply");
/*  74 */     this.okButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0) {
/*  77 */         PvalueChooser.this.ok = true;
/*  78 */         PvalueChooser.this.dialog.setVisible(false);
/*     */       }
/*     */     });
/*  83 */     JButton cancelButton = new JButton("Cancel");
/*  84 */     cancelButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0) {
/*  87 */         PvalueChooser.this.dialog.setVisible(false);
/*     */       }
/*     */     });
/*  92 */     JPanel buttonPanel = new JPanel();
/*  93 */     buttonPanel.add(this.okButton);
/*  94 */     buttonPanel.add(cancelButton);
/*  95 */     add(buttonPanel, "South");
/*     */   }
/*     */ 
/*     */   public double getPvalue1()
/*     */   {
/* 100 */     String pString = (String)this.pvalue1.getSelectedItem();
/* 101 */     return Double.parseDouble(pString);
/*     */   }
/*     */ 
/*     */   public double getPvalue2() {
/* 105 */     String pString = (String)this.pvalue2.getSelectedItem();
/* 106 */     return Double.parseDouble(pString);
/*     */   }
/*     */ 
/*     */   public boolean showDialog(Component parent, String title) {
/* 110 */     this.ok = false;
/*     */ 
/* 112 */     Frame owner = null;
/* 113 */     if ((parent instanceof Frame))
/* 114 */       owner = (Frame)parent;
/*     */     else {
/* 116 */       owner = (Frame)SwingUtilities.getAncestorOfClass(Frame.class, 
/* 117 */         parent);
/*     */     }
/* 119 */     if ((this.dialog == null) || (this.dialog.getOwner() != owner)) {
/* 120 */       this.dialog = new JDialog(owner, true);
/* 121 */       this.dialog.add(this);
/* 122 */       this.dialog.getRootPane().setDefaultButton(this.okButton);
/* 123 */       this.dialog.pack();
/*     */     }
/*     */ 
/* 126 */     this.dialog.setLocation(250, 300);
/* 127 */     this.dialog.setTitle(title);
/* 128 */     this.dialog.setVisible(true);
/*     */ 
/* 130 */     return this.ok;
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.PvalueChooser
 * JD-Core Version:    0.6.2
 */