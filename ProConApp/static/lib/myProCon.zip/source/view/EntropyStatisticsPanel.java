/*     */ package source.view;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.PrintStream;
/*     */ import java.text.DecimalFormat;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class EntropyStatisticsPanel extends JPanel
/*     */ {
/*     */   private JRadioButton a20Button;
/*     */   private JRadioButton a6Button;
/*     */   private ProbabilityCalculator pc;
/*     */   private JPanel titlePanel;
/*     */   private JLabel gapLabel;
/*     */   private JPanel optionpanel;
/*     */   private EntropyListPanel listPanel;
/*     */   private EntropyDistributionDiagramPanel entropyDistributionDiagramPanel;
/*     */   private double avg20;
/*     */   private double avg6;
/*     */ 
/*     */   public EntropyStatisticsPanel(ProbabilityCalculator pc)
/*     */   {
/*  19 */     this.pc = pc;
/*  20 */     this.entropyDistributionDiagramPanel = new EntropyDistributionDiagramPanel(pc);
/*  21 */     this.listPanel = new EntropyListPanel(pc, this.entropyDistributionDiagramPanel);
/*  22 */     this.titlePanel = new JPanel();
/*  23 */     this.titlePanel.add(new JLabel("information statistics: "));
/*  24 */     this.gapLabel = new JLabel("(for sites whose gap frequency <= " + 
/*  25 */       pc.getGapPercent() + ")");
/*  26 */     this.titlePanel.add(this.gapLabel);
/*     */ 
/*  28 */     JPanel westpanel = new JPanel();
/*     */ 
/*  30 */     this.optionpanel = new JPanel();
/*     */ 
/*  32 */     this.optionpanel.setLayout(new GridLayout(2, 1));
/*     */ 
/*  34 */     ButtonGroup group = new ButtonGroup();
/*     */ 
/*  36 */     this.a20Button = new JRadioButton(
/*  37 */       "show information for 20 alphabet", false);
/*  38 */     group.add(this.a20Button);
/*  39 */     this.a20Button.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent event) {
/*  42 */         EntropyStatisticsPanel.this.listPanel.displayList(20);
/*     */       }
/*     */     });
/*  48 */     this.a6Button = new JRadioButton(
/*  49 */       "show information for 6 alphabet ", true);
/*  50 */     group.add(this.a6Button);
/*     */ 
/*  52 */     this.a6Button.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent event) {
/*  55 */         EntropyStatisticsPanel.this.listPanel.displayList(EntropyStatisticsPanel.this.getNumberofgroup());
/*     */       }
/*     */     });
/*  61 */     this.optionpanel.add(this.a6Button);
/*  62 */     this.optionpanel.add(this.a20Button);
/*     */ 
/*  64 */     westpanel.setLayout(new BorderLayout());
/*  65 */     westpanel.add(this.optionpanel, "North");
/*  66 */     westpanel.add(this.listPanel, "Center");
/*     */ 
/*  68 */     setLayout(new BorderLayout());
/*  69 */     add(this.titlePanel, "North");
/*  70 */     add(westpanel, "West");
/*  71 */     add(this.entropyDistributionDiagramPanel, "Center");
/*     */   }
/*     */ 
/*     */   public int getNumberofgroup()
/*     */   {
/*  78 */     return this.pc.getNumberofgroup();
/*     */   }
/*     */ 
/*     */   public void resetPc(ProbabilityCalculator pc) {
/*  82 */     this.pc = pc;
/*  83 */     this.listPanel.resetPc(pc);
/*  84 */     this.gapLabel.setText("( for sites whose gap frequency <= " + 
/*  85 */       pc.getGapPercent() + ")");
/*     */ 
/*  87 */     double[] entropy0 = pc.getEntropy0();
/*  88 */     double[] entropy1 = pc.getEntropy1();
/*  89 */     double[][] freq6aa = pc.getFreq6aa();
/*  90 */     double[][] freqaa = pc.getFreqaa();
/*     */ 
/*  92 */     this.avg20 = 0.0D;
/*  93 */     this.avg6 = 0.0D;
/*  94 */     int n6 = 0;
/*  95 */     int n20 = 0;
/*     */ 
/*  97 */     for (int i = 0; i < entropy1.length; i++) {
/*  98 */       if (freq6aa[i][pc.getNumberofgroup()] <= pc.getGapPercent())
/*     */       {
/* 100 */         this.avg6 += entropy1[i];
/* 101 */         n6++;
/*     */       }
/*     */     }
/*     */ 
/* 105 */     for (int j = 0; j < entropy0.length; j++)
/*     */     {
/* 107 */       if (freqaa[j][20] <= pc.getGapPercent() * entropy0.length) {
/* 108 */         this.avg20 += entropy0[j];
/* 109 */         System.out.println("!!!entropy0[j] = " + entropy0[j]);
/* 110 */         n20++;
/*     */       }
/*     */     }
/*     */ 
/* 114 */     this.avg20 /= n20;
/* 115 */     this.avg6 /= n6;
/*     */ 
/* 117 */     this.a20Button
/* 118 */       .setText("show information for 20 alphabet: average = " + 
/* 119 */       SicenToComm(this.avg20));
/*     */ 
/* 121 */     String text = new String();
/* 122 */     if (pc.getDefault()) text = "show information for 6 alphabet (default setting): average = "; else {
/* 123 */       text = "show information for " + pc.getNumberofgroup() + " alphabet (user setting): average = ";
/*     */     }
/* 125 */     this.a6Button
/* 126 */       .setText(text + 
/* 127 */       SicenToComm(this.avg6));
/*     */   }
/*     */ 
/*     */   public static String SicenToComm(double value)
/*     */   {
/* 133 */     String retValue = null;
/*     */ 
/* 135 */     DecimalFormat df = new DecimalFormat();
/*     */ 
/* 137 */     df.setMinimumFractionDigits(3);
/*     */ 
/* 139 */     df.setMaximumFractionDigits(3);
/*     */ 
/* 141 */     retValue = df.format(value);
/*     */ 
/* 143 */     retValue = retValue.replaceAll(",", "");
/*     */ 
/* 145 */     return retValue;
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.EntropyStatisticsPanel
 * JD-Core Version:    0.6.2
 */