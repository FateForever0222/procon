/*     */ package source.view;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class DistributionPanel extends JPanel
/*     */ {
/*     */   private ProbabilityCalculator pc;
/*     */   private JPanel titlePanel;
/*     */   private JTextField siteField;
/*     */   private JLabel siteLabel;
/*     */   private DistributionDiagramPanel diagramPanel;
/*     */   private JSlider siteslider;
/*     */   private ChangeListener listener;
/*     */ 
/*     */   public DistributionPanel(ProbabilityCalculator pc)
/*     */   {
/*  21 */     this.pc = pc;
/*  22 */     this.diagramPanel = new DistributionDiagramPanel(pc);
/*  23 */     setLayout(new BorderLayout());
/*  24 */     add(this.diagramPanel, "Center");
/*     */ 
/*  26 */     this.listener = new ChangeListener()
/*     */     {
/*     */       public void stateChanged(ChangeEvent event) {
/*  29 */         JSlider source = (JSlider)event.getSource();
/*     */ 
/*  32 */         DistributionPanel.this.siteLabel.setText(String.valueOf(source.getValue()));
/*  33 */         DistributionPanel.this.diagramPanel.setSite(source.getValue() - 1);
/*  34 */         DistributionPanel.this.diagramPanel.repaint();
/*     */       }
/*     */     };
/*  41 */     this.titlePanel = new JPanel();
/*  42 */     this.titlePanel.add(new JLabel("position: "));
/*  43 */     this.siteLabel = new JLabel("1");
/*  44 */     this.siteLabel.setForeground(Color.RED);
/*     */ 
/*  46 */     this.titlePanel.add(this.siteLabel);
/*  47 */     this.titlePanel
/*  48 */       .add(new JLabel(
/*  49 */       ". Please drag the slider below to change the position value."));
/*     */ 
/*  51 */     add(this.titlePanel, "North");
/*     */ 
/*  53 */     if (pc.getResNumber() != 0)
/*  54 */       this.siteslider = new JSlider(1, pc.getResNumber());
/*     */     else {
/*  56 */       this.siteslider = new JSlider(1, 100, 1);
/*     */     }
/*  58 */     this.siteslider.setBounds(new Rectangle(800, 20));
/*  59 */     this.siteslider.setPaintTicks(true);
/*  60 */     this.siteslider.setPaintLabels(true);
/*  61 */     this.siteslider.setMajorTickSpacing(20);
/*  62 */     this.siteslider.setMinorTickSpacing(5);
/*  63 */     this.siteslider.addChangeListener(this.listener);
/*  64 */     add(this.siteslider, "South");
/*     */   }
/*     */ 
/*     */   public void resetPc(ProbabilityCalculator pc)
/*     */   {
/*  70 */     this.pc = pc;
/*  71 */     this.siteslider.setMaximum(pc.getResNumber());
/*  72 */     this.diagramPanel.resetPc(pc);
/*  73 */     this.diagramPanel.repaint();
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.DistributionPanel
 * JD-Core Version:    0.6.2
 */