/*    */ package source.view;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.Image;
/*    */ import java.awt.Toolkit;
/*    */ import java.io.File;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ public class LogoPanel extends JPanel
/*    */ {
/*    */   private Image image;
/*    */ 
/*    */   public void paintComponent(Graphics g)
/*    */   {
/* 17 */     super.paintComponents(g);
/* 18 */     Graphics2D g2 = (Graphics2D)g;
/* 19 */     File directory = new File("..");
/*    */     try
/*    */     {
/* 22 */       Toolkit kit = Toolkit.getDefaultToolkit();
/* 23 */       this.image = kit.getImage(directory.getCanonicalPath() + "/bin/procon_logo.gif ");
/*    */     }
/*    */     catch (Exception e) {
/* 26 */       e.printStackTrace();
/*    */     }
/*    */ 
/* 29 */     g2.drawImage(this.image, 50, 50, null);
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.LogoPanel
 * JD-Core Version:    0.6.2
 */