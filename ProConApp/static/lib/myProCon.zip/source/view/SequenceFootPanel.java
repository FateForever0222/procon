/*    */ package source.view;
/*    */ 
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ import source.model.ProbabilityCalculator;
/*    */ 
/*    */ public class SequenceFootPanel extends JPanel
/*    */ {
/*    */   private JLabel label;
/*    */   private ProbabilityCalculator pc;
/*    */   private int reference;
/*    */ 
/*    */   public SequenceFootPanel(ProbabilityCalculator pc)
/*    */   {
/* 15 */     this.pc = pc;
/* 16 */     this.label = new JLabel();
/* 17 */     add(this.label);
/*    */   }
/*    */ 
/*    */   public void resetPc(ProbabilityCalculator pc)
/*    */   {
/* 35 */     this.pc = pc;
/* 36 */     repaint();
/*    */   }
/*    */ 
/*    */   public void resetReference(int reference) {
/* 40 */     this.reference = reference;
/* 41 */     this.label.setText("Current reference sequence is: " + 
/* 42 */       Integer.toString(reference + 1));
/* 43 */     repaint();
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.SequenceFootPanel
 * JD-Core Version:    0.6.2
 */