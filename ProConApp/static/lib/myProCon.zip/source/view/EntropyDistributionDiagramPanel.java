/*     */ package source.view;
/*     */ 
/*     */ import java.awt.Color;
import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Point;
/*     */ import java.awt.Polygon;
import java.awt.geom.Line2D;

/*     */ import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
/*     */
/*     */ import java.text.DecimalFormat;

import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.TableModel;

import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
/*     */ import source.model.EntropyInformation;
import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class EntropyDistributionDiagramPanel extends JPanel
/*     */ {
/*     */   private ProbabilityCalculator pc;
/*     */   private Point p0;
/*     */   private double threshold;
/*     */   private double interval;
/*     */   private int choice;
/*     */   private int lengthofx;
/*     */   private int[] numberofresidus;
/*     */   private double random1;
/*     */   private double random2;

private javax.swing.JPopupMenu jPopupMenu_save;
private javax.swing.JMenuItem jMenuItem_save_pic;
/*     */ 
/*     */   public EntropyDistributionDiagramPanel(ProbabilityCalculator pc)
/*     */   {
/*  24 */     this.pc = pc;
/*  25 */     this.p0 = new Point(50, 90);
/*  26 */     this.choice = this.pc.getNumberofgroup();
/*  27 */     this.threshold = 0.0D;
/*  28 */     this.interval = 0.2D;
/*  29 */     this.numberofresidus = new int[0];
/*  30 */     this.random1 = Math.random();
/*  31 */     this.random2 = Math.random();

jPopupMenu_save = new javax.swing.JPopupMenu();
jMenuItem_save_pic = new javax.swing.JMenuItem();
jMenuItem_save_pic.setText("Save as JPEG");
jMenuItem_save_pic.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(java.awt.event.ActionEvent evt) {
       jMenuItem_save_picActionPerformed(evt);
    }
});
jPopupMenu_save.add(jMenuItem_save_pic);
this.setComponentPopupMenu(jPopupMenu_save);

/*     */   }
/*     */ 
/*     */   public void paintComponent(Graphics g) {
/*  35 */     super.paintComponents(g);
/*  36 */     Graphics2D g2 = (Graphics2D)g;
/*     */ 
/*  38 */     g2.setFont(new Font("Dialog", 1, 16));
/*  39 */     g2.drawString("distribution of information: for " + 
/*  40 */       Integer.toString(this.choice) + " alphabet", 50, 50);
/*     */ 
/*  42 */     g2.setFont(new Font("Dialog", 0, 10));
/*     */ 
/*  46 */     g2.draw(new Line2D.Double(this.p0.getX() + 30.0D, this.p0.getY() + 400.0D, this.p0
/*  47 */       .getX() + 410.0D, this.p0.getY() + 400.0D));
/*  48 */     g2.draw(new Line2D.Double(this.p0.getX() + 30.0D, this.p0.getY() + 400.0D, this.p0
/*  49 */       .getX() + 30.0D, this.p0.getY() + 50.0D));
/*     */ 
/*  52 */     drawTriangle(g2, Color.BLACK, 
/*  53 */       (int)this.p0.getX() + 410, (int)this.p0.getY() + 400, 
/*  54 */       (int)this.p0.getX() + 410 - 6, (int)this.p0.getY() + 400 + 2, 
/*  55 */       (int)this.p0.getX() + 410 - 6, (int)this.p0.getY() + 400 - 2);
/*     */ 
/*  57 */     drawTriangle(g2, Color.BLACK, 
/*  58 */       (int)this.p0.getX() + 30, (int)this.p0.getY() + 50, 
/*  59 */       (int)this.p0.getX() + 30 - 2, (int)this.p0.getY() + 50 + 6, 
/*  60 */       (int)this.p0.getX() + 30 + 2, (int)this.p0.getY() + 50 + 6);
/*     */ 
/*  63 */     g2.setFont(new Font("Dialog", 0, 12));
/*  64 */     g2.drawString("information Value", (int)this.p0.getX() + 220, 
/*  65 */       (int)this.p0.getY() + 450);
/*     */ 
/*  67 */     g2.rotate(4.71238898038469D, (int)this.p0.getX() - 10, (int)this.p0.getY() + 230);
/*  68 */     g2.drawString("number of Sites ", (int)this.p0.getX() - 10, 
/*  69 */       (int)this.p0
/*  69 */       .getY() + 230);
/*  70 */     g2.rotate(1.570796326794897D, (int)this.p0.getX() - 10, (int)this.p0.getY() + 230);
/*     */ 
/*  73 */     g2.setFont(new Font("Dialog", 0, 9));
/*     */ 
/*  75 */     if (this.numberofresidus.length != 0) {
/*  76 */       double stepX = 1.0D;
/*  77 */       double stepY = 1.0D;
/*  78 */       if (this.lengthofx != 0) stepX = 350 / this.lengthofx;
/*     */ 
/*  80 */       if (getMax(this.numberofresidus) != 0) stepY = 250 / getMax(this.numberofresidus);
/*     */ 
/*  85 */       for (int i = 0; i <= this.lengthofx; i++) {
/*  86 */         g2.draw(new Line2D.Double(this.p0.getX() + 30.0D + stepX * i, 
/*  87 */           this.p0.getY() + 400.0D, this.p0.getX() + 30.0D + stepX * i, 
/*  88 */           this.p0.getY() + 400.0D + 3.0D));
/*     */ 
/*  90 */         double b = i * this.interval;
/*     */ 
/*  92 */         if (this.lengthofx > 20)
/*     */         {
/*  94 */           if (i % 5 == 0)
/*  95 */             g2.drawString(SicenToComm(i * this.interval), (int)this.p0.getX() + 30 + 
/*  96 */               (int)stepX * i, (int)this.p0.getY() + 420);
/*     */         }
/*     */         else {
/*  99 */           g2.drawString(SicenToComm(i * this.interval), (int)this.p0.getX() + 30 + 
/* 100 */             (int)stepX * i, (int)this.p0.getY() + 420);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 108 */       int step = 5;
/*     */ 
/* 110 */       if (getMax(this.numberofresidus) / step >= 10) step = 10;
/*     */ 
/* 112 */       for (int i = 0; i <= getMax(this.numberofresidus) / step + 1; i++) {
/* 113 */         g2.draw(new Line2D.Double(this.p0.getX() + 30.0D - 3.0D, this.p0.getY() + 400.0D - 
/* 114 */           stepY * step * i, this.p0.getX() + 30.0D, this.p0.getY() + 400.0D - stepY * step * i));
/*     */ 
/* 116 */         g2.drawString(Integer.toString(i * step), (int)this.p0.getX(), 
/* 117 */           (int)(this.p0.getY() + 400.0D - stepY * step * i));
/*     */       }
/*     */ 
/* 153 */       g2.setPaint(Color.RED);
/*     */ 
/* 155 */       for (int i = 0; i < this.lengthofx; i++) {
/* 156 */         Rectangle2D rect = new Rectangle2D.Double(this.p0.getX() + 30.0D + (i + 0.15D) * 
/* 157 */           stepX, this.p0.getY() + 400.0D - this.numberofresidus[i] * stepY, 
/* 158 */           stepX * 0.7D, this.numberofresidus[i] * stepY);
/*     */ 
/* 161 */         g2.fill(rect);
/* 162 */         g2.draw(rect);
/*     */ 
/* 164 */         g2.setColor(Color.black);
/* 165 */         g2.drawString(Integer.toString(this.numberofresidus[i]), 
/* 166 */           (int)(this.p0.getX() + 30.0D + i * 
/* 166 */           stepX + 5.0D), 
/* 167 */           (int)(this.p0.getY() + 400.0D - this.numberofresidus[i] * stepY) - 5);
/* 168 */         g2.setColor(Color.red);
/*     */       }
/*     */ 
/* 175 */       g2.setPaint(Color.BLUE);
/* 176 */       g2.setFont(new Font("Dialog", 1, 12));
/* 177 */       g2.draw(new Line2D.Double(this.p0.getX() + 30.0D + this.threshold * stepX / this.interval, this.p0.getY() + 400.0D, this.p0.getX() + 30.0D + this.threshold * stepX / this.interval, this.p0.getY() + 380.0D - getMax(this.numberofresidus) * stepY));
/* 178 */       g2.drawString("information threshold = " + Double.toString(this.threshold), 
/* 179 */         (int)(this.p0.getX() + 30.0D + this.threshold * stepX / this.interval + 5.0D), 
/* 180 */         (int)(this.p0.getY() + 380.0D - getMax(this.numberofresidus) * stepY));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void displayInformation(int choice, Object[] EIArray, double threshold, double interval)
/*     */   {
/* 188 */     this.choice = choice;
/* 189 */     this.interval = interval;
/* 190 */     this.threshold = threshold;
/*     */ 
/* 192 */     if (EIArray.length != 0) {
/* 193 */       EntropyInformation ei0 = (EntropyInformation)EIArray[0];
/*     */ 
/* 195 */       this.lengthofx = ((int)(ei0.getEntropy() / interval) + 1);
/*     */ 
/* 197 */       this.numberofresidus = new int[this.lengthofx];
/*     */ 
/* 199 */       for (int j = 0; j < this.lengthofx; j++) {
/* 200 */         this.numberofresidus[j] = 0;
/*     */       }
/*     */ 
/* 203 */       for (int i = 0; i < EIArray.length; i++) {
/* 204 */         EntropyInformation ei = (EntropyInformation)EIArray[i];
/*     */ 
/* 206 */         for (int j = 0; j < this.lengthofx; j++) {
/* 207 */           int x = (int)(ei.getEntropy() / interval);
/* 208 */           if (x == j) {
/* 209 */             this.numberofresidus[j] += 1;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 214 */       repaint();
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getMax(int[] a) {
/* 219 */     int min = 0;
/* 220 */     int max = 0;
/*     */ 
/* 222 */     min = a[0];
/* 223 */     max = a[0];
/*     */ 
/* 225 */     for (int i = 1; i <= a.length - 1; i++) {
/* 226 */       if (a[i] < min) {
/* 227 */         min = a[i];
/*     */       }
/* 229 */       if (a[i] > max) {
/* 230 */         max = a[i];
/*     */       }
/*     */     }
/* 233 */     return max;
/*     */   }
/*     */ 
/*     */   public static String SicenToComm(double value)
/*     */   {
/* 238 */     String retValue = null;
/*     */ 
/* 240 */     DecimalFormat df = new DecimalFormat();
/*     */ 
/* 242 */     df.setMinimumFractionDigits(1);
/*     */ 
/* 244 */     df.setMaximumFractionDigits(1);
/*     */ 
/* 246 */     retValue = df.format(value);
/*     */ 
/* 248 */     retValue = retValue.replaceAll(",", "");
/*     */ 
/* 250 */     return retValue;
/*     */   }
/*     */ 
/*     */   public void drawTriangle(Graphics2D g, Color color, int x1, int y1, int x2, int y2, int x3, int y3)
/*     */   {
/* 257 */     Polygon filledPolygon = new Polygon();
/* 258 */     filledPolygon.addPoint(x1, y1);
/* 259 */     filledPolygon.addPoint(x2, y2);
/* 260 */     filledPolygon.addPoint(x3, y3);
/* 261 */     g.setColor(color);
/* 262 */     g.fill(filledPolygon);
/* 263 */     g.drawPolygon(filledPolygon);
/*     */   }

			public void create_pic(String outputFile,JPanel panel)
			{
				Dimension imageSize = panel.getSize();
			    BufferedImage image = new BufferedImage(imageSize.width,
			            imageSize.height, BufferedImage.TYPE_INT_ARGB);
			    Graphics2D g = image.createGraphics();
			    panel.paint(g);
			    g.dispose();
			    try {
			        File f = new File(outputFile+".jpg");
			    	ImageIO.write(image, "png", f);
			    } catch (IOException e) {
			        e.printStackTrace();
			       
			    }
			   // System.out.println("export Image -->" + f.getAbsoluteFile());
			   
			}
			
			private void  jMenuItem_save_picActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_save_execlActionPerformed
			    // TODO add your handling code here:
			    JFileChooser jfilechooser = new JFileChooser();
			    jfilechooser.setDialogType(JFileChooser.SAVE_DIALOG);
			    FileNameExtensionFilter filter = new FileNameExtensionFilter("jpg","jpeg");
			    jfilechooser.setFileFilter(filter);
			    //jfilechooser.set
			    jfilechooser.showSaveDialog(null);
			    if(jfilechooser.getSelectedFile().exists())
			    {
			           int choose= JOptionPane.showConfirmDialog(null, "The file did exist!","OOPS",JOptionPane.OK_CANCEL_OPTION);
			            //this.jTextField_batch_file.setForeground(Color.red);
			           if(choose == JOptionPane.YES_OPTION)
			               create_pic(jfilechooser.getSelectedFile().getPath(),this);
			           else
			            return;
			    }
			    else
			    {
			        //File file = jfilechooser.getSelectedFile();
			        create_pic(jfilechooser.getSelectedFile().getPath(),this);
			    }
			
			
			}
/*     */ }
