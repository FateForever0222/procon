/*     */ package source.view;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JSeparator;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.table.TableModel;
/*     */ import source.model.MutObjNew;
/*     */ import source.model.MutualInformation;
/*     */ import source.model.ProbabilityCalculator;
/*     */ import source.model.Triplet;
/*     */ import source.model.TripletFinder;
/*     */ 
/*     */ public class TpListPanel extends JPanel
/*     */ {
/*     */   private JLabel head;
/*     */   private ProbabilityCalculator pc;
/*     */   private StructureDisplayPanel displaypanel;
/*     */   private MutualInformation mi;
/*     */   private TripletFinder tf;
/*     */   private ArrayList displaylist;
/*     */   private JTable table;
/*     */   private JScrollPane pane;
/*     */   private TableModel model;
/*     */ 
/*     */   public TpListPanel(ProbabilityCalculator pc, StructureDisplayPanel spanel)
/*     */   {
/*  30 */     this.pc = pc;
/*  31 */     this.displaypanel = spanel;
/*     */ 
/*  33 */     Object[][] rows = new Object[40][4];
/*  34 */     String[] columns = { "rank", "site1", "site2", "site3" };
/*  35 */     this.model = new DefaultTableModel(rows, columns);
/*  36 */     this.table = new JTable(this.model);
/*     */ 
/*  38 */     this.table.setPreferredScrollableViewportSize(new Dimension(200, 300));
/*     */ 
/*  40 */     Font f = new Font("Serif", 0, 10);
/*  41 */     this.table.setFont(f);
/*     */ 
/*  43 */     this.table.getTableHeader().setFont(new Font("Serif", 0, 10));
/*     */ 
/*  45 */     TableColumn column3 = this.table.getColumnModel().getColumn(3);
/*  46 */     column3.setPreferredWidth(220);
/*     */ 
/*  48 */     this.table.addMouseListener(new MouseAdapter() {
/*     */       public void mouseClicked(MouseEvent e) {
/*  50 */         TpListPanel.this.tableClickActionPerformedTriplet(TpListPanel.this.table);
/*     */       }
/*     */     });
/*  53 */     this.pane = new JScrollPane(this.table);
/*     */ 
/*  57 */     setLayout(new BorderLayout());
/*     */ 
/*  59 */     this.head = new JLabel();
/*  60 */     this.head.setText("triplets found among the covariant pairs (p < " + 
/*  61 */       pc.getPValue2() + " )");
/*     */ 
/*  63 */     add(this.head, "North");
/*     */ 
/*  65 */     add(this.pane, "Center");
/*  66 */     JSeparator s = new JSeparator(0);
/*  67 */     Dimension ps = s.getPreferredSize();
/*  68 */     s.setPreferredSize(new Dimension(ps.width, 30));
/*  69 */     add(s, "South");
/*     */   }
/*     */ 
/*     */   public void initialPc(ProbabilityCalculator pc) {
/*  73 */     this.pc = pc;
/*     */   }
/*     */ 
/*     */   public void resetPc(ProbabilityCalculator pc) {
/*  77 */     this.pc = pc;
/*  78 */     displayList();
/*  79 */     this.table.repaint();
/*  80 */     this.head.setText("triplets found among the covariant pairs (p < " + 
/*  81 */       pc.getPValue2() + " )");
/*     */   }
/*     */ 
/*     */   public ProbabilityCalculator getPc() {
/*  85 */     return this.pc;
/*     */   }
/*     */ 
/*     */   public MutualInformation getMutualInformation() {
/*  89 */     return this.mi;
/*     */   }
/*     */ 
/*     */   public void setMutualInformation(MutualInformation mi) {
/*  93 */     this.mi = mi;
/*  94 */     this.tf = new TripletFinder(mi);
/*     */ 
/*  96 */     displayList();
/*     */   }
/*     */ 
/*     */   public ArrayList getDisplayList()
/*     */   {
/* 101 */     ArrayList displayList = new ArrayList();
/*     */ 
/* 103 */     if ((this.mi != null) && (this.tf != null))
/*     */     {
/* 106 */       ArrayList mutlist = this.mi.getList();
/*     */ 
/* 129 */       ArrayList tripletList = this.tf.getTriplets();
/*     */ 
/* 131 */       this.tf.displayresult();
/*     */ 
/* 133 */       boolean flag1 = true;
/* 134 */       boolean flag2 = true;
/* 135 */       boolean flag3 = true;
/*     */ 
/* 137 */       for (int i = 0; i < tripletList.size(); i++) {
/* 138 */         Triplet tp = (Triplet)tripletList.get(i);
/*     */ 
/* 140 */         int S1 = tp.getS1();
/* 141 */         int S2 = tp.getS2();
/* 142 */         int S3 = tp.getS3();
/* 143 */         flag1 = false;
/* 144 */         flag2 = false;
/* 145 */         flag3 = false;
/*     */ 
/* 147 */         for (int j = 0; j < mutlist.size(); j++) {
/* 148 */           if (((S1 == ((MutObjNew)mutlist.get(j)).getSite1()) && 
/* 149 */             (S2 == 
/* 149 */             ((MutObjNew)mutlist
/* 149 */             .get(j)).getSite2())) || (
/* 150 */             (S2 == ((MutObjNew)mutlist.get(j)).getSite1()) && 
/* 151 */             (S1 == 
/* 151 */             ((MutObjNew)mutlist
/* 151 */             .get(j)).getSite2()))) {
/* 152 */             flag1 = true;
/*     */           }
/* 154 */           if (((S2 == ((MutObjNew)mutlist.get(j)).getSite1()) && 
/* 155 */             (S3 == 
/* 155 */             ((MutObjNew)mutlist
/* 155 */             .get(j)).getSite2())) || (
/* 156 */             (S3 == ((MutObjNew)mutlist.get(j)).getSite1()) && 
/* 157 */             (S2 == 
/* 157 */             ((MutObjNew)mutlist
/* 157 */             .get(j)).getSite2()))) {
/* 158 */             flag2 = true;
/*     */           }
/* 160 */           if (((S1 == ((MutObjNew)mutlist.get(j)).getSite1()) && 
/* 161 */             (S3 == 
/* 161 */             ((MutObjNew)mutlist
/* 161 */             .get(j)).getSite2())) || (
/* 162 */             (S3 == ((MutObjNew)mutlist.get(j)).getSite1()) && 
/* 163 */             (S1 == 
/* 163 */             ((MutObjNew)mutlist
/* 163 */             .get(j)).getSite2()))) {
/* 164 */             flag3 = true;
/*     */           }
/*     */         }
/* 167 */         if ((flag1) && (flag2) && (flag3)) {
/* 168 */           displayList.add(tp);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 179 */     return displayList;
/*     */   }
/*     */ 
/*     */   public void displayList()
/*     */   {
/* 184 */     this.displaylist = getDisplayList();
/*     */ 
/* 186 */     String[][] rows2 = new String[this.displaylist.size()][4];
/*     */ 
/* 188 */     for (int i = 0; i < this.displaylist.size(); i++)
/*     */     {
/* 190 */       Triplet tp = (Triplet)this.displaylist.get(i);
/*     */ 
/* 192 */       int S1 = tp.getS1();
/* 193 */       int S2 = tp.getS2();
/* 194 */       int S3 = tp.getS3();
/*     */ 
/* 201 */       rows2[i][0] = Integer.toString(i + 1);
/* 202 */       rows2[i][1] = this.pc.calculateSite(S1);
/* 203 */       rows2[i][2] = this.pc.calculateSite(S2);
/* 204 */       rows2[i][3] = this.pc.calculateSite(S3);
/*     */     }
/*     */ 
/* 211 */     String[] columns = { "rank", "site1", "site2", "site3" };
/*     */ 
/* 213 */     this.model = new DefaultTableModel(rows2, columns) {
/*     */       public boolean isCellEditable(int row, int column) {
/* 215 */         return false;
/*     */       }
/*     */     };
/* 220 */     this.table.setModel(this.model);
/*     */ 
/* 222 */     this.table.getTableHeader().setFont(new Font("Serif", 0, 10));
/*     */ 
/* 226 */     this.table.repaint();
/* 227 */     this.table.updateUI();
/*     */   }
/*     */ 
/*     */   public void tableClickActionPerformedTriplet(JTable table)
/*     */   {
/* 233 */     int numRow = table.getSelectedRow();
/*     */ 
/* 235 */     Triplet tp = (Triplet)this.displaylist.get(numRow);
/*     */ 
/* 237 */     this.displaypanel.dispalyTriplet(this.pc.getActualSite(tp.getS1()), this.pc
/* 238 */       .getActualSite(tp.getS2()), this.pc.getActualSite(tp.getS3()));
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.TpListPanel
 * JD-Core Version:    0.6.2
 */