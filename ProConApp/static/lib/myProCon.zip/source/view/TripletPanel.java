/*     */ package source.view;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import source.model.DiagramEngine;
/*     */ import source.model.MutualInformation;
/*     */ import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class TripletPanel extends JPanel
/*     */ {
/*     */   private JLabel groupLabel;
/*     */   private JRadioButton tripletButton;
/*     */   private JRadioButton muButton;
/*     */   private JRadioButton mup2Button;
/*     */   private ProbabilityCalculator pc;
/*     */   private TripletListPanel listpanel;
/*     */   private MutualInformation mi;
/*     */   private DiagramEngine diagramengine;
/*     */   private TripletDisplayPanel displaypanel;
/*     */   private JPanel optionpanel;
/*     */ 
/*     */   public TripletPanel(ProbabilityCalculator pc)
/*     */   {
/*  26 */     this.pc = pc;
/*     */ 
/*  28 */     this.listpanel = new TripletListPanel(pc);
/*     */ 
/*  31 */     this.diagramengine = new DiagramEngine(this.listpanel);
/*  32 */     this.displaypanel = new TripletDisplayPanel(this.listpanel);
/*  33 */     JPanel westpanel = new JPanel();
/*     */ 
/*  35 */     this.optionpanel = new JPanel();
/*     */ 
/*  37 */     this.optionpanel.setLayout(new GridLayout(4, 1));
/*     */ 
/*  39 */     this.groupLabel = new JLabel(" triplets and covariant aas for 20 alphabet");
/*     */ 
/*  41 */     ButtonGroup group = new ButtonGroup();
/*     */ 
/*  43 */     this.tripletButton = new JRadioButton("show triplets (p < " + 
/*  44 */       pc.getPValue2() + " )", true);
/*  45 */     group.add(this.tripletButton);
/*  46 */     this.tripletButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent event) {
/*  49 */         TripletPanel.this.listpanel.displayList();
/*     */ 
/*  51 */         if (TripletPanel.this.listpanel.getTripletListLength() > 100) {
/*  52 */           JOptionPane.showMessageDialog(TripletPanel.this, 
/*  53 */             "Sorry, there are too many triplets to generate a diagram.");
/*     */         }
/*     */ 
/*  56 */         TripletPanel.this.displaypanel.setDisplayTriplet(3);
/*  57 */         TripletPanel.this.displaypanel.repaint();
/*     */       }
/*     */     });
/*  63 */     this.muButton = new JRadioButton("show covariant pairs (p < " + 
/*  64 */       pc.getPValue1() + " )", false);
/*  65 */     group.add(this.muButton);
/*     */ 
/*  67 */     this.muButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent event) {
/*  70 */         TripletPanel.this.listpanel.displayMuP1List();
/*     */ 
/*  72 */         if (TripletPanel.this.listpanel.getMu1ListLength() > 100) {
/*  73 */           JOptionPane.showMessageDialog(TripletPanel.this, 
/*  74 */             "Sorry, there are too many covariant pairs to generate a diagram.");
/*     */         }
/*     */ 
/*  77 */         TripletPanel.this.displaypanel.setDisplayTriplet(1);
/*  78 */         TripletPanel.this.displaypanel.repaint();
/*     */       }
/*     */     });
/*  84 */     this.mup2Button = new JRadioButton("show covariant pairs (p = " + 
/*  85 */       pc.getPValue1() + " ~ " + pc.getPValue2() + " )", false);
/*  86 */     group.add(this.mup2Button);
/*     */ 
/*  88 */     this.mup2Button.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent event) {
/*  91 */         TripletPanel.this.listpanel.displayMuP2List();
/*     */ 
/*  93 */         if (TripletPanel.this.listpanel.getMu2ListLength() > 100) {
/*  94 */           JOptionPane.showMessageDialog(TripletPanel.this, 
/*  95 */             "Sorry, there are too many covariant pairs to generate a diagram.");
/*     */         }
/*     */ 
/*  98 */         TripletPanel.this.displaypanel.setDisplayTriplet(2);
/*  99 */         TripletPanel.this.displaypanel.repaint();
/*     */       }
/*     */     });
/* 105 */     this.optionpanel.add(this.groupLabel);
/* 106 */     this.optionpanel.add(this.tripletButton);
/* 107 */     this.optionpanel.add(this.muButton);
/* 108 */     this.optionpanel.add(this.mup2Button);
/* 109 */     westpanel.setLayout(new BorderLayout());
/*     */ 
/* 112 */     westpanel.add(this.listpanel, "Center");
/* 113 */     westpanel.add(this.optionpanel, "North");
/*     */ 
/* 115 */     setLayout(new BorderLayout());
/* 116 */     add(westpanel, "West");
/*     */ 
/* 135 */     add(this.displaypanel, "Center");
/*     */ 
/* 137 */     JPanel graphvizPanel = new JPanel();
/*     */ 
/* 139 */     JButton figureButton = new JButton("view the diagram in Windows paint");
/*     */ 
/* 142 */     figureButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent event)
/*     */       {
/* 146 */         File directory = new File("..");
/*     */         try
/*     */         {
/* 149 */           String cLine = new String();
/* 150 */           if (TripletPanel.this.displaypanel.getDisplayTriplet() == 1) {
/* 151 */             cLine = "mspaint \"" + directory.getCanonicalPath() + 
/* 152 */               "\\output\\pairs(P value smaller than P1).png\"";
/*     */           }
/* 154 */           if (TripletPanel.this.displaypanel.getDisplayTriplet() == 2) {
/* 155 */             cLine = "mspaint \"" + directory.getCanonicalPath() + 
/* 156 */               "\\output\\pairs(P value between P1 and P2).png\"";
/*     */           }
/* 158 */           if (TripletPanel.this.displaypanel.getDisplayTriplet() == 3) {
/* 159 */             cLine = "mspaint \"" + directory.getCanonicalPath() + 
/* 160 */               "\\output\\Triplets.png\"";
/*     */           }
/*     */ 
/* 163 */           Process p = Runtime.getRuntime().exec(cLine);
/* 164 */           p.waitFor();
/* 165 */           p.destroy();
/*     */         }
/*     */         catch (Exception localException)
/*     */         {
/*     */         }
/*     */       }
/*     */     });
/* 202 */     JLabel graphvizLabel = new JLabel();
/* 203 */     graphvizLabel.setFont(new Font("Dialog", 1, 14));
/*     */ 
/* 207 */     if (System.getProperty("os.name").substring(0, 7).equals("Windows")) {
/* 208 */       graphvizPanel.add(figureButton);
/*     */     }
/*     */ 
/* 212 */     add(graphvizPanel, "South");
/*     */   }
/*     */ 
/*     */   public void setMutualInformation(MutualInformation mi)
/*     */   {
/* 218 */     this.mi = mi;
/*     */ 
/* 220 */     if ((this.mi != null) && (!this.mi.getGroupFlag()))
/* 221 */       this.groupLabel.setText(" triplets and covariant aas for " + Integer.toString(this.pc.getNumberofgroup()) + " alphabet");
/*     */     else
/* 223 */       this.groupLabel.setText(" triplets and covariant aas for 20 alphabet");
/* 224 */     this.listpanel.setMutualInformation(this.mi);
/*     */ 
/* 226 */     this.diagramengine.calculateTripletNodes();
/* 227 */     this.diagramengine.calculateMuNodes();
/*     */     try
/*     */     {
/* 230 */       this.diagramengine.generateDiagram();
/* 231 */       this.diagramengine.generateMuDiagram();
/*     */     } catch (Exception e) {
/* 233 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 239 */     this.displaypanel.repaint();
/*     */   }
/*     */ 
/*     */   public void initialPc(ProbabilityCalculator pc) {
/* 243 */     this.pc = pc;
/* 244 */     this.listpanel.initialPc(pc);
/*     */   }
/*     */ 
/*     */   public void resetPc(ProbabilityCalculator pc) {
/* 248 */     this.pc = pc;
/* 249 */     this.listpanel.resetPc(pc);
/*     */ 
/* 254 */     this.diagramengine.calculateTripletNodes();
/* 255 */     this.diagramengine.calculateMuNodes();
/*     */     try {
/* 257 */       this.diagramengine.generateDiagram();
/* 258 */       this.diagramengine.generateMuDiagram();
/*     */     } catch (Exception e) {
/* 260 */       e.printStackTrace();
/*     */     }
/* 262 */     this.displaypanel.repaint();
/* 263 */     this.tripletButton.setText("show triplets (p < " + pc.getPValue2() + " )");
/* 264 */     this.muButton
/* 265 */       .setText("show covariant pairs (p < " + pc.getPValue1() + " )");
/* 266 */     this.mup2Button.setText("show covariant pairs (p = " + pc.getPValue1() + 
/* 267 */       " ~ " + pc.getPValue2() + " )");
/*     */   }
/*     */ 
/*     */   public void resetTriplets() {
/* 271 */     this.listpanel.displayList();
/*     */ 
/* 274 */     this.diagramengine.calculateTripletNodes();
/* 275 */     this.diagramengine.calculateMuNodes();
/*     */     try {
/* 277 */       this.diagramengine.generateDiagram();
/* 278 */       this.diagramengine.generateMuDiagram();
/*     */     } catch (Exception e) {
/* 280 */       e.printStackTrace();
/*     */     }
/* 282 */     this.displaypanel.repaint();
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.TripletPanel
 * JD-Core Version:    0.6.2
 */