/*     */ package source.view;
/*     */ 
/*     */ import java.awt.Font;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import source.model.MutualInformation;
/*     */ import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class MutualFootPanel extends JPanel
/*     */ {
/*     */   private JLabel label;
/*     */   private JLabel label2;
/*     */   private JLabel label3;
/*     */   private JRadioButton a20Button;
/*     */   private JRadioButton a6Button;
/*     */   private ProbabilityCalculator pc;
/*     */   private int reference;
/*     */   private MutualListPanel listPanel;
/*     */   private MutualInformation mi6;
/*     */   private MutualInformation mi20;
/*     */   private CovariantDistributionPanel covariantDistributionPanel;
/*     */   private TripletPanel tripletpanel;
/*     */   private StructurePanel structurepanel;
/*     */ 
/*     */   public MutualFootPanel(ProbabilityCalculator apc, MutualListPanel alistPanel, CovariantDistributionPanel acovariantDistributionPanel, TripletPanel atripletpanel, StructurePanel astructurepanel)
/*     */   {
/*  22 */     this.pc = apc;
/*     */ 
/*  29 */     this.listPanel = alistPanel;
/*     */ 
/*  31 */     this.covariantDistributionPanel = acovariantDistributionPanel;
/*  32 */     this.tripletpanel = atripletpanel;
/*  33 */     this.structurepanel = astructurepanel;
/*     */ 
/*  35 */     setLayout(new GridLayout(5, 1));
/*  36 */     this.label = new JLabel("current reference sequence is: 1");
/*  37 */     this.label2 = new JLabel("to see information for individual pairs,");
/*  38 */     this.label2.setFont(new Font("Dialog", 0, 12));
/*  39 */     this.label3 = new JLabel("click for a line in the table:");
/*  40 */     this.label3.setFont(new Font("Dialog", 0, 12));
/*     */ 
/*  42 */     ButtonGroup group = new ButtonGroup();
/*     */ 
/*  44 */     this.a20Button = new JRadioButton(
/*  45 */       "show covariant pairs for 20 alphabet", true);
/*  46 */     group.add(this.a20Button);
/*  47 */     this.a20Button.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent event)
/*     */       {
/*  52 */         MutualFootPanel.this.listPanel.setMutualInformation(MutualFootPanel.this.mi20);
/*  53 */         MutualFootPanel.this.listPanel.resetList();
/*     */ 
/*  57 */         MutualFootPanel.this.covariantDistributionPanel.setMutualInformation(MutualFootPanel.this.mi20);
/*  58 */         MutualFootPanel.this.covariantDistributionPanel.resetPc(MutualFootPanel.this.pc);
/*  59 */         MutualFootPanel.this.tripletpanel.setMutualInformation(MutualFootPanel.this.mi20);
/*  60 */         MutualFootPanel.this.structurepanel.setMutualInformation(MutualFootPanel.this.mi20);
/*     */       }
/*     */     });
/*  67 */     this.a6Button = new JRadioButton(
/*  68 */       "show covariant pairs for " + Integer.toString(this.pc.getNumberofgroup()) + " alphabet ", false);
/*  69 */     group.add(this.a6Button);
/*     */ 
/*  71 */     this.a6Button.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent event) {
/*  74 */         MutualFootPanel.this.listPanel.setMutualInformation(MutualFootPanel.this.mi6);
/*  75 */         MutualFootPanel.this.listPanel.resetList();
/*     */ 
/*  78 */         MutualFootPanel.this.covariantDistributionPanel.setMutualInformation(MutualFootPanel.this.mi6);
/*  79 */         MutualFootPanel.this.covariantDistributionPanel.resetPc(MutualFootPanel.this.pc);
/*  80 */         MutualFootPanel.this.tripletpanel.setMutualInformation(MutualFootPanel.this.mi6);
/*  81 */         MutualFootPanel.this.structurepanel.setMutualInformation(MutualFootPanel.this.mi6);
/*     */       }
/*     */     });
/*  88 */     add(this.a20Button);
/*  89 */     add(this.a6Button);
/*     */ 
/*  92 */     add(this.label);
/*  93 */     add(this.label2);
/*  94 */     add(this.label3);
/*     */   }
/*     */ 
/*     */   public void resetReference(int reference) {
/*  98 */     this.reference = reference;
/*  99 */     this.label.setText("current reference sequence is: " + 
/* 100 */       Integer.toString(this.pc.getReference() + 1));
/* 101 */     repaint();
/*     */   }
/*     */ 
/*     */   public void resetPc(ProbabilityCalculator pc)
/*     */   {
/* 113 */     this.pc = pc;
/* 114 */     this.mi20 = new MutualInformation(this.pc, this.pc.getGapPercent(), this.pc.getPValue1(), this.pc.getPValue2());
/* 115 */     this.mi6 = new MutualInformation(this.pc, this.pc.getGapPercent(), this.pc.getPValue1(), this.pc.getPValue2(), false);
/* 116 */     repaint();
/* 117 */     this.a6Button.setText("show covariant pairs for " + Integer.toString(pc.getNumberofgroup()) + " alphabet ");
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.MutualFootPanel
 * JD-Core Version:    0.6.2
 */