/*     */ package source.view;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
import java.io.FileOutputStream;
import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableModel;

import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
/*     */ import source.model.MutualInformation;
import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class MutualDetailPanel extends JPanel
/*     */ {
/*     */   private MutualInformation mi;
/*     */   private ProbabilityCalculator pc;
/*     */   private JTable table;
/*     */   private JScrollPane pane;
			
			
			
			private javax.swing.JPopupMenu jPopupMenu_table_save;
			private javax.swing.JMenuItem jMenuItem_save_excel;

/* 141 */   public static String[] columns = { "aas", "A", "C", "D", "E", "F", "G", "H", 
/* 142 */     "I", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "V", "W", "Y" };
/*     */ 
/* 143 */   private static int rowHeight = 12;
/*     */ 
/*     */   public MutualDetailPanel()
/*     */   {
/*  26 */     Object[][] rows = new Object[20][21];
/*     */ 
/*  28 */     TableModel model = new DefaultTableModel(rows, columns);
/*  29 */     this.table = new JTable(model);
/*  30 */     this.table.setRowHeight(rowHeight);
/*     */ 
/*  32 */     this.table.setPreferredScrollableViewportSize(new Dimension(700, 
/*  33 */       rowHeight * 20));
/*  34 */     this.table.setAutoResizeMode(2);
/*     */ 
/*  44 */     Font f = new Font("Serif", 0, 10);
/*  45 */     this.table.setFont(f);
/*     */ 
/*  47 */     this.table.getTableHeader().setFont(new Font("Serif", 0, 10));

				jPopupMenu_table_save = new javax.swing.JPopupMenu();
				jMenuItem_save_excel = new javax.swing.JMenuItem();
				jMenuItem_save_excel.setText("Save as Excel");
				jMenuItem_save_excel.addActionListener(new java.awt.event.ActionListener() {
				    public void actionPerformed(java.awt.event.ActionEvent evt) {
				        jMenuItem_save_excelActionPerformed(evt);
				    }
				});
				jPopupMenu_table_save.add(jMenuItem_save_excel);
				table.setComponentPopupMenu(jPopupMenu_table_save);
				


/*  48 */     this.pane = new JScrollPane(this.table);
/*     */ 
/*  50 */     add(this.pane, "Center");
/*     */   }
/*     */ 
/*     */   public void resetTable(float[][] detail)
/*     */   {
/*  56 */     if ((this.mi != null) && (!this.mi.getGroupFlag()))
/*     */     {
/*  58 */       int groupnumber = this.pc.getNumberofgroup();
/*  59 */       int[] group = this.pc.getGroup();
/*  60 */       String[] groupnames = this.pc.getGroupNames();
/*     */ 
/*  62 */       String[] newgroupnames = new String[groupnumber + 1];
/*     */ 
/*  64 */       newgroupnames[0] = "aa groups";
/*  65 */       for (int i = 1; i <= groupnumber; i++) {
/*  66 */         newgroupnames[i] = groupnames[(i - 1)];
/*     */       }
/*     */ 
/*  69 */       String[][] rows2 = new String[groupnumber][groupnumber + 1];
/*  70 */       for (int i = 0; i < groupnumber; i++)
/*     */       {
/*  72 */         rows2[i][0] = groupnames[i];
/*     */ 
/*  74 */         for (int j = 0; j < groupnumber; j++) {
/*  75 */           NumberFormat formater = 
/*  76 */             DecimalFormat.getInstance();
/*  77 */           formater.setMaximumFractionDigits(3);
/*  78 */           String rt = formater.format(detail[i][j]);
/*  79 */           rows2[i][(j + 1)] = rt;
/*     */         }
/*     */       }
/*     */ 
/*  83 */       TableModel model2 = new DefaultTableModel(rows2, newgroupnames) {
/*     */         public boolean isCellEditable(int row, int column) {
/*  85 */           return false;
/*     */         }
/*     */       };
/*  88 */       this.table.setModel(model2);
/*  89 */       this.table.setRowHeight(rowHeight * 20 / groupnumber);
/*     */     }
/*     */     else
/*     */     {
/*  94 */       String[][] rows2 = new String[20][21];
/*     */ 
/*  96 */       for (int i = 0; i < 20; i++) {
/*  97 */         System.out.println("columns[i+1]=" + columns[(i + 1)]);
/*  98 */         rows2[i][0] = columns[(i + 1)];
/*  99 */         for (int j = 0; j < 20; j++)
/*     */         {
/* 103 */           NumberFormat formater = 
/* 104 */             DecimalFormat.getInstance();
/* 105 */           formater.setMaximumFractionDigits(3);
/* 106 */           String rt = formater.format(detail[i][j]);
/* 107 */           rows2[i][(j + 1)] = rt;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 113 */       TableModel model2 = new DefaultTableModel(rows2, columns) {
/*     */         public boolean isCellEditable(int row, int column) {
/* 115 */           return false;
/*     */         }
/*     */       };
/* 118 */       this.table.setModel(model2);
/* 119 */       this.table.setRowHeight(rowHeight);
/*     */     }
/*     */ 
/* 122 */     this.table.repaint();
/* 123 */     this.table.updateUI();
/*     */   }
/*     */ 
/*     */   public void resetMutualInformation(MutualInformation ami, ProbabilityCalculator apc)
/*     */   {
/* 128 */     this.mi = ami;
/* 129 */     this.pc = apc;
/*     */   }
			
			public void create_excel(String outputFile,JTable in_table)
			{
			   TableModel tablemodel =  in_table.getModel();
			   int colcount = tablemodel.getColumnCount();
			   int rowcount = tablemodel.getRowCount();
			   String title[] = new String[colcount];
			   for(int i=0;i<colcount;i++)
			     title[i] = tablemodel.getColumnName(i);
			
			  if(!outputFile.contains(".xls")&&!outputFile.contains(".xlsx"))
			       outputFile += ".xls";
			  String targetfile = outputFile;// 输出的excel文件名
			  System.out.println(targetfile);
			String worksheet = "List";// 输出的excel文件工作表名
			WritableWorkbook workbook = null;
			try {
			OutputStream os=new FileOutputStream(targetfile);
			workbook=Workbook.createWorkbook(os);
			WritableSheet sheet = workbook.createSheet(worksheet, 0); // 添加第一个工作表
			jxl.write.Label label = null;
			for (int i=0; i<title.length; i++){
			// Label(列号,行号 ,内容 )
			label = new jxl.write.Label(i, 0, title[i]); //把标题放到第一行
			sheet.addCell(label);
			}
			for(int i=0;i<rowcount;i++)
			   for(int j=0;j<colcount;j++)
			    {
			        //data[i][j] = tablemodel.getValueAt(i, j).toString();
			       label = new jxl.write.Label(j, i+1,  tablemodel.getValueAt(i, j).toString()); //j col,i+1 row
			       System.out.println(label+"\n");
			       sheet.addCell(label);
			     }
			
			workbook.write();
			workbook.close();
			os.close();
			}
			catch (Exception e) {
			e.printStackTrace();
			}
			
			}
			
			private void jMenuItem_save_excelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_save_execlActionPerformed
			    // TODO add your handling code here:
			    JFileChooser jfilechooser = new JFileChooser();
			    jfilechooser.setDialogType(JFileChooser.SAVE_DIALOG);
			    FileNameExtensionFilter filter = new FileNameExtensionFilter("xls","xlsx");
			    jfilechooser.setFileFilter(filter);
			    //jfilechooser.set
			    jfilechooser.showSaveDialog(null);
			    if(jfilechooser.getSelectedFile().exists())
			    {
			           int choose= JOptionPane.showConfirmDialog(null, "The file did exist!","OOPS",JOptionPane.OK_CANCEL_OPTION);
			            //this.jTextField_batch_file.setForeground(Color.red);
			           if(choose == JOptionPane.YES_OPTION)
			               create_excel(jfilechooser.getSelectedFile().getPath(),this.table);
			           else
			            return;
			    }
			    else
			    {
			        //File file = jfilechooser.getSelectedFile();
			        create_excel(jfilechooser.getSelectedFile().getPath(),this.table);
			    }
			
			
			}
/*     */ }

/* Location:           C:\Documents and Settings\yyang\妗��\SOD1 ���\ProCon-20121023.jar
 * Qualified Name:     source.view.MutualDetailPanel
 * JD-Core Version:    0.6.2
 */