/*    */ package source.view;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import javax.swing.JPanel;
/*    */ import source.model.MutualInformation;
/*    */ import source.model.ProbabilityCalculator;
/*    */ 
/*    */ public class CovariantDistributionPanel extends JPanel
/*    */ {
/*    */   private JPanel titlePanel;
/*    */   private ProbabilityCalculator pc;
/*    */   private MutualInformation mi;
/*    */   private CovariantDistributionDiagramPanel diagramPanel;
/*    */ 
/*    */   public CovariantDistributionPanel(ProbabilityCalculator pc)
/*    */   {
/* 14 */     this.pc = pc;
/* 15 */     this.titlePanel = new JPanel();
/*    */ 
/* 17 */     this.diagramPanel = new CovariantDistributionDiagramPanel(pc);
/*    */ 
/* 19 */     setLayout(new BorderLayout());
/* 20 */     add(this.titlePanel, "North");
/* 21 */     add(this.diagramPanel, "Center");
/*    */   }
/*    */ 
/*    */   public void resetPc(ProbabilityCalculator pc)
/*    */   {
/* 58 */     this.pc = pc;
/*    */ 
/* 60 */     this.diagramPanel.resetPc(pc);
/* 61 */     this.diagramPanel.setMutualInformation(this.mi);
/*    */ 
/* 63 */     this.diagramPanel.repaint();
/*    */   }
/*    */ 
/*    */   public void setMutualInformation(MutualInformation mi)
/*    */   {
/* 68 */     this.mi = mi;
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.CovariantDistributionPanel
 * JD-Core Version:    0.6.2
 */