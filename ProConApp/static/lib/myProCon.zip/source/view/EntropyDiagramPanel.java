/*     */ package source.view;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.JPanel;
/*     */ import org.jfree.chart.ChartFactory;
/*     */ import org.jfree.chart.ChartPanel;
/*     */ import org.jfree.chart.JFreeChart;
/*     */ import org.jfree.chart.axis.CategoryAxis;
/*     */ import org.jfree.chart.axis.CategoryLabelPositions;
/*     */ import org.jfree.chart.axis.ValueAxis;
/*     */ import org.jfree.chart.plot.CategoryPlot;
/*     */ import org.jfree.chart.plot.PlotOrientation;
/*     */ import org.jfree.chart.renderer.category.BarRenderer;
/*     */ import org.jfree.data.category.CategoryDataset;
/*     */ import org.jfree.data.category.DefaultCategoryDataset;
/*     */ import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class EntropyDiagramPanel extends JPanel
/*     */ {
/*     */   private ProbabilityCalculator pc;
/*     */   private int siteposition;
/*     */   private ChartPanel chartpanel;
/*     */   private ChartPanel chartpanel2;
/*     */   private JFreeChart chart;
/*     */   private JFreeChart chart2;
/*     */ 
/*     */   public EntropyDiagramPanel(ProbabilityCalculator pc)
/*     */   {
/*  31 */     this.pc = pc;
/*  32 */     this.siteposition = 0;
/*     */ 
/*  34 */     CategoryDataset dataset = new DefaultCategoryDataset();
/*     */ 
/*  36 */     this.chart = ChartFactory.createBarChart(
/*  37 */       "information at different positions", 
/*  38 */       "positions (gap percentage < " + pc.getGapPercent() + ")", 
/*  39 */       "information", 
/*  40 */       dataset, 
/*  41 */       PlotOrientation.VERTICAL, 
/*  43 */       true, 
/*  45 */       false, 
/*  46 */       false);
/*     */ 
/*  49 */     this.chart2 = ChartFactory.createBarChart(
/*  50 */       "gap frequencies at different positions", 
/*  51 */       "positions", 
/*  52 */       "gap frequency", 
/*  53 */       dataset, 
/*  54 */       PlotOrientation.VERTICAL, 
/*  56 */       true, 
/*  58 */       false, 
/*  59 */       false);
/*     */ 
/*  62 */     this.chartpanel = new ChartPanel(this.chart);
/*  63 */     this.chartpanel2 = new ChartPanel(this.chart2);
/*  64 */     this.chartpanel.setPreferredSize(new Dimension(1000, 250));
/*  65 */     this.chartpanel2.setPreferredSize(new Dimension(1000, 250));
/*  66 */     add(this.chartpanel);
/*  67 */     add(this.chartpanel2);
/*     */   }
/*     */ 
/*     */   public void resetPc(ProbabilityCalculator pc)
/*     */   {
/*  72 */     this.pc = pc;
/*     */   }
/*     */ 
/*     */   public void paintComponent(Graphics g)
/*     */   {
/*  78 */     if (this.pc.getSeqNumber() != 0)
/*     */     {
/*  80 */       CategoryDataset dataset1 = getDataSet1();
/*  81 */       this.chart = ChartFactory.createBarChart(
/*  82 */         "information at different positions", 
/*  83 */         "positions (information will not be shown if gap frequency > " + 
/*  84 */         this.pc.getGapPercent() + ")", 
/*  85 */         "information", 
/*  86 */         dataset1, 
/*  87 */         PlotOrientation.VERTICAL, 
/*  89 */         true, 
/*  91 */         false, 
/*  92 */         false);
/*     */ 
/*  95 */       CategoryPlot plot = this.chart.getCategoryPlot();
/*  96 */       plot.setRangeGridlinesVisible(true);
/*  97 */       plot.setDomainGridlinesVisible(true);
/*     */ 
/*  99 */       ValueAxis rangeAxis = plot.getRangeAxis();
/*     */ 
/* 101 */       rangeAxis.setUpperMargin(0.1D);
/*     */ 
/* 103 */       CategoryAxis domainAxis = plot.getDomainAxis();
/* 104 */       domainAxis.setLowerMargin(0.0D);
/* 105 */       domainAxis.setUpperMargin(0.0D);
/*     */ 
/* 107 */       domainAxis.setAxisLineVisible(true);
/* 108 */       domainAxis.setTickMarksVisible(true);
/*     */ 
/* 112 */       domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
/* 113 */       this.chartpanel.setChart(this.chart);
/* 114 */       this.chartpanel.repaint();
/*     */ 
/* 116 */       CategoryDataset dataset2 = getDataSet2();
/* 117 */       this.chart2 = ChartFactory.createBarChart(
/* 118 */         "gap frequencies at different positions (current gap percentage = " + 
/* 119 */         this.pc.getGapPercent() + ")", 
/* 120 */         "positions", 
/* 121 */         "gap frequency", 
/* 122 */         dataset2, 
/* 123 */         PlotOrientation.VERTICAL, 
/* 125 */         false, 
/* 127 */         false, 
/* 128 */         false);
/*     */ 
/* 131 */       CategoryPlot plot2 = this.chart2.getCategoryPlot();
/* 132 */       plot2.setRangeGridlinesVisible(true);
/* 133 */       plot2.setDomainGridlinesVisible(true);
/*     */ 
/* 135 */       ValueAxis rangeAxis2 = plot2.getRangeAxis();
/*     */ 
/* 137 */       rangeAxis2.setUpperMargin(0.1D);
/*     */ 
/* 139 */       CategoryAxis domainAxis2 = plot2.getDomainAxis();
/* 140 */       domainAxis2.setLowerMargin(0.0D);
/* 141 */       domainAxis2.setUpperMargin(0.0D);
/* 142 */       domainAxis2.setAxisLineVisible(true);
/* 143 */       domainAxis2.setTickMarksVisible(true);
/* 144 */       BarRenderer renderer2 = (BarRenderer)plot2.getRenderer();
/* 145 */       renderer2.setSeriesPaint(0, Color.GREEN);
/*     */ 
/* 155 */       domainAxis2.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
/*     */ 
/* 157 */       this.chartpanel2.setChart(this.chart2);
/* 158 */       this.chartpanel2.repaint();
/*     */     }
/*     */   }
/*     */ 
/*     */   private CategoryDataset getDataSet1()
/*     */   {
/* 165 */     DefaultCategoryDataset dataset1 = new DefaultCategoryDataset();
/*     */ 
/* 168 */     double[] entropy0 = this.pc.getEntropy0();
/* 169 */     double[] entropy1 = this.pc.getEntropy1();
/* 170 */     double[][] freq6aa = this.pc.getFreq6aa();
/* 171 */     int displaylength = 60;
/*     */ 
/* 173 */     if (this.pc.getResNumber() < 60) {
/* 174 */       displaylength = this.pc.getResNumber();
/*     */     }
/* 176 */     for (int i = this.siteposition; i < this.siteposition + displaylength; i++) {
/* 177 */       if (freq6aa[i][this.pc.getNumberofgroup()] <= this.pc.getGapPercent()) {
/* 178 */         dataset1.addValue(entropy0[i], "information for 20 alphabet", 
/* 179 */           String.valueOf(i + 1));
/* 180 */         if (this.pc.getDefault())
/* 181 */           dataset1.addValue(entropy1[i], "information for " + Integer.toString(this.pc.getNumberofgroup()) + " alphabet " + "(default setting)", 
/* 182 */             String.valueOf(i + 1));
/*     */         else
/* 184 */           dataset1.addValue(entropy1[i], "information for " + Integer.toString(this.pc.getNumberofgroup()) + " alphabet " + "(user setting)", 
/* 185 */             String.valueOf(i + 1));
/*     */       }
/*     */       else
/*     */       {
/* 189 */         dataset1.addValue(0.0D, "information for 20 alphabet", 
/* 190 */           String.valueOf(i + 1));
/* 191 */         if (this.pc.getDefault())
/* 192 */           dataset1.addValue(0.0D, "information for " + Integer.toString(this.pc.getNumberofgroup()) + " alphabet " + "(default setting)", 
/* 193 */             String.valueOf(i + 1));
/*     */         else
/* 195 */           dataset1.addValue(0.0D, "information for " + Integer.toString(this.pc.getNumberofgroup()) + " alphabet " + "(user setting)", 
/* 196 */             String.valueOf(i + 1));
/*     */       }
/*     */     }
/* 199 */     return dataset1;
/*     */   }
/*     */ 
/*     */   private CategoryDataset getDataSet2() {
/* 203 */     DefaultCategoryDataset dataset2 = new DefaultCategoryDataset();
/*     */ 
/* 205 */     double[][] freq6aa = this.pc.getFreq6aa();
/* 206 */     int displaylength = 60;
/* 207 */     if (this.pc.getResNumber() < 60) {
/* 208 */       displaylength = this.pc.getResNumber();
/*     */     }
/* 210 */     for (int i = this.siteposition; i < this.siteposition + displaylength; i++) {
/* 211 */       dataset2.addValue(freq6aa[i][this.pc.getNumberofgroup()], "gap frequency", 
/* 212 */         String.valueOf(i + 1));
/*     */     }
/* 214 */     return dataset2;
/*     */   }
/*     */ 
/*     */   public void printPC() {
/* 218 */     System.out.println("iiiipc.getSeqNumber() = " + this.pc.getSeqNumber());
/*     */   }
/*     */ 
/*     */   public void setSite(int site) {
/* 222 */     this.siteposition = site;
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.EntropyDiagramPanel
 * JD-Core Version:    0.6.2
 */