/*     */ package source.view;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
import java.io.FileOutputStream;
import java.io.OutputStream;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.ArrayList;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.table.TableModel;

import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
/*     */ import source.model.MutObjNew;
/*     */ import source.model.MutualInformation;
/*     */ import source.model.ProbabilityCalculator;
/*     */ import source.model.Triplet;
import source.model.TripletFinder;
/*     */ 
/*     */ public class TripletListPanel extends JPanel
/*     */ {
/*     */   private ProbabilityCalculator pc;
/*     */   private MutualInformation mi;
/*     */   private TripletFinder tf;
/*     */   private JTable table;
/*     */   private JScrollPane pane;
/*     */   private int listlength;
/*     */   private int p1listlength;
/*     */   private int p2listlength;

private javax.swing.JPopupMenu jPopupMenu_table_save;
private javax.swing.JMenuItem jMenuItem_save_excel;
/*     */ 
/*     */   public TripletListPanel(ProbabilityCalculator pc)
/*     */   {
/*  27 */     this.pc = pc;
/*     */ 
/*  29 */     this.listlength = 0;
/*  30 */     this.p1listlength = 0;
/*  31 */     this.p2listlength = 0;
/*     */ 
/*  33 */     Object[][] rows = new Object[40][4];
/*  34 */     String[] columns = { "rank", "site1", "site2", "site3" };
/*  35 */     TableModel model = new DefaultTableModel(rows, columns);
/*  36 */     this.table = new JTable(model);
/*     */ 
/*  38 */     this.table.setPreferredScrollableViewportSize(new Dimension(200, 400));
/*     */ 
/*  40 */     Font f = new Font("Serif", 0, 10);
/*  41 */     this.table.setFont(f);
/*     */ 
/*  43 */     this.table.getTableHeader().setFont(new Font("Serif", 0, 10));
/*     */ 
/*  45 */     TableColumn column3 = this.table.getColumnModel().getColumn(3);
/*  46 */     column3.setPreferredWidth(220);

				jPopupMenu_table_save = new javax.swing.JPopupMenu();
				jMenuItem_save_excel = new javax.swing.JMenuItem();
				jMenuItem_save_excel.setText("Save as Excel");
				jMenuItem_save_excel.addActionListener(new java.awt.event.ActionListener() {
				    public void actionPerformed(java.awt.event.ActionEvent evt) {
				        jMenuItem_save_excelActionPerformed(evt);
				    }
				});
				jPopupMenu_table_save.add(jMenuItem_save_excel);
				table.setComponentPopupMenu(jPopupMenu_table_save);

/*     */ 
/*  48 */     this.pane = new JScrollPane(this.table);
/*     */ 
/*  51 */     add(this.pane, "Center");
/*     */   }
/*     */ 
/*     */   public void setMutualInformation(MutualInformation mi)
/*     */   {
/*  56 */     this.mi = mi;
/*  57 */     this.tf = new TripletFinder(this.mi);
/*     */ 
/*  59 */     displayList();
/*     */   }
/*     */ 
/*     */   public ArrayList getDisplayList()
/*     */   {
/*  65 */     ArrayList displayList = new ArrayList();
/*     */ 
/*  67 */     if ((this.mi != null) && (this.tf != null))
/*     */     {
/*  71 */       ArrayList mulist = this.mi.getList();
/*     */ 
/*  94 */       ArrayList tripletList = this.tf.getTriplets();
/*     */ 
/*  96 */       this.tf.displayresult();
/*     */ 
/*  98 */       boolean flag1 = true;
/*  99 */       boolean flag2 = true;
/* 100 */       boolean flag3 = true;
/*     */ 
/* 102 */       for (int i = 0; i < tripletList.size(); i++) {
/* 103 */         Triplet tp = (Triplet)tripletList.get(i);
/*     */ 
/* 105 */         int S1 = tp.getS1();
/* 106 */         int S2 = tp.getS2();
/* 107 */         int S3 = tp.getS3();
/* 108 */         flag1 = false;
/* 109 */         flag2 = false;
/* 110 */         flag3 = false;
/*     */ 
/* 112 */         for (int j = 0; j < mulist.size(); j++) {
/* 113 */           if (((S1 == ((MutObjNew)mulist.get(j)).getSite1()) && 
/* 114 */             (S2 == 
/* 114 */             ((MutObjNew)mulist
/* 114 */             .get(j)).getSite2())) || (
/* 115 */             (S2 == ((MutObjNew)mulist.get(j)).getSite1()) && 
/* 116 */             (S1 == 
/* 116 */             ((MutObjNew)mulist
/* 116 */             .get(j)).getSite2()))) {
/* 117 */             flag1 = true;
/*     */           }
/* 119 */           if (((S2 == ((MutObjNew)mulist.get(j)).getSite1()) && 
/* 120 */             (S3 == 
/* 120 */             ((MutObjNew)mulist
/* 120 */             .get(j)).getSite2())) || (
/* 121 */             (S3 == ((MutObjNew)mulist.get(j)).getSite1()) && 
/* 122 */             (S2 == 
/* 122 */             ((MutObjNew)mulist
/* 122 */             .get(j)).getSite2()))) {
/* 123 */             flag2 = true;
/*     */           }
/* 125 */           if (((S1 == ((MutObjNew)mulist.get(j)).getSite1()) && 
/* 126 */             (S3 == 
/* 126 */             ((MutObjNew)mulist
/* 126 */             .get(j)).getSite2())) || (
/* 127 */             (S3 == ((MutObjNew)mulist.get(j)).getSite1()) && 
/* 128 */             (S1 == 
/* 128 */             ((MutObjNew)mulist
/* 128 */             .get(j)).getSite2()))) {
/* 129 */             flag3 = true;
/*     */           }
/*     */         }
/* 132 */         if ((flag1) && (flag2) && (flag3)) {
/* 133 */           displayList.add(tp);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 144 */     return displayList;
/*     */   }
/*     */ 
/*     */   public void displayList()
/*     */   {
/* 149 */     ArrayList displaylist = getDisplayList();
/*     */ 
/* 151 */     this.listlength = displaylist.size();
int length =  displaylist.size();
if(length>4000) length=4000;
/*     */ 
/* 153 */     String[][] rows2 = new String[length][4];
/*     */ 
/* 155 */     for (int i = 0; i <length; i++)
/*     */     {
/* 157 */       Triplet tp = (Triplet)displaylist.get(i);
/*     */ 
/* 159 */       int S1 = tp.getS1();
/* 160 */       int S2 = tp.getS2();
/* 161 */       int S3 = tp.getS3();
/*     */ 
/* 166 */       rows2[i][0] = Integer.toString(i + 1);
/* 167 */       rows2[i][1] = this.pc.calculateSite(S1);
/* 168 */       rows2[i][2] = this.pc.calculateSite(S2);
/* 169 */       rows2[i][3] = this.pc.calculateSite(S3);
/*     */     }
/*     */ 
/* 175 */     String[] columns = { "rank", "site1", "site2", "site3" };
/*     */ 
/* 177 */     TableModel model2 = new DefaultTableModel(rows2, columns) {
/*     */       public boolean isCellEditable(int row, int column) {
/* 179 */         return false;
/*     */       }
/*     */     };
/* 182 */     this.table.setModel(model2);
/*     */ 
/* 184 */     this.table.getTableHeader().setFont(new Font("Serif", 0, 10));
/*     */ 
/* 186 */     this.table.repaint();
/* 187 */     this.table.updateUI();
/*     */   }
/*     */ 
/*     */   public void displayMuP1List()
/*     */   {
/* 193 */     ArrayList p1List = this.mi.getListP1();
/*     */ 
/* 195 */     this.p1listlength = p1List.size();
/* NEW    */ /*     */ int length1 = p1List.size();
				if(p1List.size()>4000) length1 =4000;
/* 197 */     String[][] rows1 = new String[length1][4];
/*     */ 
/* 199 */     for (int i = 0; i < length1; i++) {
/* 200 */       rows1[i][0] = Integer.toString(i + 1);
/* 201 */       rows1[i][1] = this.pc.calculateSite(((MutObjNew)p1List.get(i)).getSite1());
/* 202 */       rows1[i][2] = this.pc.calculateSite(((MutObjNew)p1List.get(i)).getSite2());
/*     */ 
/* 211 */       NumberFormat formater = 
/* 212 */         DecimalFormat.getInstance();
/* 213 */       formater.setMaximumFractionDigits(3);
/* 214 */       String rt = formater.format(((MutObjNew)p1List.get(i)).getMuinf12());
/* 215 */       rows1[i][3] = rt;
/*     */     }
/*     */ 
/* 218 */     String[] columns = { "rank", "site1", "site2", "mutual information" };
/* 219 */     TableModel model2 = new DefaultTableModel(rows1, columns) {
/*     */       public boolean isCellEditable(int row, int column) {
/* 221 */         return false;
/*     */       }
/*     */     };
/* 224 */     this.table.setModel(model2);
/*     */ 
/* 226 */     this.table.getTableHeader().setFont(new Font("Serif", 0, 10));
/*     */ 
/* 228 */     TableColumn column0 = this.table.getColumnModel().getColumn(0);
/* 229 */     column0.setPreferredWidth(30);
/*     */ 
/* 231 */     TableColumn column3 = this.table.getColumnModel().getColumn(3);
/* 232 */     column3.setPreferredWidth(90);
/*     */ 
/* 238 */     this.table.repaint();
/* 239 */     this.table.updateUI();
/*     */   }
/*     */ 
/*     */   public void displayMuP2List()
/*     */   {
/* 246 */     ArrayList p2List = this.mi.getListP2();
/*     */ 
/* 248 */     this.p2listlength = p2List.size();
/* NEW    */ /*     */ int length2 = p2List.size();
			if(p2List.size()>4000) length2 =4000;
/* 250 */     String[][] rows2 = new String[length2][4];
/*     */ 
/* 252 */     for (int i = 0; i <length2; i++) {
/* 253 */       rows2[i][0] = Integer.toString(i + 1);
/* 254 */       rows2[i][1] = this.pc.calculateSite(((MutObjNew)p2List.get(i)).getSite1());
/* 255 */       rows2[i][2] = this.pc.calculateSite(((MutObjNew)p2List.get(i)).getSite2());
/*     */ 
/* 264 */       NumberFormat formater = 
/* 265 */         DecimalFormat.getInstance();
/* 266 */       formater.setMaximumFractionDigits(3);
/* 267 */       String rt = formater.format(((MutObjNew)p2List.get(i)).getMuinf12());
/* 268 */       rows2[i][3] = rt;
/*     */     }
/*     */ 
/* 271 */     String[] columns = { "rank", "site1", "site2", "mutual information" };
/* 272 */     TableModel model2 = new DefaultTableModel(rows2, columns) {
/*     */       public boolean isCellEditable(int row, int column) {
/* 274 */         return false;
/*     */       }
/*     */     };
/* 277 */     this.table.setModel(model2);
/*     */ 
/* 279 */     this.table.getTableHeader().setFont(new Font("Serif", 0, 10));
/*     */ 
/* 281 */     TableColumn column0 = this.table.getColumnModel().getColumn(0);
/* 282 */     column0.setPreferredWidth(30);
/*     */ 
/* 284 */     TableColumn column3 = this.table.getColumnModel().getColumn(3);
/* 285 */     column3.setPreferredWidth(90);
/*     */ 
/* 287 */     this.table.repaint();
/* 288 */     this.table.updateUI();
/*     */   }
/*     */ 
/*     */   public void initialPc(ProbabilityCalculator pc)
/*     */   {
/* 293 */     this.pc = pc;
/*     */   }
/*     */ 
/*     */   public void resetPc(ProbabilityCalculator pc) {
/* 297 */     this.pc = pc;
/*     */ 
/* 299 */     displayMuP1List();
/* 300 */     displayMuP2List();
/* 301 */     displayList();
/* 302 */     this.table.repaint();
/*     */   }
/*     */ 
/*     */   public ProbabilityCalculator getPc() {
/* 306 */     return this.pc;
/*     */   }
/*     */ 
/*     */   public MutualInformation getMutualInformation() {
/* 310 */     return this.mi;
/*     */   }
/*     */ 
/*     */   public int getTripletListLength() {
/* 314 */     return this.listlength;
/*     */   }
/*     */ 
/*     */   public int getMu1ListLength()
/*     */   {
/* 319 */     return this.p1listlength;
/*     */   }
/*     */ 
/*     */   public int getMu2ListLength() {
/* 323 */     return this.p2listlength;
/*     */   }
public void create_excel(String outputFile,JTable in_table)
{
   TableModel tablemodel =  in_table.getModel();
   int colcount = tablemodel.getColumnCount();
   int rowcount = tablemodel.getRowCount();
   String title[] = new String[colcount];
   for(int i=0;i<colcount;i++)
     title[i] = tablemodel.getColumnName(i);

  if(!outputFile.contains(".xls")&&!outputFile.contains(".xlsx"))
       outputFile += ".xls";
  String targetfile = outputFile;// �����excel�ļ���
  System.out.println(targetfile);
String worksheet = "List";// �����excel�ļ���������
WritableWorkbook workbook = null;
try {
OutputStream os=new FileOutputStream(targetfile);
workbook=Workbook.createWorkbook(os);
WritableSheet sheet = workbook.createSheet(worksheet, 0); // ���ӵ�һ��������
jxl.write.Label label = null;
for (int i=0; i<title.length; i++){
// Label(�к�,�к� ,���� )
label = new jxl.write.Label(i, 0, title[i]); //�ѱ���ŵ���һ��
sheet.addCell(label);
}
for(int i=0;i<rowcount;i++)
   for(int j=0;j<colcount;j++)
    {
        //data[i][j] = tablemodel.getValueAt(i, j).toString();
       label = new jxl.write.Label(j, i+1,  tablemodel.getValueAt(i, j).toString()); //j col,i+1 row
       System.out.println(label+"\n");
       sheet.addCell(label);
     }

workbook.write();
workbook.close();
os.close();
}
catch (Exception e) {
e.printStackTrace();
}

}

private void jMenuItem_save_excelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_save_execlActionPerformed
    // TODO add your handling code here:
    JFileChooser jfilechooser = new JFileChooser();
    jfilechooser.setDialogType(JFileChooser.SAVE_DIALOG);
    FileNameExtensionFilter filter = new FileNameExtensionFilter("xls","xlsx");
    jfilechooser.setFileFilter(filter);
    //jfilechooser.set
    jfilechooser.showSaveDialog(null);
    if(jfilechooser.getSelectedFile().exists())
    {
           int choose= JOptionPane.showConfirmDialog(null, "The file did exist!","OOPS",JOptionPane.OK_CANCEL_OPTION);
            //this.jTextField_batch_file.setForeground(Color.red);
           if(choose == JOptionPane.YES_OPTION)
               create_excel(jfilechooser.getSelectedFile().getPath(),this.table);
           else
            return;
    }
    else
    {
        //File file = jfilechooser.getSelectedFile();
        create_excel(jfilechooser.getSelectedFile().getPath(),this.table);
    }


}
/*     */ }

