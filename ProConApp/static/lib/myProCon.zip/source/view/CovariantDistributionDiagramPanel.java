/*     */ package source.view;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Point;
/*     */ import java.awt.Polygon;
import java.awt.geom.Line2D;

/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
import javax.swing.filechooser.FileNameExtensionFilter;

/*     */ import source.model.MutObjNew;
/*     */ import source.model.MutualInformation;
import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class CovariantDistributionDiagramPanel extends JPanel
/*     */ {
/* 348 */   static final float[] dash1 = { 3.0F };
/* 349 */   static final BasicStroke dashed = new BasicStroke(1.0F, 
/* 350 */     0, 0, 3.0F, dash1, 0.0F);
/*     */   private double interval;
/*     */   private Point p0;
/*     */   private int pFlag;
/*     */   private int length;
/*     */   private ProbabilityCalculator pc;
/*     */   private MutualInformation mi;
/*     */   private ArrayList<MutObjNew> p1List;
/*     */   private ArrayList<MutObjNew> p2List;
/*     */   private int[][] values;
/*     */   private double p1X;
/*     */   private double p2X;
/*     */   private double p2X0;
/*     */   private MutObjNew[] muts;

			private javax.swing.JPopupMenu jPopupMenu_save;
			private javax.swing.JMenuItem jMenuItem_save_pic;
/*     */ 
/*     */   public CovariantDistributionDiagramPanel(ProbabilityCalculator pc)
/*     */   {
/*  28 */     this.p0 = new Point(30, 50);
/*  29 */     this.pc = pc;
/*  30 */     this.interval = 1.0D;
/*  31 */     this.length = 1;

				
				jPopupMenu_save = new javax.swing.JPopupMenu();
				jMenuItem_save_pic = new javax.swing.JMenuItem();
				jMenuItem_save_pic.setText("Save as JPEG");
				jMenuItem_save_pic.addActionListener(new java.awt.event.ActionListener() {
				    public void actionPerformed(java.awt.event.ActionEvent evt) {
				       jMenuItem_save_picActionPerformed(evt);
				    }
				});
				jPopupMenu_save.add(jMenuItem_save_pic);
				this.setComponentPopupMenu(jPopupMenu_save);
/*     */   }
/*     */ 
/*     */   public void paintComponent(Graphics g)
/*     */   {
/* 104 */     super.paintComponents(g);
/* 105 */     Graphics2D g2 = (Graphics2D)g;
/*     */ 
/* 107 */     g2.setFont(new Font("Dialog", 1, 18));
/* 108 */     if ((this.mi != null) && (!this.mi.getGroupFlag()))
/* 109 */       g2.drawString("distribution of mutual information for " + Integer.toString(this.pc.getNumberofgroup()) + " alphabet", 300, 50);
/* 110 */     else g2.drawString("distribution of mutual information for 20 alphabet", 300, 50);
/*     */ 
/* 112 */     g2.setPaint(Color.BLUE);
/*     */ 
/* 114 */     g2.setFont(new Font("Dialog", 1, 12));
/* 115 */     g2.drawString("p1 and p2 are p-values of Z-test ", 700, 80);
/*     */ 
/* 117 */     g2.setPaint(Color.BLACK);
/*     */ 
/* 119 */     g2.setFont(new Font("Dialog", 0, 10));
/*     */ 
/* 121 */     g2.draw(new Line2D.Double(this.p0.getX() + 30.0D, this.p0.getY() + 500.0D, 
/* 122 */       this.p0.getX() + 940.0D, this.p0.getY() + 500.0D));
/*     */ 
/* 124 */     g2.draw(new Line2D.Double(this.p0.getX() + 30.0D, this.p0.getY() + 500.0D, 
/* 125 */       this.p0.getX() + 30.0D, this.p0.getY() + 50.0D));
/*     */ 
/* 127 */     drawTriangle(g2, Color.BLACK, (int)this.p0.getX() + 940, 
/* 128 */       (int)this.p0.getY() + 500, (int)this.p0.getX() + 940 - 6, 
/* 129 */       (int)this.p0
/* 129 */       .getY() + 500 + 2, (int)this.p0.getX() + 940 - 6, 
/* 130 */       (int)this.p0
/* 130 */       .getY() + 500 - 2);
/*     */ 
/* 132 */     drawTriangle(g2, Color.BLACK, (int)this.p0.getX() + 30, 
/* 133 */       (int)this.p0.getY() + 50, (int)this.p0.getX() + 30 - 2, 
/* 134 */       (int)this.p0.getY() + 50 + 6, (int)this.p0.getX() + 30 + 2, 
/* 135 */       (int)this.p0
/* 135 */       .getY() + 50 + 6);
/*     */ 
/* 139 */     g2.setFont(new Font("Dialog", 0, 14));
/* 140 */     g2.drawString("mutual information", (int)this.p0.getX() + 450, 
/* 141 */       (int)this.p0.getY() + 550);
/*     */ 
/* 143 */     g2.rotate(4.71238898038469D, (int)this.p0.getX() - 10, (int)this.p0.getY() + 350);
/*     */ 
/* 145 */     g2.drawString("number of covariant pairs ", (int)this.p0.getX() - 10, 
/* 146 */       (int)this.p0
/* 146 */       .getY() + 350);
/* 147 */     g2.rotate(1.570796326794897D, (int)this.p0.getX() - 10, (int)this.p0.getY() + 350);
/*     */ 
/* 151 */     if ((this.mi != null) && (this.values.length != 0))
/*     */     {
/* 153 */       double stepX = 900 / this.length;
/*     */ 
/* 155 */       double stepY = 45000 / getMax(this.values[1]);
/*     */ 
/* 157 */       g2.setFont(new Font("Dialog", 0, 11));
/*     */ 
/* 159 */       for (int i = 0; i <= this.length; i++) {
/* 160 */         g2.draw(new Line2D.Double(this.p0.getX() + 30.0D + stepX * i, 
/* 161 */           this.p0.getY() + 500.0D, this.p0.getX() + 30.0D + stepX * i, 
/* 162 */           this.p0.getY() + 500.0D + 2.0D));
/*     */ 
/* 164 */         if (this.length > 40)
/*     */         {
/* 166 */           if ((i + this.values[0][0]) % 10 == 0) {
/* 167 */             g2.draw(new Line2D.Double(this.p0.getX() + 30.0D + stepX * i, 
/* 168 */               this.p0.getY() + 500.0D, this.p0.getX() + 30.0D + stepX * i, this.p0
/* 169 */               .getY() + 500.0D + 4.0D));
/*     */ 
/* 171 */             g2.drawString(Integer.toString(i + this.values[0][0]), 
/* 172 */               (int)this.p0.getX() + 30 + (int)stepX * i, 
/* 173 */               (int)this.p0.getY() + 520);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 178 */           g2.drawString(SicenToComm(this.values[0][i] * this.interval), 
/* 179 */             (int)this.p0.getX() + 30 + (int)stepX * i, 
/* 180 */             (int)this.p0
/* 180 */             .getY() + 520);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 185 */       int step = 100;
/*     */ 
/* 189 */       if (getMax(this.values[1]) / step >= 10) step = 200;
/*     */ 
/* 191 */       for (int i = 0; i < getMax(this.values[1]) / step + 1; i++)
/*     */       {
/* 193 */         g2.draw(new Line2D.Double(this.p0.getX() + 30.0D - 3.0D, this.p0.getY() + 500.0D - 
/* 194 */           stepY / 100.0D * step * i, this.p0.getX() + 30.0D, this.p0.getY() + 500.0D - stepY / 100.0D * step * i));
/*     */ 
/* 196 */         g2.drawString(Integer.toString(i * step), (int)this.p0.getX(), 
/* 197 */           (int)(this.p0.getY() + 500.0D - stepY / 100.0D * step * i));
/*     */       }
/*     */ 
/* 203 */       g2.setFont(new Font("SansSerif", 2, 9));
/*     */ 
/* 205 */       for (int i = 0; i < this.length; i++) {
/* 206 */         Rectangle2D rect = new Rectangle2D.Double(this.p0.getX() + 30.0D + (i + 0.15D) * 
/* 207 */           stepX, this.p0.getY() + 500.0D - this.values[1][i] * stepY / 100.0D, 
/* 208 */           stepX * 0.7D, this.values[1][i] * stepY / 100.0D);
/*     */ 
/* 210 */         g2.setPaint(Color.RED);
/* 211 */         g2.fill(rect);
/* 212 */         g2.draw(rect);
/*     */ 
/* 214 */         g2.setPaint(Color.BLACK);
/*     */ 
/* 216 */         if (this.values[1][i] > 10) {
/* 217 */           if ((i > 0) && (this.values[1][i] < this.values[1][(i - 1)]))
/* 218 */             g2.drawString(Integer.toString(this.values[1][i]), 
/* 219 */               (int)(this.p0.getX() + 30.0D + i * 
/* 219 */               stepX), 
/* 220 */               (int)(this.p0.getY() + 500.0D - this.values[1][i] * stepY / 100.0D) - 5);
/*     */           else {
/* 222 */             g2.drawString(Integer.toString(this.values[1][i]), 
/* 223 */               (int)(this.p0.getX() + 30.0D + (i - 1) * 
/* 223 */               stepX), 
/* 224 */               (int)(this.p0.getY() + 500.0D - this.values[1][i] * stepY / 100.0D) - 5);
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 230 */       g2.setPaint(Color.BLUE);
/* 231 */       g2.setFont(new Font("SansSerif", 1, 12));
/*     */ 
/* 233 */       g2.draw(new Line2D.Double(this.p0.getX() + 30.0D + (this.p1X - this.values[0][0]) * stepX / this.interval, this.p0.getY() + 530.0D, this.p0.getX() + 30.0D + (this.p1X - this.values[0][0]) * stepX / this.interval, this.p0.getY() + 270.0D));
/* 234 */       g2.drawString("p1 = " + Double.toString(this.pc.getPValue1()) + "; MI >= " + SicenToComm(this.p1X) + " ; " + Integer.toString(this.p1List.size()) + " pairs", 
/* 235 */         (int)(this.p0.getX() + 35.0D + (this.p1X - this.values[0][0]) * stepX / this.interval), 
/* 236 */         (int)(this.p0.getY() + 540.0D));
/*     */ 
/* 238 */       g2.draw(new Line2D.Double(this.p0.getX() + 30.0D + (this.p2X - this.values[0][0]) * stepX / this.interval, this.p0.getY() + 560.0D, this.p0.getX() + 30.0D + (this.p2X - this.values[0][0]) * stepX / this.interval, this.p0.getY() + 300.0D));
/* 239 */       g2.drawString("p2 = " + Double.toString(this.pc.getPValue2()) + "; MI from " + SicenToComm(this.p2X) + " to " + SicenToComm(this.p2X0) + " ; " + Integer.toString(this.p2List.size()) + " pairs", 
/* 240 */         (int)(this.p0.getX() + 35.0D + (this.p2X - this.values[0][0]) * stepX / this.interval), 
/* 241 */         (int)(this.p0.getY() + 570.0D));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setMutualInformation(MutualInformation mi)
/*     */   {
/* 249 */     this.mi = mi;
/*     */ 
/* 251 */     this.p1List = mi.getListP1();
/* 252 */     this.p2List = mi.getListP2();
/* 253 */     if (this.p1List.size() >= 1) this.p1X = ((MutObjNew)this.p1List.get(this.p1List.size() - 1)).getMuinf12();
/* 254 */     if (this.p2List.size() >= 1) this.p2X = ((MutObjNew)this.p2List.get(this.p2List.size() - 1)).getMuinf12();
/* 255 */     this.p2X0 = 0.0D;
/* 256 */     if (this.p2List.size() != 0) this.p2X0 = ((MutObjNew)this.p2List.get(0)).getMuinf12();
/*     */ 
/* 258 */     this.muts = mi.getMutObj();
/*     */ 
/* 264 */     this.length = 
/* 265 */       ((int)(this.muts[0].getMuinf12() + 1.0D) - 
/* 265 */       (int)(this.muts[(this.muts.length - 1)].getMuinf12() / 1.0D - 1.0D));
/*     */ 
/* 268 */     this.values = new int[2][this.length];
/*     */ 
/* 270 */     for (int i = 0; i < this.length; i++) {
/* 271 */       this.values[0][i] = ((int)this.muts[(this.muts.length - 1)].getMuinf12() / 1 - 1 + i);
/* 272 */       this.values[1][i] = 0;
/*     */     }
/*     */ 
/* 275 */     for (int i = 0; i < this.muts.length; i++)
/* 276 */       for (int j = 0; j < this.length; j++)
/* 277 */         if (this.values[0][j] == (int)(this.muts[i].getMuinf12() / 1.0D))
/* 278 */           this.values[1][j] += 1;
/*     */   }
/*     */ 
/*     */   public void resetPc(ProbabilityCalculator pc)
/*     */   {
/* 295 */     this.pc = pc;
/* 296 */     repaint();
/*     */   }
/*     */ 
/*     */   public void drawTriangle(Graphics2D g, Color color, int x1, int y1, int x2, int y2, int x3, int y3)
/*     */   {
/* 302 */     Polygon filledPolygon = new Polygon();
/* 303 */     filledPolygon.addPoint(x1, y1);
/* 304 */     filledPolygon.addPoint(x2, y2);
/* 305 */     filledPolygon.addPoint(x3, y3);
/* 306 */     g.setColor(color);
/* 307 */     g.fill(filledPolygon);
/* 308 */     g.drawPolygon(filledPolygon);
/*     */   }
/*     */ 
/*     */   public int getMax(int[] a)
/*     */   {
/* 313 */     int min = 0;
/* 314 */     int max = 0;
/*     */ 
/* 316 */     min = a[0];
/* 317 */     max = a[0];
/*     */ 
/* 319 */     for (int i = 1; i <= a.length - 1; i++) {
/* 320 */       if (a[i] < min) {
/* 321 */         min = a[i];
/*     */       }
/* 323 */       if (a[i] > max) {
/* 324 */         max = a[i];
/*     */       }
/*     */     }
/* 327 */     return max;
/*     */   }
/*     */ 
/*     */   public static String SicenToComm(double value)
/*     */   {
/* 332 */     String retValue = null;
/*     */ 
/* 334 */     DecimalFormat df = new DecimalFormat();
/*     */ 
/* 336 */     df.setMinimumFractionDigits(1);
/*     */ 
/* 338 */     df.setMaximumFractionDigits(1);
/*     */ 
/* 340 */     retValue = df.format(value);
/*     */ 
/* 342 */     retValue = retValue.replaceAll(",", "");
/*     */ 
/* 344 */     return retValue;
/*     */   }

			public void create_pic(String outputFile,JPanel panel)
			{
				Dimension imageSize = panel.getSize();
			    BufferedImage image = new BufferedImage(imageSize.width,
			            imageSize.height, BufferedImage.TYPE_INT_ARGB);
			    Graphics2D g = image.createGraphics();
			    panel.paint(g);
			    g.dispose();
			    try {
			        File f = new File(outputFile+".jpg");
			    	ImageIO.write(image, "png", f);
			    } catch (IOException e) {
			        e.printStackTrace();
			       
			    }
			   // System.out.println("export Image -->" + f.getAbsoluteFile());
			   
			}
			
			private void  jMenuItem_save_picActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_save_execlActionPerformed
			    // TODO add your handling code here:
			    JFileChooser jfilechooser = new JFileChooser();
			    jfilechooser.setDialogType(JFileChooser.SAVE_DIALOG);
			    FileNameExtensionFilter filter = new FileNameExtensionFilter("jpg","jpeg");
			    jfilechooser.setFileFilter(filter);
			    //jfilechooser.set
			    jfilechooser.showSaveDialog(null);
			    if(jfilechooser.getSelectedFile().exists())
			    {
			           int choose= JOptionPane.showConfirmDialog(null, "The file did exist!","OOPS",JOptionPane.OK_CANCEL_OPTION);
			            //this.jTextField_batch_file.setForeground(Color.red);
			           if(choose == JOptionPane.YES_OPTION)
			               create_pic(jfilechooser.getSelectedFile().getPath(),this);
			           else
			            return;
			    }
			    else
			    {
			        //File file = jfilechooser.getSelectedFile();
			        create_pic(jfilechooser.getSelectedFile().getPath(),this);
			    }


}



/*     */ }

