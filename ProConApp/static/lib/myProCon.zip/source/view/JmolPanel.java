/*    */ package source.view;
/*    */ 
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Rectangle;
/*    */ import javax.swing.JPanel;
/*    */ import org.jmol.adapter.smarter.SmarterJmolAdapter;
/*    */ import org.jmol.api.JmolAdapter;
/*    */ import org.jmol.api.JmolSimpleViewer;
/*    */ 
/*    */ public class JmolPanel extends JPanel
/*    */ {
/* 36 */   final Dimension currentSize = new Dimension();
/* 37 */   final Rectangle rectClip = new Rectangle();
/*    */   private static final long serialVersionUID = -3661941083797644242L;
/*    */   JmolSimpleViewer viewer;
/*    */   JmolAdapter adapter;
/*    */ 
/*    */   JmolPanel()
/*    */   {
/* 19 */     this.adapter = new SmarterJmolAdapter();
/* 20 */     this.viewer = JmolSimpleViewer.allocateSimpleViewer(this, this.adapter);
/* 21 */     this.viewer.evalString("set language 'en'");
/*    */   }
/*    */ 
/*    */   public JmolSimpleViewer getViewer() {
/* 25 */     return this.viewer;
/*    */   }
/*    */ 
/*    */   public void serViewer(JmolSimpleViewer viewer) {
/* 29 */     this.viewer = viewer;
/*    */   }
/*    */ 
/*    */   public void executeCmd(String rasmolScript) {
/* 33 */     this.viewer.evalString(rasmolScript);
/*    */   }
/*    */ 
/*    */   public void paint(Graphics g)
/*    */   {
/* 40 */     getSize(this.currentSize);
/* 41 */     g.getClipBounds(this.rectClip);
/* 42 */     this.viewer.renderScreenImage(g, this.currentSize, this.rectClip);
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.JmolPanel
 * JD-Core Version:    0.6.2
 */