/*     */ package source.view;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.PrintStream;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JSeparator;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.table.TableModel;
/*     */ import source.model.MutObjNew;
/*     */ import source.model.MutualInformation;
/*     */ import source.model.ProbabilityCalculator;
/*     */ import source.model.TripletFinder;
/*     */ 
/*     */ public class MuListPanel extends JPanel
/*     */ {
/*     */   private int flag;
/*     */   private ProbabilityCalculator pc;
/*     */   private StructureDisplayPanel displaypanel;
/*     */   private ArrayList<MutObjNew> mulist;
/*     */   private MutualInformation mi;
/*     */   private TripletFinder tf;
/*     */   private ArrayList displaylist;
/*     */   private JLabel head;
/*     */   private JTable table;
/*     */   private JScrollPane pane;
/*     */   private TableModel model;
/*     */   private String[][] rows;
/*     */ 
/*     */   public MuListPanel(ProbabilityCalculator pc, StructureDisplayPanel spanel, int PvalueFlag)
/*     */   {
/*  29 */     this.flag = PvalueFlag;
/*  30 */     this.pc = pc;
/*  31 */     this.displaypanel = spanel;
/*     */ 
/*  33 */     this.rows = new String[40][4];
/*  34 */     String[] columns = { "rank", "site1", "site2", "mutual information" };
/*  35 */     this.model = new DefaultTableModel(this.rows, columns);
/*  36 */     this.table = new JTable(this.model);
/*     */ 
/*  38 */     this.table.setPreferredScrollableViewportSize(new Dimension(200, 300));
/*     */ 
/*  40 */     Font f = new Font("Serif", 0, 10);
/*  41 */     this.table.setFont(f);
/*     */ 
/*  43 */     this.table.getTableHeader().setFont(new Font("Serif", 0, 10));
/*     */ 
/*  45 */     TableColumn column3 = this.table.getColumnModel().getColumn(3);
/*  46 */     column3.setPreferredWidth(220);
/*     */ 
/*  48 */     this.table.addMouseListener(new MouseAdapter()
/*     */     {
/*     */       public void mouseClicked(MouseEvent e) {
/*  51 */         MuListPanel.this.tableClickActionPerformedMutual(MuListPanel.this.table);
/*     */       }
/*     */     });
/*  55 */     this.pane = new JScrollPane(this.table);
/*     */ 
/*  59 */     setLayout(new BorderLayout());
/*     */ 
/*  61 */     add(this.pane, "Center");
/*  62 */     JSeparator s = new JSeparator(0);
/*  63 */     Dimension ps = s.getPreferredSize();
/*  64 */     s.setPreferredSize(new Dimension(ps.width, 20));
/*     */ 
/*  66 */     this.head = new JLabel();
/*  67 */     if (this.flag == 1)
/*  68 */       this.head.setText("significant covariant pairs ( p < " + pc.getPValue1() + 
/*  69 */         " )");
/*     */     else {
/*  71 */       this.head.setText("significant covariant pairs ( p = " + pc.getPValue1() + 
/*  72 */         " ~ " + pc.getPValue2() + " ) ");
/*     */     }
/*  74 */     add(this.head, "North");
/*  75 */     add(s, "South");
/*     */   }
/*     */ 
/*     */   public void initialPc(ProbabilityCalculator pc) {
/*  79 */     this.pc = pc;
/*     */   }
/*     */ 
/*     */   public void resetPc(ProbabilityCalculator pc) {
/*  83 */     this.pc = pc;
/*  84 */     displayMuList();
/*  85 */     this.table.repaint();
/*  86 */     if (this.flag == 1)
/*  87 */       this.head.setText("significant covariant pairs (p < " + pc.getPValue1() + 
/*  88 */         " )");
/*     */     else
/*  90 */       this.head.setText("significant covariant pairs (p = " + pc.getPValue1() + 
/*  91 */         " ~ " + pc.getPValue2() + " ) ");
/*     */   }
/*     */ 
/*     */   public ProbabilityCalculator getPc()
/*     */   {
/*  96 */     return this.pc;
/*     */   }
/*     */ 
/*     */   public MutualInformation getMutualInformation() {
/* 100 */     return this.mi;
/*     */   }
/*     */ 
/*     */   public void setMutualInformation(MutualInformation mi) {
/* 104 */     this.mi = mi;
/* 105 */     this.tf = new TripletFinder(mi);
/*     */ 
/* 107 */     displayMuList();
/*     */   }
/*     */ 
/*     */   public void displayMuList()
/*     */   {
/* 113 */     System.out.println("!!!!!!!now run! displayMuList ");
/*     */ 
/* 117 */     if (this.flag == 1)
/* 118 */       this.mulist = this.mi.getListP1();
/*     */     else {
/* 120 */       this.mulist = this.mi.getListP2();
/*     */     }
/* 122 */     this.rows = new String[this.mulist.size()][4];
/*     */ 
/* 124 */     for (int i = 0; i < this.mulist.size(); i++) {
/* 125 */       this.rows[i][0] = Integer.toString(i + 1);
/* 126 */       this.rows[i][1] = this.pc.calculateSite(((MutObjNew)this.mulist.get(i)).getSite1());
/* 127 */       this.rows[i][2] = this.pc.calculateSite(((MutObjNew)this.mulist.get(i)).getSite2());
/*     */ 
/* 136 */       NumberFormat formater = 
/* 137 */         DecimalFormat.getInstance();
/* 138 */       formater.setMaximumFractionDigits(3);
/* 139 */       String rt = formater.format(((MutObjNew)this.mulist.get(i)).getMuinf12());
/* 140 */       this.rows[i][3] = rt;
/*     */     }
/*     */ 
/* 143 */     String[] columns = { "Rank", "Site1", "Site2", "Mutual Information" };
/*     */ 
/* 146 */     this.model = new DefaultTableModel(this.rows, columns) {
/*     */       public boolean isCellEditable(int row, int column) {
/* 148 */         return false;
/*     */       }
/*     */     };
/* 157 */     Font f = new Font("Serif", 0, 10);
/* 158 */     this.table.setFont(f);
/*     */ 
/* 160 */     this.table.getTableHeader().setFont(f);
/*     */ 
/* 162 */     this.table.setModel(this.model);
/*     */ 
/* 166 */     TableColumn column0 = this.table.getColumnModel().getColumn(0);
/* 167 */     column0.setPreferredWidth(30);
/*     */ 
/* 169 */     TableColumn column3 = this.table.getColumnModel().getColumn(3);
/* 170 */     column3.setPreferredWidth(90);
/*     */ 
/* 179 */     this.table.repaint();
/* 180 */     this.table.updateUI();
/*     */   }
/*     */ 
/*     */   public void tableClickActionPerformedMutual(JTable table)
/*     */   {
/* 188 */     int numRow = table.getSelectedRow();
/*     */ 
/* 192 */     MutObjNew mo = (MutObjNew)this.mulist.get(numRow);
/*     */ 
/* 194 */     this.displaypanel.displayMutual(this.pc.getActualSite(mo.getSite1()), this.pc
/* 195 */       .getActualSite(mo.getSite2()));
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.MuListPanel
 * JD-Core Version:    0.6.2
 */