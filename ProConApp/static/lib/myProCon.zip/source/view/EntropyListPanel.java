/*     */ package source.view;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.io.OutputStream;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import javax.swing.JButton;
import javax.swing.JFileChooser;
/*     */ import javax.swing.JLabel;
import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.table.TableModel;

import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
/*     */ import source.model.EntropyComparator;
/*     */ import source.model.EntropyInformation;
import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class EntropyListPanel extends JPanel
/*     */ {
/*     */   private EntropyDistributionDiagramPanel entropyDistributionDiagramPanel;
/*     */   private int choice;
/*     */   private ProbabilityCalculator pc;
/*     */   private JTable table;
/*     */   private JScrollPane pane;
/*     */   private JPanel thresholdPanel;
/*     */   private JPanel intervalPanel;
/*     */   private double threshold;
/*     */   private double interval;
/*     */   private JLabel thresholdLabel;
/*     */   private JLabel intervalLabel;
/*     */   private JTextField thresholdText;
/*     */   private JTextField intervalText;
/*     */   private JButton thresholdButton;
/*     */   private JButton intervalButton;
/*     */   private double[] entropy;
/*     */   private double[][] freq6aa;
/*     */   private double[][] freqaa;
/*     */   private Object[] EIArray;

			private javax.swing.JPopupMenu jPopupMenu_table_save;
			private javax.swing.JMenuItem jMenuItem_save_excel;
/*     */ 
/*     */   public EntropyListPanel(ProbabilityCalculator pc, EntropyDistributionDiagramPanel entropyDistributionDiagramPanel)
/*     */   {
/*  32 */     this.pc = pc;
/*  33 */     this.choice = pc.getNumberofgroup();
/*     */ 
/*  35 */     this.entropyDistributionDiagramPanel = entropyDistributionDiagramPanel;
/*     */ 
/*  37 */     this.thresholdPanel = new JPanel();
/*  38 */     this.intervalPanel = new JPanel();
/*  39 */     this.threshold = 0.0D;
/*  40 */     this.interval = 0.2D;
/*  41 */     this.thresholdLabel = new JLabel("current information threshold is " + this.threshold + 
/*  42 */       "; please enter a new value: ");
/*  43 */     this.thresholdText = new JTextField("0.0", 4);
/*  44 */     this.thresholdButton = new JButton("apply");
/*     */ 
/*  46 */     this.intervalLabel = new JLabel("current statistics interval is " + this.interval + 
/*  47 */       "; please enter a new value: ");
/*  48 */     this.intervalText = new JTextField("0.2", 4);
/*  49 */     this.intervalButton = new JButton("apply");
/*     */ 
/*  51 */     this.thresholdButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/*  55 */         if (EntropyListPanel.this.thresholdText.getText().length() != 0) {
/*  56 */           EntropyListPanel.this.threshold = Double.parseDouble(EntropyListPanel.this.thresholdText.getText());
/*     */ 
/*  58 */           EntropyListPanel.this.thresholdLabel.setText("current information threshold is " + EntropyListPanel.this.threshold + 
/*  59 */             "; please enter a new value: ");
/*     */ 
/*  61 */           EntropyListPanel.this.displayList(EntropyListPanel.this.choice);
/*     */         }
/*     */       }
/*     */     });
/*  67 */     this.intervalButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/*  71 */         if (EntropyListPanel.this.intervalText.getText().length() != 0) {
/*  72 */           EntropyListPanel.this.interval = Double.parseDouble(EntropyListPanel.this.intervalText.getText());
/*     */ 
/*  74 */           EntropyListPanel.this.intervalLabel.setText("current interval is " + EntropyListPanel.this.interval + 
/*  75 */             "; please enter a new value: ");
/*     */ 
/*  77 */           EntropyListPanel.this.displayList(EntropyListPanel.this.choice);
/*     */         }
/*     */       }
/*     */     });
/*  83 */     Object[][] rows = new Object[40][4];
/*  84 */     String[] columns = { "rank", "position", "site", 
/*  85 */       "information" };
/*  86 */     TableModel model = new DefaultTableModel(rows, columns);
/*  87 */     this.table = new JTable(model);
/*     */ 
/*  89 */     this.table.setPreferredScrollableViewportSize(new Dimension(300, 400));
/*     */ 
/*  91 */     Font f = new Font("Serif", 0, 10);
/*  92 */     this.table.setFont(f);
/*     */ 
/*  94 */     this.table.getTableHeader().setFont(new Font("Serif", 0, 10));
/*     */ 
/*  96 */     TableColumn column3 = this.table.getColumnModel().getColumn(3);
/*  97 */     column3.setPreferredWidth(220);


				jPopupMenu_table_save = new javax.swing.JPopupMenu();
				jMenuItem_save_excel = new javax.swing.JMenuItem();
				jMenuItem_save_excel.setText("Save as Excel");
				jMenuItem_save_excel.addActionListener(new java.awt.event.ActionListener() {
				    public void actionPerformed(java.awt.event.ActionEvent evt) {
				        jMenuItem_save_excelActionPerformed(evt);
				    }
				});
				jPopupMenu_table_save.add(jMenuItem_save_excel);
				table.setComponentPopupMenu(jPopupMenu_table_save);



/*     */ 
/*  99 */     this.pane = new JScrollPane(this.table);
/*     */ 
/* 102 */     this.thresholdPanel.add(this.thresholdLabel);
/* 103 */     this.thresholdPanel.add(this.thresholdText);
/* 104 */     this.thresholdPanel.add(this.thresholdButton);
/*     */ 
/* 106 */     this.intervalPanel.add(this.intervalLabel);
/* 107 */     this.intervalPanel.add(this.intervalText);
/* 108 */     this.intervalPanel.add(this.intervalButton);
/*     */ 
/* 110 */     setLayout(new BorderLayout());
/* 111 */     add(this.thresholdPanel, "North");
/* 112 */     add(this.intervalPanel, "South");
/* 113 */     add(this.pane, "Center");
/*     */   }
/*     */ 
/*     */   public void displayList(int choice)
/*     */   {
/* 119 */     this.choice = choice;
/*     */ 
/* 121 */     ArrayList entropyList = new ArrayList();
/*     */ 
/* 123 */     if (this.choice < 20) {
/* 124 */       this.entropy = this.pc.getEntropy1();
/* 125 */       this.freq6aa = this.pc.getFreq6aa();
/*     */ 
/* 127 */       for (int i = 0; i < this.entropy.length; i++)
/*     */       {
/* 129 */         if (this.freq6aa[i][this.pc.getNumberofgroup()] <= this.pc.getGapPercent())
/*     */         {
/* 131 */           EntropyInformation ei = new EntropyInformation(i + 1, this.pc
/* 132 */             .calculateSite(i), this.entropy[i]);
/* 133 */           entropyList.add(ei);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/* 139 */     else if (this.choice == 20)
/*     */     {
/* 141 */       this.entropy = this.pc.getEntropy0();
/* 142 */       this.freqaa = this.pc.getFreqaa();
/*     */ 
/* 144 */       for (int i = 0; i < this.entropy.length; i++)
/*     */       {
/* 146 */         if (this.freqaa[i][20] / this.pc.getResNumber() <= this.pc.getGapPercent())
/*     */         {
/* 148 */           EntropyInformation ei = new EntropyInformation(i + 1, this.pc
/* 149 */             .calculateSite(i), this.entropy[i]);
/* 150 */           entropyList.add(ei);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 157 */     this.EIArray = entropyList.toArray();
/*     */ 
/* 159 */     Arrays.sort(this.EIArray, new EntropyComparator());
/*     */ 
/* 161 */     this.entropyDistributionDiagramPanel.displayInformation(choice, this.EIArray, 
/* 162 */       this.threshold, this.interval);
/*     */ 
/* 164 */     String[][] rows2 = new String[this.EIArray.length][4];
/*     */ 
/* 166 */     for (int i = 0; i < this.EIArray.length; i++)
/*     */     {
/* 168 */       EntropyInformation ei = (EntropyInformation)this.EIArray[i];
/* 169 */       if (ei.getEntropy() < this.threshold) break;
/* 170 */       rows2[i][0] = Integer.toString(i + 1);
/* 171 */       rows2[i][1] = Integer.toString(ei.getPosition());
/* 172 */       rows2[i][2] = ei.getSite();
/* 173 */       rows2[i][3] = SicenToComm(ei.getEntropy());
/*     */     }
/*     */ 
/* 178 */     String[] columns = { "rank", "position", "site", 
/* 179 */       "information" };
/*     */ 
/* 181 */     TableModel model2 = new DefaultTableModel(rows2, columns) {
/*     */       public boolean isCellEditable(int row, int column) {
/* 183 */         return false;
/*     */       }
/*     */     };
/* 186 */     this.table.setModel(model2);
/*     */ 
/* 188 */     this.table.getTableHeader().setFont(new Font("Serif", 0, 10));
/*     */ 
/* 191 */     this.table.repaint();
/* 192 */     this.table.updateUI();
/*     */   }
/*     */ 
/*     */   public void resetPc(ProbabilityCalculator pc)
/*     */   {
/* 197 */     this.pc = pc;
/* 198 */     this.thresholdLabel.setText("current information threshold is " + this.threshold + 
/* 199 */       "; please input a new value:");
/* 200 */     displayList(pc.getNumberofgroup());
/*     */   }
/*     */ 
/*     */   public static String SicenToComm(double value)
/*     */   {
/* 206 */     String retValue = null;
/*     */ 
/* 208 */     DecimalFormat df = new DecimalFormat();
/*     */ 
/* 210 */     df.setMinimumFractionDigits(3);
/*     */ 
/* 212 */     df.setMaximumFractionDigits(3);
/*     */ 
/* 214 */     retValue = df.format(value);
/*     */ 
/* 216 */     retValue = retValue.replaceAll(",", "");
/*     */ 
/* 218 */     return retValue;
/*     */   }

		public void create_excel(String outputFile,JTable in_table)
		{
		   TableModel tablemodel =  in_table.getModel();
		   int colcount = tablemodel.getColumnCount();
		   int rowcount = tablemodel.getRowCount();
		   String title[] = new String[colcount];
		   for(int i=0;i<colcount;i++)
		     title[i] = tablemodel.getColumnName(i);
		
		  if(!outputFile.contains(".xls")&&!outputFile.contains(".xlsx"))
		       outputFile += ".xls";
		  String targetfile = outputFile;// 输出的excel文件名
		  System.out.println(targetfile);
		String worksheet = "List";// 输出的excel文件工作表名
		WritableWorkbook workbook = null;
		try {
		OutputStream os=new FileOutputStream(targetfile);
		workbook=Workbook.createWorkbook(os);
		WritableSheet sheet = workbook.createSheet(worksheet, 0); // 添加第一个工作表
		jxl.write.Label label = null;
		for (int i=0; i<title.length; i++){
		// Label(列号,行号 ,内容 )
		label = new jxl.write.Label(i, 0, title[i]); //把标题放到第一行
		sheet.addCell(label);
		}
		for(int i=0;i<rowcount;i++)
		   for(int j=0;j<colcount;j++)
		    {
		        //data[i][j] = tablemodel.getValueAt(i, j).toString();
		       label = new jxl.write.Label(j, i+1,  tablemodel.getValueAt(i, j).toString()); //j col,i+1 row
		       System.out.println(label+"\n");
		       sheet.addCell(label);
		     }
		
		workbook.write();
		workbook.close();
		os.close();
		}
		catch (Exception e) {
		e.printStackTrace();
		}
		
		}
		
		private void jMenuItem_save_excelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_save_execlActionPerformed
		    // TODO add your handling code here:
		    JFileChooser jfilechooser = new JFileChooser();
		    jfilechooser.setDialogType(JFileChooser.SAVE_DIALOG);
		    FileNameExtensionFilter filter = new FileNameExtensionFilter("xls","xlsx");
		    jfilechooser.setFileFilter(filter);
		    //jfilechooser.set
		    jfilechooser.showSaveDialog(null);
		    if(jfilechooser.getSelectedFile().exists())
		    {
		           int choose= JOptionPane.showConfirmDialog(null, "The file did exist!","OOPS",JOptionPane.OK_CANCEL_OPTION);
		            //this.jTextField_batch_file.setForeground(Color.red);
		           if(choose == JOptionPane.YES_OPTION)
		               create_excel(jfilechooser.getSelectedFile().getPath(),this.table);
		           else
		            return;
		    }
		    else
		    {
		        //File file = jfilechooser.getSelectedFile();
		        create_excel(jfilechooser.getSelectedFile().getPath(),this.table);
		    }
		
		
		}
}//GEN-LAST:event_jMenuItem_save_execlActionPerformed
