/*     */ package source.view;
/*     */ 
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ColorModel;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.swing.JPanel;
/*     */ import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class TripletDisplayPanel extends JPanel
/*     */ {
/*     */   private TripletListPanel tripletlistpanel;
/*     */   private BufferedImage image;
/*     */   private int displayTriplet;
/*     */ 
/*     */   public TripletDisplayPanel(TripletListPanel tripletlistpanel)
/*     */   {
/*  28 */     this.tripletlistpanel = tripletlistpanel;
/*  29 */     this.displayTriplet = 0;
/*     */   }
/*     */ 
/*     */   public void paintComponent(Graphics g)
/*     */   {
/*  37 */     super.paintComponents(g);
/*  38 */     Graphics2D g2 = (Graphics2D)g;
/*     */ 
/*  40 */     if (this.tripletlistpanel.getPc().getSeqNumber() != 0)
/*     */     {
/*  42 */       String head1 = "current reference sequence is: " + 
/*  44 */         Integer.toString(this.tripletlistpanel.getPc().getReference() + 1);
/*  45 */       g2.setFont(new Font("Dialog", 1, 14));
/*  46 */       g2.drawString(head1, 40, 30);
/*  47 */       File directory = new File("..");
/*     */ 
/*  49 */       if (getDisplayTriplet() == 3) {
/*  50 */         String head2 = "triplets found among the covariant pairs";
/*  51 */         g2.setFont(new Font("Dialog", 0, 13));
/*  52 */         g2.drawString(head2, 40, 50);
/*     */ 
/*  54 */         if (System.getProperty("os.name").substring(0, 7).equals("Windows"))
/*     */         {
/*  56 */           g2.drawString("the diagram file is stored in the route \"\\output\\Triplets.dot\" ", 40, 650);
/*     */           try
/*     */           {
/*  62 */             this.image = ImageIO.read(new File(directory.getCanonicalPath() + 
/*  63 */               "\\output\\Triplets.png"));
/*     */ 
/*  65 */             if ((this.image.getHeight() > 600) || (this.image.getWidth() > 750)) //break label841;
/*  66 */             if (this.image.getHeight() <= this.image.getWidth())
/*  67 */               this.image = resizeImage(this.image, 750, 600 * 
/*  68 */                 this.image.getHeight() / this.image.getWidth());
/*     */             else
/*  70 */               this.image = resizeImage(this.image, 750 * this.image.getWidth() / 
/*  71 */                 this.image.getHeight(), 600);
/*     */           }
/*     */           catch (Exception e) {
/*  74 */             e.printStackTrace();
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*  79 */       else if (getDisplayTriplet() == 1) {
/*  80 */         String head2 = "covariant pairs with p values less than " + 
/*  81 */           this.tripletlistpanel.getPc().getPValue1();
/*  82 */         g2.setFont(new Font("Dialog", 0, 13));
/*  83 */         g2.drawString(head2, 40, 50);
/*     */ 
/*  85 */         if (System.getProperty("os.name").substring(0, 7).equals("Windows"))
/*     */         {
/*  88 */           g2.drawString("the diagram file is stored in the route \"\\output\\pairs(P value smaller than P1).dot\" ", 40, 650);
/*     */           try
/*     */           {
/*  91 */             this.image = ImageIO.read(new File(directory.getCanonicalPath() + 
/*  92 */               "\\output\\pairs(P value smaller than P1).png"));
/*     */ 
/*  94 */             if ((this.image.getHeight() > 600)|| (this.image.getWidth() > 750)) //break label841;
/*  95 */             if (this.image.getHeight() <= this.image.getWidth())
/*  96 */               this.image = resizeImage(this.image, 750, 600 * 
/*  97 */                 this.image.getHeight() / this.image.getWidth());
/*     */             else
/*  99 */               this.image = resizeImage(this.image, 750 * this.image.getWidth() / 
/* 100 */                 this.image.getHeight(), 600);
/*     */           }
/*     */           catch (IOException e) {
/* 103 */             e.printStackTrace();
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 108 */       else if (getDisplayTriplet() == 2)
/*     */       {
/* 112 */         String head2 = "covariant pairs with p values between " + 
/* 113 */           this.tripletlistpanel.getPc().getPValue1() + " and " + 
/* 114 */           this.tripletlistpanel.getPc().getPValue2();
/* 115 */         g2.setFont(new Font("Dialog", 0, 13));
/* 116 */         g2.drawString(head2, 40, 50);
/*     */ 
/* 118 */         if (System.getProperty("os.name").substring(0, 7).equals("Windows"))
/*     */         {
/* 120 */           g2.drawString("the diagram file is stored in the route \"\\output\\pairs(P value between P1 and P2).dot\" ", 40, 650);
/*     */           try
/*     */           {
/* 123 */             this.image = ImageIO.read(new File(directory.getCanonicalPath() + 
/* 124 */               "\\output\\pairs(P value between P1 and P2).png"));
/*     */ 
/* 126 */             if ((this.image.getHeight() > 600) || (this.image.getWidth() > 750))
/* 127 */               if (this.image.getHeight() <= this.image.getWidth())
/* 128 */                 this.image = resizeImage(this.image, 750, 600 * 
/* 129 */                   this.image.getHeight() / this.image.getWidth());
/*     */               else
/* 131 */                 this.image = resizeImage(this.image, 750 * this.image.getWidth() / 
/* 132 */                   this.image.getHeight(), 600);
/*     */           }
/*     */           catch (IOException e) {
/* 135 */             e.printStackTrace();
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 141 */       label841: g2.drawImage(this.image, 40, 90, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getDisplayTriplet()
/*     */   {
/* 149 */     return this.displayTriplet;
/*     */   }
/*     */ 
/*     */   public void setDisplayTriplet(int display) {
/* 153 */     this.displayTriplet = display;
/* 154 */     if (!System.getProperty("os.name").substring(0, 7).equals("Windows"))
/*     */     {
/* 156 */       File directory = new File("..");
/*     */       try
/*     */       {
/* 161 */         String cLine = new String();
/*     */ 
/* 163 */         if (display == 1) {
/* 164 */           cLine = "open -a " + directory.getCanonicalPath() + "/bin/graphviz.app " + 
/* 165 */             directory.getCanonicalPath() + "/output/pairs(P<P1).dot";
/*     */         }
/* 167 */         else if (display == 2)
/* 168 */           cLine = "open -a " + directory.getCanonicalPath() + "/bin/graphviz.app " + 
/* 168 */             directory.getCanonicalPath() + "/output/pairs(P1<P<P2).dot";
/*     */         else {
/* 170 */           cLine = "open -a " + directory.getCanonicalPath() + "/bin/graphviz.app " + 
/* 171 */             directory.getCanonicalPath() + "/output/Triplets.dot";
/*     */         }
/* 173 */         System.out.println("hellohellohello!!!!!!!" + cLine);
/* 174 */         Process p = Runtime.getRuntime().exec(cLine);
/*     */ 
/* 176 */         p.waitFor();
/* 177 */         p.destroy();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 182 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static BufferedImage resizeImage(BufferedImage bufferedimage, int w, int h)
/*     */   {
/* 192 */     int type = bufferedimage.getColorModel().getTransparency();
/*     */     BufferedImage img;
/*     */     Graphics2D graphics2d;
/* 195 */     (graphics2d = (img = new BufferedImage(w, h, type)).createGraphics())
/* 196 */       .setRenderingHint(RenderingHints.KEY_INTERPOLATION, 
/* 197 */       RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/* 198 */     graphics2d.drawImage(bufferedimage, 0, 0, w, h, 0, 0, bufferedimage
/* 199 */       .getWidth(), bufferedimage.getHeight(), null);
/* 200 */     graphics2d.dispose();
/* 201 */     return img;
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\妗��\SOD1 ���\ProCon-20121023.jar
 * Qualified Name:     source.view.TripletDisplayPanel
 * JD-Core Version:    0.6.2
 */