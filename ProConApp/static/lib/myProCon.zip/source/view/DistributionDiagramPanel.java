/*     */ package source.view;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import javax.swing.JPanel;
/*     */ import org.jfree.chart.ChartFactory;
/*     */ import org.jfree.chart.ChartPanel;
/*     */ import org.jfree.chart.JFreeChart;
/*     */ import org.jfree.chart.axis.CategoryAxis;
/*     */ import org.jfree.chart.axis.ValueAxis;
/*     */ import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
/*     */ import org.jfree.chart.plot.CategoryPlot;
/*     */ import org.jfree.chart.plot.PlotOrientation;
/*     */ import org.jfree.chart.renderer.category.BarRenderer;
/*     */ import org.jfree.data.category.CategoryDataset;
/*     */ import org.jfree.data.category.DefaultCategoryDataset;
/*     */ import source.model.ProbabilityCalculator;
/*     */ import source.model.RankProbaa;
/*     */ 
/*     */ public class DistributionDiagramPanel extends JPanel
/*     */ {
/*     */   private Image image;
/*     */   private Image image2;
/*     */   private ProbabilityCalculator pc;
/*     */   private int siteposition;
/*     */   private ChartPanel chartpanel1;
/*     */   private ChartPanel chartpanel2;
/*     */   private JFreeChart chart1;
/*     */   private JFreeChart chart2;
/*     */ 
/*     */   public DistributionDiagramPanel(ProbabilityCalculator pc)
/*     */   {
/*  34 */     this.pc = pc;
/*  35 */     this.siteposition = 0;
/*  36 */     CategoryDataset dataset = new DefaultCategoryDataset();
/*     */ 
/*  38 */     this.chart1 = ChartFactory.createBarChart("amino acid distribution", 
/*  39 */       "amino acid", 
/*  40 */       "frequency", 
/*  41 */       dataset, 
/*  42 */       PlotOrientation.VERTICAL, 
/*  44 */       false, 
/*  46 */       false, 
/*  47 */       false);
/*     */ 
/*  50 */     this.chart2 = 
/*  51 */       ChartFactory.createBarChart(
/*  52 */       "amino acid distribution according to some properties", 
/*  53 */       "amino acid with some properties", 
/*  54 */       "frequency", 
/*  55 */       dataset, 
/*  56 */       PlotOrientation.VERTICAL, 
/*  58 */       false, 
/*  60 */       false, 
/*  61 */       false);
/*     */ 
/*  64 */     this.chartpanel1 = new ChartPanel(this.chart1);
/*  65 */     this.chartpanel2 = new ChartPanel(this.chart2);
/*  66 */     this.chartpanel1.setPreferredSize(new Dimension(1000, 250));
/*  67 */     this.chartpanel2.setPreferredSize(new Dimension(1000, 250));
/*  68 */     add(this.chartpanel1);
/*  69 */     add(this.chartpanel2);
/*     */   }
/*     */ 
/*     */   public void paintComponent(Graphics g)
/*     */   {
/*  75 */     if (this.pc.getSeqNumber() != 0)
/*     */     {
/*  79 */       CategoryDataset dataset = getDataSet();
/*  80 */       JFreeChart chart1 = ChartFactory.createBarChart(
/*  81 */         "amino acid distribution", 
/*  82 */         "amino acid", 
/*  83 */         "frequency", 
/*  84 */         dataset, 
/*  85 */         PlotOrientation.VERTICAL, 
/*  87 */         false, 
/*  89 */         false, 
/*  90 */         false);
/*     */ 
/* 110 */       CategoryPlot plot1 = chart1.getCategoryPlot();
/* 111 */       CategoryAxis domainAxis2 = plot1.getDomainAxis();
/* 112 */       domainAxis2.setUpperMargin(0.05D);
/*     */ 
/* 114 */       ValueAxis rangeAxis = plot1.getRangeAxis();
/*     */ 
/* 116 */       rangeAxis.setUpperMargin(0.1D);
/*     */ 
/* 118 */       BarRenderer barrenderer1 = (BarRenderer)plot1.getRenderer();
/*     */ 
/* 122 */       barrenderer1
/* 123 */         .setItemLabelGenerator(new StandardCategoryItemLabelGenerator());
/* 124 */       barrenderer1.setItemLabelFont(new Font("黑体", 0, 8));
/* 125 */       barrenderer1.setItemLabelsVisible(true);
/*     */ 
/* 127 */       this.chartpanel1.setChart(chart1);
/* 128 */       this.chartpanel1.repaint();
/*     */     }
/*     */ 
/* 132 */     if (this.pc.getSeqNumber() != 0)
/*     */     {
/* 134 */       String diagramtitle = new String();
/* 135 */       String diagramtag = new String();
/* 136 */       if (this.pc.getDefault()) {
/* 137 */         diagramtitle = "amino acid distribution according to physicochemical properties(default)";
/* 138 */         diagramtag = "amino acid with physicochemical properties";
/*     */       }
/*     */       else {
/* 141 */         diagramtitle = "amino acid distribution according to user setting groups";
/* 142 */         diagramtag = "amino acid in user setting groups";
/*     */       }
/*     */ 
/* 145 */       CategoryDataset dataset2 = getDataSet2();
/* 146 */       JFreeChart chart2 = 
/* 147 */         ChartFactory.createBarChart(
/* 148 */         diagramtitle, 
/* 149 */         diagramtag, 
/* 150 */         "frequency", 
/* 151 */         dataset2, 
/* 152 */         PlotOrientation.VERTICAL, 
/* 154 */         false, 
/* 156 */         false, 
/* 157 */         false);
/*     */ 
/* 160 */       CategoryPlot plot2 = chart2.getCategoryPlot();
/* 161 */       CategoryAxis domainAxis2 = plot2.getDomainAxis();
/* 162 */       domainAxis2.setUpperMargin(0.05D);
/*     */ 
/* 164 */       ValueAxis rangeAxis = plot2.getRangeAxis();
/*     */ 
/* 166 */       rangeAxis.setUpperMargin(0.1D);
/*     */ 
/* 168 */       BarRenderer barrenderer = (BarRenderer)plot2.getRenderer();
/*     */ 
/* 172 */       barrenderer
/* 173 */         .setItemLabelGenerator(new StandardCategoryItemLabelGenerator());
/* 174 */       barrenderer.setItemLabelFont(new Font("黑体", 0, 10));
/* 175 */       barrenderer.setItemLabelsVisible(true);
/*     */ 
/* 177 */       this.chartpanel2.setChart(chart2);
/* 178 */       this.chartpanel2.repaint();
/*     */     }
/*     */   }
/*     */ 
/*     */   private CategoryDataset getDataSet()
/*     */   {
/* 189 */     DefaultCategoryDataset dataset = new DefaultCategoryDataset();
/*     */ 
/* 193 */     RankProbaa[][] rpaa = this.pc.getProbaa();
/*     */ 
/* 195 */     double[][] freqaa = this.pc.getFreqaa();
/*     */ 
/* 197 */     for (int i = 0; i < 21; i++) {
/* 198 */       char c = rpaa[this.siteposition][i].getRankaa();
/* 199 */       dataset.addValue(freqaa[this.siteposition][i], "Amino Acid", 
/* 200 */         String.valueOf(c));
/*     */     }
/*     */ 
/* 203 */     return dataset;
/*     */   }
/*     */ 
/*     */   private CategoryDataset getDataSet2()
/*     */   {
/* 208 */     DefaultCategoryDataset dataset = new DefaultCategoryDataset();
/*     */ 
/* 210 */     double[][] freq6aa = this.pc.getFreq6aa();
/* 211 */     String[] physicochemical = { "hydrophobic", "AT", "negative", 
/* 212 */       "conformational", "polar", "positive", "gap" };
/*     */ 
/* 214 */     String[] usersetgroup = new String[this.pc.getNumberofgroup() + 1];
/* 215 */     usersetgroup[this.pc.getNumberofgroup()] = "gap";
/* 216 */     int[] group = this.pc.getGroup();
/* 217 */     for (int i = 0; i < this.pc.getNumberofgroup(); i++) {
/* 218 */       usersetgroup[i] = new String();
/* 219 */       for (int j = 0; j < 20; j++) {
/* 220 */         if (group[j] == i)
/*     */         {
/*     */           int tmp131_129 = i;
/*     */           String[] tmp131_127 = usersetgroup; tmp131_127[tmp131_129] = (tmp131_127[tmp131_129] + ProbabilityCalculator.RESIDUE[j]);
/*     */         }
/*     */       }
/*     */     }
/* 224 */     if (this.pc.getDefault()) {
/* 225 */       for (int i = 0; i < this.pc.getNumberofgroup() + 1; i++) {
/* 226 */         dataset
/* 227 */           .addValue(
/* 228 */           freq6aa[this.siteposition][i], 
/* 229 */           "amino acid grouped according to physicochemical properties (default setting)", 
/* 230 */           physicochemical[i]);
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 236 */       for (int i = 0; i < this.pc.getNumberofgroup() + 1; i++) {
/* 237 */         dataset
/* 238 */           .addValue(
/* 239 */           freq6aa[this.siteposition][i], 
/* 240 */           "amino acid distribution according to user setting groups", 
/* 241 */           usersetgroup[i]);
/*     */       }
/*     */     }
/* 244 */     return dataset;
/*     */   }
/*     */ 
/*     */   public void resetPc(ProbabilityCalculator pc) {
/* 248 */     this.pc = pc;
/*     */   }
/*     */ 
/*     */   public void setSite(int site)
/*     */   {
/* 253 */     this.siteposition = site;
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.DistributionDiagramPanel
 * JD-Core Version:    0.6.2
 */