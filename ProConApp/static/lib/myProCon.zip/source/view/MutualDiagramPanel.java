/*     */ package source.view;
/*     */ 
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.awt.geom.Line2D.Double;
/*     */ import java.awt.geom.Line2D.Float;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
/*     */ import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
import javax.swing.filechooser.FileNameExtensionFilter;

/*     */ import source.model.MutInfo;
/*     */ import source.model.MutObjNew;
/*     */ import source.model.MutualInformation;
import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class MutualDiagramPanel extends JPanel
/*     */ {
/*     */   private ProbabilityCalculator pc;
/*     */   private MutualInformation mi;
/*     */   private float[][] detail;
/*     */   private int site1;
/*     */   private int site2;
/*     */   private double muinf12;
/* 391 */   private static double ANGLE = 0.5235987755982988D;
/*     */   private double SPACE;
/* 393 */   private static double SPACE2 = 20.0D;
/* 394 */   private static double XSTEP = 20.0D;
/* 395 */   private static double YSTEP = 15.0D;
/* 396 */   private static double X0 = 50.0D;
/* 397 */   private static double Y0 = 280.0D;

			private javax.swing.JPopupMenu jPopupMenu_save;
			private javax.swing.JMenuItem jMenuItem_save_pic;
/*     */ 
/*     */   public MutualDiagramPanel(ProbabilityCalculator pc)
/*     */   {
/*  23 */     this.detail = new float[20][20];
/*  24 */     this.pc = pc;
/*  25 */     this.SPACE = 2.5D;


				jPopupMenu_save = new javax.swing.JPopupMenu();
				jMenuItem_save_pic = new javax.swing.JMenuItem();
				jMenuItem_save_pic.setText("Save as JPEG");
				jMenuItem_save_pic.addActionListener(new java.awt.event.ActionListener() {
				    public void actionPerformed(java.awt.event.ActionEvent evt) {
				       jMenuItem_save_picActionPerformed(evt);
				    }
				});
				jPopupMenu_save.add(jMenuItem_save_pic);
				this.setComponentPopupMenu(jPopupMenu_save);

/*     */   }
/*     */ 
/*     */   public void paintComponent(Graphics g) {
/*  29 */     super.paintComponents(g);
/*  30 */     Graphics2D g2 = (Graphics2D)g;
/*     */ 
/*  36 */     if ((this.mi != null) && (!this.mi.getGroupFlag()))
/*     */     {
/*  39 */       int groupnumber = this.pc.getNumberofgroup();
/*  40 */       String[] groupnames = this.pc.getGroupNames();
/*     */ 
/*  42 */       g2.setFont(new Font("Dialog", 1, 14));
/*  43 */       g2.setColor(Color.BLUE);
/*     */ 
/*  45 */       g2.drawString("details of covariant aas for " + Integer.toString(groupnumber) + " alphabet", 200, 20);
/*  46 */       g2.setColor(Color.BLACK);
/*     */ 
/*  49 */       double newXSTEP = XSTEP * 20.0D / groupnumber;
/*  50 */       double newYSTEP = YSTEP * 20.0D / groupnumber;
/*     */ 
/*  52 */       g2.draw(new Line2D.Double(X0, Y0 - SPACE2 - this.SPACE * ((int)(this.muinf12 / 5.0D) + 2) * 
/*  53 */         5.0D, X0, Y0));
/*  54 */       g2.draw(new Line2D.Double(X0, Y0, X0 + (groupnumber - 1) * newXSTEP, Y0));
/*  55 */       g2.draw(new Line2D.Double(X0 + (groupnumber - 1) * newXSTEP, Y0, X0 + (groupnumber - 1) * newXSTEP, Y0 - 
/*  56 */         SPACE2));
/*  57 */       g2.draw(new Line2D.Double(X0 + (groupnumber - 1) * newXSTEP + newYSTEP * (groupnumber - 1) * 
/*  58 */         Math.cos(ANGLE), Y0 - newYSTEP * (groupnumber - 1) * Math.sin(ANGLE), X0 + 380.0D + 
/*  59 */         newYSTEP * (groupnumber - 1) * Math.cos(ANGLE), Y0 - newYSTEP * (groupnumber - 1) * 
/*  60 */         Math.sin(ANGLE) - SPACE2));
/*  61 */       g2.draw(new Line2D.Double(X0 + (groupnumber - 1) * newXSTEP, Y0, X0 + (groupnumber - 1) * newXSTEP + (groupnumber - 1) * 
/*  62 */         newYSTEP * Math.cos(ANGLE), Y0 - newYSTEP * (groupnumber - 1) * Math.sin(ANGLE)));
/*     */ 
/*  64 */       g2.setFont(new Font("Dialog", 0, 9));
/*     */ 
/*  66 */       int kk = 1;
/*  67 */       if (this.SPACE <= 2.0D) kk = 2;
/*  68 */       if (this.SPACE <= 1.0D) kk = 4;
/*  69 */       if (this.SPACE <= 0.5D) kk = 8;
/*     */ 
/*  71 */       for (int i = -1; i <= (int)(this.muinf12 / 5.0D) + 2; i += kk) {
/*  72 */         g2.draw(new Line2D.Double(X0, Y0 - SPACE2 - i * 5 * this.SPACE, X0 + 
/*  73 */           this.SPACE, Y0 - SPACE2 - i * 5 * this.SPACE));
/*  74 */         String mark = Integer.toString(i * 5);
/*  75 */         g2.drawString(mark, (int)X0 - 15, 
/*  76 */           (int)(Y0 - SPACE2 - i * 5 * 
/*  76 */           this.SPACE));
/*     */       }
/*     */ 
/*  81 */       for (int i = 0; i < groupnumber; i++) {
/*  82 */         g2.draw(new Line2D.Double(X0 + i * newXSTEP, Y0, X0 + i * newXSTEP, Y0 - 
/*  83 */           this.SPACE));
/*  84 */         g2.draw(new Line2D.Double(X0 + (groupnumber - 1) * newXSTEP + i * newYSTEP * 
/*  85 */           Math.cos(ANGLE), Y0 - i * newYSTEP * Math.sin(ANGLE), X0 + 
/*  86 */           (groupnumber - 1) * newXSTEP + i * newYSTEP * Math.cos(ANGLE), Y0 - i * newYSTEP * 
/*  87 */           Math.sin(ANGLE) - this.SPACE));
/*  88 */         String message = groupnames[i].toString();
/*  89 */         if (i % 2 == 0)
/*  90 */           g2.drawString(message, (int)(X0 + i * newXSTEP - 10.0D), 
/*  91 */             (int)(Y0 + 15.0D));
/*     */         else {
/*  93 */           g2.drawString(message, (int)(X0 + i * newXSTEP - 10.0D), 
/*  94 */             (int)(Y0 + 25.0D));
/*     */         }
/*  96 */         g2.drawString(message, 
/*  97 */           (int)(X0 + (groupnumber - 1) * newXSTEP + i * newYSTEP * 
/*  97 */           Math.cos(ANGLE) + 10.0D), 
/*  98 */           (int)(Y0 + 5.0D - i * newYSTEP * 
/*  98 */           Math.sin(ANGLE)));
/*     */       }
/*     */ 
/* 101 */       if ((this.site1 > 0) && (this.site2 > 0)) {
/* 102 */         String site1String = "residues at site " + Integer.toString(this.site1) + 
/* 103 */           " " + this.pc.calculateSite(this.site1 - 1);
/* 104 */         String site2String = "residues at site " + Integer.toString(this.site2) + 
/* 105 */           " " + this.pc.calculateSite(this.site2 - 1);
/*     */ 
/* 107 */         g2.setFont(new Font("Dialog", 1, 11));
/* 108 */         g2.setColor(Color.BLUE);
/*     */ 
/* 110 */         g2.drawString(site1String, (int)(X0 + 100.0D), (int)(Y0 + 50.0D));
/* 111 */         g2.drawString(site2String, (int)(X0 + newXSTEP * (groupnumber - 1) + 150.0D), 
/* 112 */           (int)(Y0 - 40.0D));
/*     */       }
/*     */ 
/* 116 */       g2.setFont(new Font("Dialog", 1, 10));
/* 117 */       g2.setColor(Color.RED);
/* 118 */       for (int i = 0; i < groupnumber - 1; i++)
/*     */       {
/* 121 */         for (int j = 0; j < groupnumber - 1; j++) {
/* 122 */           double x1 = X0 + newXSTEP * i + newYSTEP * j * Math.cos(ANGLE);
/* 123 */           double y1 = Y0 - newYSTEP * j * Math.sin(ANGLE);
/*     */ 
/* 125 */           double x2 = X0 + newXSTEP * i + newYSTEP * (j + 1) * Math.cos(ANGLE);
/* 126 */           double y2 = Y0 - newYSTEP * (j + 1) * Math.sin(ANGLE);
/*     */ 
/* 128 */           double x3 = X0 + newXSTEP * (i + 1) + newYSTEP * j * Math.cos(ANGLE);
/* 129 */           double y3 = y1;
/*     */ 
/* 134 */           double x10 = x1;
/* 135 */           double y10 = y1 - SPACE2 - this.detail[i][j] * this.SPACE;
/*     */ 
/* 137 */           double x20 = x2;
/* 138 */           double y20 = y2 - SPACE2 - this.detail[i][(j + 1)] * this.SPACE;
/*     */ 
/* 140 */           double x30 = x3;
/* 141 */           double y30 = y3 - SPACE2 - this.detail[(i + 1)][j] * this.SPACE;
/*     */ 
/* 143 */           g2.draw(new Line2D.Double(x10, y10, x20, y20));
/* 144 */           g2.draw(new Line2D.Double(x10, y10, x30, y30));
/*     */         }
/*     */       }
/*     */ 
/* 148 */       for (int i = 0; i < groupnumber - 1; i++)
/*     */       {
/* 157 */         double x1 = X0 + newXSTEP * i + (groupnumber - 1) * newYSTEP * Math.cos(ANGLE);
/* 158 */         double y1 = Y0 - (groupnumber - 1) * newYSTEP * Math.sin(ANGLE);
/*     */ 
/* 160 */         double x2 = X0 + newXSTEP * (i + 1) + 380.0D * Math.cos(ANGLE);
/* 161 */         double y2 = y1;
/*     */ 
/* 165 */         x1 = X0 + (groupnumber - 1) * newXSTEP + newYSTEP * i * Math.cos(ANGLE);
/* 166 */         y1 = Y0 - newYSTEP * i * Math.sin(ANGLE) - this.detail[(groupnumber - 1)][i] * this.SPACE - 
/* 167 */           SPACE2;
/*     */ 
/* 169 */         x2 = X0 + (groupnumber - 1) * newXSTEP + newYSTEP * (i + 1) * Math.cos(ANGLE);
/* 170 */         y2 = Y0 - newYSTEP * (i + 1) * Math.sin(ANGLE) - this.detail[(groupnumber - 1)][(i + 1)] * 
/* 171 */           this.SPACE - SPACE2;
/*     */ 
/* 173 */         g2.draw(new Line2D.Double(x1, y1, x2, y2));
/*     */ 
/* 175 */         x1 = X0 + newXSTEP * i + (groupnumber - 1) * newYSTEP * Math.cos(ANGLE);
/* 176 */         y1 = Y0 - (groupnumber - 1) * newYSTEP * Math.sin(ANGLE) - this.detail[i][(groupnumber - 1)] * this.SPACE - 
/* 177 */           SPACE2;
/*     */ 
/* 179 */         x2 = X0 + newXSTEP * (i + 1) + (groupnumber - 1) * newYSTEP * Math.cos(ANGLE);
/* 180 */         y2 = Y0 - (groupnumber - 1) * newYSTEP * Math.sin(ANGLE) - this.detail[(i + 1)][(groupnumber - 1)] * this.SPACE - 
/* 181 */           SPACE2;
/*     */ 
/* 183 */         g2.draw(new Line2D.Double(x1, y1, x2, y2));
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 190 */       g2.setFont(new Font("Dialog", 1, 14));
/* 191 */       g2.setColor(Color.BLUE);
/* 192 */       g2.drawString("details of covariant aas for 20 alphabet", 220, 20);
/* 193 */       g2.setColor(Color.BLACK);
/*     */ 
/* 195 */       g2.draw(new Line2D.Double(X0, Y0 - SPACE2 - this.SPACE * ((int)(this.muinf12 / 5.0D) + 2) * 
/* 196 */         5.0D, X0, Y0));
/* 197 */       g2.draw(new Line2D.Double(X0, Y0, X0 + 19.0D * XSTEP, Y0));
/* 198 */       g2.draw(new Line2D.Double(X0 + 19.0D * XSTEP, Y0, X0 + 19.0D * XSTEP, Y0 - 
/* 199 */         SPACE2));
/* 200 */       g2.draw(new Line2D.Double(X0 + 19.0D * XSTEP + YSTEP * 19.0D * 
/* 201 */         Math.cos(ANGLE), Y0 - YSTEP * 19.0D * Math.sin(ANGLE), X0 + 380.0D + 
/* 202 */         YSTEP * 19.0D * Math.cos(ANGLE), Y0 - YSTEP * 19.0D * 
/* 203 */         Math.sin(ANGLE) - SPACE2));
/* 204 */       g2.draw(new Line2D.Double(X0 + 19.0D * XSTEP, Y0, X0 + 19.0D * XSTEP + 19.0D * 
/* 205 */         YSTEP * Math.cos(ANGLE), Y0 - YSTEP * 19.0D * Math.sin(ANGLE)));
/*     */ 
/* 207 */       g2.setFont(new Font("Dialog", 0, 9));
/*     */ 
/* 209 */       int kk = 1;
/* 210 */       if (this.SPACE <= 2.0D) kk = 2;
/* 211 */       if (this.SPACE <= 1.0D) kk = 4;
/* 212 */       if (this.SPACE <= 0.5D) kk = 8;
/*     */ 
/* 214 */       for (int i = -1; i <= (int)(this.muinf12 / 5.0D) + 2; i += kk) {
/* 215 */         g2.draw(new Line2D.Double(X0, Y0 - SPACE2 - i * 5 * this.SPACE, X0 + 
/* 216 */           this.SPACE, Y0 - SPACE2 - i * 5 * this.SPACE));
/* 217 */         String mark = Integer.toString(i * 5);
/* 218 */         g2.drawString(mark, (int)X0 - 15, 
/* 219 */           (int)(Y0 - SPACE2 - i * 5 * 
/* 219 */           this.SPACE));
/*     */       }
/*     */ 
/* 222 */       for (int i = 0; i < 20; i++) {
/* 223 */         g2.draw(new Line2D.Double(X0 + i * XSTEP, Y0, X0 + i * XSTEP, Y0 - 
/* 224 */           this.SPACE));
/* 225 */         g2.draw(new Line2D.Double(X0 + 19.0D * XSTEP + i * YSTEP * 
/* 226 */           Math.cos(ANGLE), Y0 - i * YSTEP * Math.sin(ANGLE), X0 + 
/* 227 */           19.0D * XSTEP + i * YSTEP * Math.cos(ANGLE), Y0 - i * YSTEP * 
/* 228 */           Math.sin(ANGLE) - this.SPACE));
/* 229 */         String message = MutualDetailPanel.columns[(i + 1)].toString();
/* 230 */         if (i % 2 == 0)
/* 231 */           g2.drawString(message, (int)(X0 + i * XSTEP), 
/* 232 */             (int)(Y0 + 15.0D));
/* 233 */         else g2.drawString(message, (int)(X0 + i * XSTEP), 
/* 234 */             (int)(Y0 + 25.0D));
/* 235 */         g2.drawString(message, 
/* 236 */           (int)(X0 + 19.0D * XSTEP + i * YSTEP * 
/* 236 */           Math.cos(ANGLE) + 10.0D), 
/* 237 */           (int)(Y0 + 10.0D - i * YSTEP * 
/* 237 */           Math.sin(ANGLE)));
/*     */       }
/*     */ 
/* 240 */       if ((this.site1 > 0) && (this.site2 > 0)) {
/* 241 */         String site1String = "residues at site " + Integer.toString(this.site1) + 
/* 242 */           " " + this.pc.calculateSite(this.site1 - 1);
/* 243 */         String site2String = "residues at site " + Integer.toString(this.site2) + 
/* 244 */           " " + this.pc.calculateSite(this.site2 - 1);
/*     */ 
/* 246 */         g2.setFont(new Font("Dialog", 1, 11));
/* 247 */         g2.setColor(Color.BLUE);
/* 248 */         g2.drawString(site1String, (int)(X0 + 100.0D), (int)(Y0 + 50.0D));
/* 249 */         g2.drawString(site2String, (int)(X0 + XSTEP * 19.0D + 150.0D), 
/* 250 */           (int)(Y0 - 40.0D));
/*     */       }
/*     */ 
/* 254 */       g2.setFont(new Font("Dialog", 1, 10));
/* 255 */       g2.setColor(Color.RED);
/* 256 */       for (int i = 0; i < 19; i++)
/*     */       {
/* 259 */         for (int j = 0; j < 19; j++) {
/* 260 */           double x1 = X0 + XSTEP * i + YSTEP * j * Math.cos(ANGLE);
/* 261 */           double y1 = Y0 - YSTEP * j * Math.sin(ANGLE);
/*     */ 
/* 263 */           double x2 = X0 + XSTEP * i + YSTEP * (j + 1) * Math.cos(ANGLE);
/* 264 */           double y2 = Y0 - YSTEP * (j + 1) * Math.sin(ANGLE);
/*     */ 
/* 266 */           double x3 = X0 + XSTEP * (i + 1) + YSTEP * j * Math.cos(ANGLE);
/* 267 */           double y3 = y1;
/*     */ 
/* 272 */           double x10 = x1;
/* 273 */           double y10 = y1 - SPACE2 - this.detail[i][j] * this.SPACE;
/*     */ 
/* 275 */           double x20 = x2;
/* 276 */           double y20 = y2 - SPACE2 - this.detail[i][(j + 1)] * this.SPACE;
/*     */ 
/* 278 */           double x30 = x3;
/* 279 */           double y30 = y3 - SPACE2 - this.detail[(i + 1)][j] * this.SPACE;
/*     */ 
/* 281 */           g2.draw(new Line2D.Double(x10, y10, x20, y20));
/* 282 */           g2.draw(new Line2D.Double(x10, y10, x30, y30));
/*     */         }
/*     */       }
/*     */ 
/* 286 */       for (int i = 0; i < 19; i++)
/*     */       {
/* 295 */         double x1 = X0 + XSTEP * i + 19.0D * YSTEP * Math.cos(ANGLE);
/* 296 */         double y1 = Y0 - 19.0D * YSTEP * Math.sin(ANGLE);
/*     */ 
/* 298 */         double x2 = X0 + XSTEP * (i + 1) + 380.0D * Math.cos(ANGLE);
/* 299 */         double y2 = y1;
/*     */ 
/* 303 */         x1 = X0 + 19.0D * XSTEP + YSTEP * i * Math.cos(ANGLE);
/* 304 */         y1 = Y0 - YSTEP * i * Math.sin(ANGLE) - this.detail[19][i] * this.SPACE - 
/* 305 */           SPACE2;
/*     */ 
/* 307 */         x2 = X0 + 19.0D * XSTEP + YSTEP * (i + 1) * Math.cos(ANGLE);
/* 308 */         y2 = Y0 - YSTEP * (i + 1) * Math.sin(ANGLE) - this.detail[19][(i + 1)] * 
/* 309 */           this.SPACE - SPACE2;
/*     */ 
/* 311 */         g2.draw(new Line2D.Double(x1, y1, x2, y2));
/*     */ 
/* 313 */         x1 = X0 + XSTEP * i + 19.0D * YSTEP * Math.cos(ANGLE);
/* 314 */         y1 = Y0 - 19.0D * YSTEP * Math.sin(ANGLE) - this.detail[i][19] * this.SPACE - 
/* 315 */           SPACE2;
/*     */ 
/* 317 */         x2 = X0 + XSTEP * (i + 1) + 19.0D * YSTEP * Math.cos(ANGLE);
/* 318 */         y2 = Y0 - 19.0D * YSTEP * Math.sin(ANGLE) - this.detail[(i + 1)][19] * this.SPACE - 
/* 319 */           SPACE2;
/*     */ 
/* 321 */         g2.draw(new Line2D.Double(x1, y1, x2, y2));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void resetDetail(MutObjNew mo, double max)
/*     */   {
/* 331 */     ArrayList muinfo = mo.getMuinf();
/*     */ 
/* 333 */     for (int i = 0; i < muinfo.size(); i++) {
/* 334 */       MutInfo mif = (MutInfo)muinfo.get(i);
/* 335 */       this.detail[mif.getResidue1()][mif.getResidue2()] = mif.getInfo();
/*     */     }
/*     */ 
/* 342 */     this.SPACE = (120.0D / max);
/*     */ 
/* 344 */     this.site1 = (mo.getSite1() + 1);
/* 345 */     this.site2 = (mo.getSite2() + 1);
/* 346 */     this.muinf12 = mo.getMuinf12();
/*     */   }
/*     */ 
/*     */   private float getMax(float[][] array)
/*     */   {
/* 351 */     float max = array[0][0];
/*     */ 
/* 353 */     for (int i = 0; i < array.length; i++) {
/* 354 */       for (int j = 0; j < array[i].length; j++) {
/* 355 */         if (array[i][j] > max) {
/* 356 */           max = array[i][j];
/*     */         }
/*     */       }
/*     */     }
/* 360 */     return max;
/*     */   }
/*     */ 
/*     */   public void resetPc(ProbabilityCalculator pc)
/*     */   {
/* 367 */     this.pc = pc;
/*     */   }
/*     */ 
/*     */   public void resetMutualInformation(MutualInformation mi) {
/* 371 */     this.mi = mi;
/* 372 */     repaint();
/*     */   }
/*     */ 
/*     */   public void drawLine(Graphics g, float width, int x1, int y1, int x2, int y2) {
/* 376 */     Graphics2D gg = (Graphics2D)g;
/* 377 */     float[] dash = { 1.0F };
/* 378 */     BasicStroke bs = new BasicStroke(width, 0, 
/* 379 */       0, 10.0F, dash, 0.0F);
/* 380 */     gg.setStroke(bs);
/* 381 */     Line2D line = new Line2D.Float(x1, y1, x2, y2);
/* 382 */     gg.draw(line);
/*     */   }

			public void create_pic(String outputFile,JPanel panel)
			{
				Dimension imageSize = panel.getSize();
			    BufferedImage image = new BufferedImage(imageSize.width,
			            imageSize.height, BufferedImage.TYPE_INT_ARGB);
			    Graphics2D g = image.createGraphics();
			    panel.paint(g);
			    g.dispose();
			    try {
			        File f = new File(outputFile+".jpg");
			    	ImageIO.write(image, "png", f);
			    } catch (IOException e) {
			        e.printStackTrace();
			       
			    }
			   // System.out.println("export Image -->" + f.getAbsoluteFile());
			   
			}
			
			private void  jMenuItem_save_picActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem_save_execlActionPerformed
			    // TODO add your handling code here:
			    JFileChooser jfilechooser = new JFileChooser();
			    jfilechooser.setDialogType(JFileChooser.SAVE_DIALOG);
			    FileNameExtensionFilter filter = new FileNameExtensionFilter("jpg","jpeg");
			    jfilechooser.setFileFilter(filter);
			    //jfilechooser.set
			    jfilechooser.showSaveDialog(null);
			    if(jfilechooser.getSelectedFile().exists())
			    {
			           int choose= JOptionPane.showConfirmDialog(null, "The file did exist!","OOPS",JOptionPane.OK_CANCEL_OPTION);
			            //this.jTextField_batch_file.setForeground(Color.red);
			           if(choose == JOptionPane.YES_OPTION)
			               create_pic(jfilechooser.getSelectedFile().getPath(),this);
			           else
			            return;
			    }
			    else
			    {
			        //File file = jfilechooser.getSelectedFile();
			        create_pic(jfilechooser.getSelectedFile().getPath(),this);
			    }
			
			
			}



/*     */ }

