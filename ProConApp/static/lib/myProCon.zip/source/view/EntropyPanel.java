/*     */ package source.view;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class EntropyPanel extends JPanel
/*     */ {
/*     */   private ProbabilityCalculator pc;
/*     */   private JPanel titlePanel;
/*     */   private JTextField siteField;
/*     */   private JLabel siteLabel;
/*     */   private EntropyDiagramPanel diagramPanel;
/*     */   private JSlider siteslider;
/*     */   private ChangeListener listener;
/*     */ 
/*     */   public EntropyPanel(ProbabilityCalculator pc)
/*     */   {
/*  21 */     this.pc = pc;
/*  22 */     this.diagramPanel = new EntropyDiagramPanel(pc);
/*  23 */     setLayout(new BorderLayout());
/*  24 */     add(this.diagramPanel, "Center");
/*     */ 
/*  26 */     this.listener = new myChangeListener();
/*     */ 
/*  49 */     this.titlePanel = new JPanel();
/*  50 */     this.titlePanel.add(new JLabel("positions: "));
/*  51 */     int displaylength = 60;
/*  52 */     if (pc.getResNumber() < 60) {
/*  53 */       displaylength = pc.getResNumber();
/*     */     }
/*     */ 
/*  56 */     this.siteLabel = new JLabel(" 1 to " + displaylength);
/*  57 */     this.siteLabel.setForeground(Color.RED);
/*     */ 
/*  60 */     this.titlePanel.add(this.siteLabel);
/*  61 */     this.titlePanel
/*  62 */       .add(new JLabel(
/*  63 */       ". Please drag the slider below to change the position values."));
/*  64 */     add(this.titlePanel, "North");
/*     */ 
/*  66 */     if (pc.getResNumber() != 0)
/*  67 */       this.siteslider = new JSlider(1, pc.getResNumber());
/*     */     else {
/*  69 */       this.siteslider = new JSlider(1, 100, 1);
/*     */     }
/*  71 */     this.siteslider.setBounds(new Rectangle(800, 20));
/*  72 */     this.siteslider.setPaintTicks(true);
/*  73 */     this.siteslider.setPaintLabels(true);
/*  74 */     this.siteslider.setMajorTickSpacing(20);
/*  75 */     this.siteslider.setMinorTickSpacing(5);
/*  76 */     this.siteslider.addChangeListener(this.listener);
/*  77 */     add(this.siteslider, "South");
/*     */   }
/*     */ 
/*     */   public void resetPc(ProbabilityCalculator pc)
/*     */   {
/*  83 */     this.pc = pc;
/*  84 */     if (pc.getResNumber() >= 60)
/*  85 */       this.siteslider.setMaximum(pc.getResNumber() - 59);
/*     */     else {
/*  87 */       this.siteslider.setMaximum(1);
/*     */     }
/*  89 */     this.diagramPanel.resetPc(pc);
/*  90 */     this.diagramPanel.repaint();
/*     */   }
/*     */ 
/*     */   private class myChangeListener
/*     */     implements ChangeListener
/*     */   {
/*     */     private myChangeListener()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void stateChanged(ChangeEvent event)
/*     */     {
/* 103 */       JSlider source = (JSlider)event.getSource();
/*     */ 
/* 105 */       if (EntropyPanel.this.pc.getResNumber() >= 60)
/* 106 */         EntropyPanel.this.siteLabel.setText(" " + String.valueOf(source.getValue()) + 
/* 107 */           " to " + String.valueOf(source.getValue() + 59));
/*     */       else
/* 109 */         EntropyPanel.this.siteLabel.setText(String.valueOf(new StringBuilder(" ").append(source.getValue()).toString()) + 
/* 110 */           " to " + 
/* 111 */           String.valueOf(source.getValue() + EntropyPanel.this.pc.getResNumber() - 
/* 112 */           1));
/* 113 */       EntropyPanel.this.diagramPanel.setSite(source.getValue() - 1);
/* 114 */       EntropyPanel.this.diagramPanel.repaint();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\妗��\SOD1 ���\ProCon-20121023.jar
 * Qualified Name:     source.view.EntropyPanel
 * JD-Core Version:    0.6.2
 */