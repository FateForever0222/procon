/*     */ package source.view;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSeparator;
/*     */ import source.model.MutualInformation;
/*     */ import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class StructurePanel extends JPanel
/*     */ {
/*     */   private JLabel groupLabel;
/*     */   private StructureDisplayPanel displaypanel;
/*     */   private ProbabilityCalculator pc;
/*     */   private JPanel optionpanel;
/*     */   private TpListPanel tripletlistpanel;
/*     */   private MuListPanel mutuallistpanelP1;
/*     */   private MuListPanel mutuallistpanelP2;
/*     */   private MutualInformation mi;
/*     */ 
/*     */   public StructurePanel(ProbabilityCalculator pc)
/*     */   {
/*  49 */     this.pc = pc;
/*  50 */     this.displaypanel = new StructureDisplayPanel(this.pc);
/*     */ 
/*  52 */     this.groupLabel = new JLabel(" covariant aas and triplets for 20 alphabet");
/*     */ 
/*  54 */     this.tripletlistpanel = new TpListPanel(this.pc, this.displaypanel);
/*  55 */     this.mutuallistpanelP1 = new MuListPanel(this.pc, this.displaypanel, 1);
/*  56 */     this.mutuallistpanelP2 = new MuListPanel(this.pc, this.displaypanel, 2);
/*     */ 
/*  58 */     JPanel westpanel = new JPanel();
/*  59 */     westpanel.setLayout(new BorderLayout());
/*     */ 
/*  61 */     westpanel.add(this.groupLabel, "North");
/*     */ 
/*  63 */     JPanel listpanel = new JPanel();
/*     */ 
/*  65 */     listpanel.setLayout(new GridLayout(3, 1, 3, 3));
/*     */ 
/*  67 */     listpanel.add(this.mutuallistpanelP1);
/*  68 */     listpanel.add(this.mutuallistpanelP2);
/*  69 */     listpanel.add(this.tripletlistpanel);
/*     */ 
/*  71 */     westpanel.add(listpanel, "Center");
/*  72 */     JSeparator s = new JSeparator(0);
/*  73 */     Dimension ps = s.getPreferredSize();
/*  74 */     s.setPreferredSize(new Dimension(ps.width, 20));
/*     */ 
/*  77 */     JSeparator s2 = new JSeparator(1);
/*  78 */     Dimension ps2 = s2.getPreferredSize();
/*  79 */     s2.setPreferredSize(new Dimension(10, ps2.height));
/*  80 */     westpanel.add(s2, "West");
/*     */ 
/*  82 */     setLayout(new BorderLayout());
/*     */ 
/*  84 */     add(westpanel, "West");
/*     */ 
/*  86 */     add(this.displaypanel, "Center");
/*     */   }
/*     */ 
/*     */   public void initialPc(ProbabilityCalculator pc)
/*     */   {
/*  91 */     this.pc = pc;
/*  92 */     this.tripletlistpanel.initialPc(pc);
/*  93 */     this.mutuallistpanelP1.initialPc(pc);
/*  94 */     this.mutuallistpanelP2.initialPc(pc);
/*     */   }
/*     */ 
/*     */   public void setMutualInformation(MutualInformation mi) {
/*  98 */     this.mi = mi;
/*     */ 
/* 100 */     if ((this.mi != null) && (!this.mi.getGroupFlag()))
/* 101 */       this.groupLabel.setText(" covariant aas and triplets for " + Integer.toString(this.pc.getNumberofgroup()) + " alphabet,");
/*     */     else {
/* 103 */       this.groupLabel.setText(" covariant aas and triplets for 20 alphabet");
/*     */     }
/* 105 */     this.tripletlistpanel.setMutualInformation(mi);
/* 106 */     this.mutuallistpanelP1.setMutualInformation(mi);
/* 107 */     this.mutuallistpanelP2.setMutualInformation(mi);
/*     */   }
/*     */ 
/*     */   public void resetPc(ProbabilityCalculator pc)
/*     */   {
/* 112 */     this.pc = pc;
/*     */ 
/* 115 */     this.displaypanel.resetPc(this.pc);
/* 116 */     this.tripletlistpanel.resetPc(this.pc);
/* 117 */     this.mutuallistpanelP1.resetPc(this.pc);
/* 118 */     this.mutuallistpanelP2.resetPc(this.pc);
/*     */   }
/*     */ 
/*     */   public void resetTriplets()
/*     */   {
/* 123 */     this.tripletlistpanel.displayList();
/* 124 */     this.mutuallistpanelP1.displayMuList();
/* 125 */     this.mutuallistpanelP2.displayMuList();
/*     */   }
/*     */ 
/*     */   static class ApplicationCloser extends WindowAdapter
/*     */   {
/*     */     public void windowClosing(WindowEvent e)
/*     */     {
/* 132 */       System.exit(0);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.StructurePanel
 * JD-Core Version:    0.6.2
 */