/*     */ package source.view;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Component;
/*     */ import java.awt.Frame;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRootPane;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.SwingUtilities;
/*     */ import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class GroupChooser extends JPanel
/*     */ {
/*     */   private boolean ok;
/*     */   private ProbabilityCalculator pc;
/*     */   private JButton okButton;
/*     */   private JButton defaultButton;
/*     */   private JButton polarityButton;
/*     */   private JButton essentialityButton;
/*     */   private JButton sidechainButton;
/*     */   private JButton cancelButton;
/*     */   private JDialog dialog;
/*     */   private GroupNameChooser namedialog;
/*     */   private String[] groupnames;
/*     */   private JTextField groupfield;
/*     */   private int groupnumber;
/*     */   private JComboBox[] groupsText;
/*     */   private int[] defaultgroup;
/*     */   private int[] group;
/*     */   private boolean ifdefault;
/* 377 */   public static String[] physicochemical = { "hydrophobic", "AT", "negative", 
/* 378 */     "conformational", "polar", "positive", "gap" };
/*     */ 
/* 379 */   public static String[] polarity = { "non polar", "uncharged polar", "acidic", "basic", "gap" };
/*     */ 
/* 381 */   public static String[] essentiality = { "essential", "non-essential", "conditionally essential", "gap" };
/* 382 */   public static String[] sidechain = { "aliphatic", "aromatic", "acidic", "basic", "hydroxylic", "sulfur-containing", "amidic" };
/*     */ 
/* 384 */   public static int[] polaritygroup = { 0, 1, 2, 2, 0, 0, 3, 0, 3, 0, 0, 1, 0, 1, 3, 1, 1, 0, 0, 1, 4 };
/*     */ 
/* 386 */   public static int[] essentialitygroup = { 1, 2, 1, 1, 0, 2, 0, 0, 0, 0, 0, 1, 2, 2, 2, 1, 0, 0, 0, 2, 3 };
/*     */ 
/* 388 */   public static int[] sidechaingroup = { 0, 5, 2, 2, 1, 0, 3, 0, 3, 0, 5, 6, 0, 6, 3, 4, 4, 0, 1, 1, 7 };
/*     */ 
/*     */   public GroupChooser(ProbabilityCalculator pc)
/*     */   {
/*  26 */     this.defaultgroup = new int[] { 1, 0, 2, 2, 0, 3, 5, 0, 5, 0, 0, 4, 3, 4, 5, 4, 1, 0, 0, 0, 6 };
/*     */ 
/*  28 */     this.group = new int[21];
/*  29 */     setSize(400, 300);
/*  30 */     this.pc = pc;
/*  31 */     this.ifdefault = pc.getDefault();
/*  32 */     this.groupnames = pc.getGroupNames();
/*  33 */     setLayout(new BorderLayout());
/*     */ 
/*  35 */     JPanel titlepanel = new JPanel();
/*  36 */     titlepanel.setLayout(new GridLayout(4, 1));
/*     */ 
/*  38 */     titlepanel.add(new JLabel("current amino acid groups are as follows, you can set the groups according to following properties:"));
/*     */ 
/*  40 */     JPanel grouppanel = new JPanel();
/*     */ 
/*  42 */     grouppanel.add(new JLabel("or set the groups yourself: set total number of groups:"));
/*     */ 
/*  44 */     this.groupfield = new JTextField(Integer.toString(pc.getNumberofgroup()), 2);
/*     */ 
/*  48 */     grouppanel.add(this.groupfield);
/*  49 */     JButton groupbutton = new JButton("OK");
/*  50 */     this.groupsText = new JComboBox[20];
/*  51 */     groupbutton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/*  55 */         GroupChooser.this.ifdefault = false;
/*  56 */         GroupChooser.this.groupnumber = Integer.parseInt(GroupChooser.this.groupfield.getText());
/*     */ 
/*  59 */         GroupChooser.this.namedialog = new GroupNameChooser(GroupChooser.this.groupnumber);
/*     */ 
/*  61 */         if (GroupChooser.this.namedialog.showDialog(GroupChooser.this, "set group names")) {
/*  62 */           GroupChooser.this.groupnames = GroupChooser.this.namedialog.getGroupNames();
/*     */         }
/*     */ 
/*  74 */         for (int i = 0; i < 20; i++)
/*     */         {
/*  76 */           GroupChooser.this.groupsText[i].removeAllItems();
/*     */ 
/*  78 */           for (int j = 0; j < GroupChooser.this.groupnumber; j++)
/*  79 */             GroupChooser.this.groupsText[i].addItem(GroupChooser.this.groupnames[j]);
/*     */         }
/*     */       }
/*     */     });
/*  89 */     grouppanel.add(groupbutton);
/*     */ 
/*  97 */     JPanel panel = new JPanel();
/*  98 */     panel.setLayout(new GridLayout(11, 4));
/*  99 */     JLabel[] label = new JLabel[20];
/*     */ 
/* 102 */     int[] group = pc.getGroup();
/* 103 */     this.groupnumber = pc.getNumberofgroup();
/*     */ 
/* 105 */     for (int i = 0; i < 20; i++) {
/* 106 */       label[i] = new JLabel("  " + Character.toString(ProbabilityCalculator.RESIDUE[i]) + " ( " + ProbabilityCalculator.FULL_RESIDUE[i] + " ) : ");
/*     */ 
/* 108 */       this.groupsText[i] = new JComboBox();
/* 109 */       for (int j = 0; j < this.groupnumber; j++) {
/* 110 */         this.groupsText[i].addItem(this.groupnames[j]);
/*     */       }
/*     */ 
/* 113 */       this.groupsText[i].setSelectedIndex(group[i]);
/*     */ 
/* 115 */       panel.add(label[i]);
/* 116 */       panel.add(this.groupsText[i]);
/*     */     }
/*     */ 
/* 119 */     add(panel, "Center");
/*     */ 
/* 125 */     this.okButton = new JButton("Apply");
/* 126 */     this.okButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0) {
/* 129 */         GroupChooser.this.ok = true;
/*     */ 
/* 132 */         String text = GroupChooser.this.getGroups();
/*     */ 
/* 135 */         int choice = JOptionPane.showConfirmDialog(null, 
/* 136 */           text, "confirm your groups setting", 0);
/* 137 */         if (choice == 0)
/*     */         {
/* 139 */           GroupChooser.this.recalculatePc();
/*     */ 
/* 141 */           GroupChooser.this.dialog.setVisible(false);
/*     */         }
/* 144 */         else if (choice == 1)
/*     */         {
/* 147 */           GroupChooser.this.dialog.setVisible(true);
/*     */         }
/*     */       }
/*     */     });
/* 159 */     this.defaultButton = new JButton("physicochemical (default)");
/* 160 */     this.defaultButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 164 */         GroupChooser.this.setDefaultGroup(1);
/*     */       }
/*     */     });
/* 170 */     this.polarityButton = new JButton("polarity");
/* 171 */     this.polarityButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 178 */         GroupChooser.this.setDefaultGroup(2);
/*     */       }
/*     */     });
/* 183 */     this.essentialityButton = new JButton("essentiality");
/* 184 */     this.essentialityButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 191 */         GroupChooser.this.setDefaultGroup(3);
/*     */       }
/*     */     });
/* 197 */     this.sidechainButton = new JButton("side chain properties");
/* 198 */     this.sidechainButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/* 205 */         GroupChooser.this.setDefaultGroup(4);
/*     */       }
/*     */     });
/* 211 */     this.cancelButton = new JButton("Cancel");
/* 212 */     this.cancelButton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent arg0) {
/* 215 */         GroupChooser.this.dialog.setVisible(false);
/*     */       }
/*     */     });
/* 223 */     JPanel groupPanel = new JPanel();
/*     */ 
/* 226 */     groupPanel.add(this.defaultButton);
/* 227 */     groupPanel.add(this.polarityButton);
/* 228 */     groupPanel.add(this.essentialityButton);
/* 229 */     groupPanel.add(this.sidechainButton);
/*     */ 
/* 231 */     titlepanel.add(groupPanel);
/*     */ 
/* 233 */     titlepanel.add(grouppanel);
/* 234 */     titlepanel.add(new JLabel("please set groups for each amino acid:"));
/* 235 */     add(titlepanel, "North");
/*     */ 
/* 237 */     JPanel buttonPanel = new JPanel();
/* 238 */     buttonPanel.add(this.okButton);
/*     */ 
/* 240 */     buttonPanel.add(this.cancelButton);
/*     */ 
/* 245 */     add(buttonPanel, "South");
/*     */   }
/*     */ 
/*     */   public void setDefaultGroup(int choice)
/*     */   {
/* 250 */     if (choice == 1) {
/* 251 */       this.ifdefault = true;
/* 252 */       this.groupnumber = 6;
/* 253 */       this.group = this.defaultgroup;
/*     */ 
/* 255 */       this.groupfield.setText("6");
/* 256 */       this.groupfield.repaint();
/*     */ 
/* 258 */       this.groupnames = physicochemical;
/*     */     }
/* 261 */     else if (choice == 2) {
/* 262 */       this.ifdefault = false;
/* 263 */       this.groupnumber = 4;
/* 264 */       this.group = polaritygroup;
/* 265 */       this.groupfield.setText("4");
/* 266 */       this.groupfield.repaint();
/*     */ 
/* 268 */       this.groupnames = polarity;
/*     */     }
/* 271 */     else if (choice == 3) {
/* 272 */       this.ifdefault = false;
/* 273 */       this.groupnumber = 3;
/* 274 */       this.group = essentialitygroup;
/* 275 */       this.groupfield.setText("3");
/* 276 */       this.groupfield.repaint();
/*     */ 
/* 278 */       this.groupnames = essentiality;
/*     */     }
/* 280 */     else if (choice == 4) {
/* 281 */       this.ifdefault = false;
/* 282 */       this.groupnumber = 7;
/* 283 */       this.group = sidechaingroup;
/* 284 */       this.groupfield.setText("7");
/* 285 */       this.groupfield.repaint();
/*     */ 
/* 287 */       this.groupnames = sidechain;
/*     */     }
/*     */ 
/* 290 */     for (int i = 0; i < 20; i++) {
/* 291 */       this.groupsText[i].removeAllItems();
/* 292 */       for (int j = 0; j < this.groupnumber; j++) {
/* 293 */         this.groupsText[i].addItem(this.groupnames[j]);
/*     */       }
/*     */ 
/* 296 */       this.groupsText[i].setSelectedIndex(this.group[i]);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getGroups()
/*     */   {
/* 302 */     String text = "your aa groups setting is as follows: \n";
/*     */ 
/* 304 */     for (int i = 0; i < 20; i++) {
/* 305 */       this.group[i] = this.groupsText[i].getSelectedIndex();
/*     */     }
/* 307 */     this.group[20] = this.groupnumber;
/*     */ 
/* 309 */     String[] usersetgroup = new String[this.groupnumber];
/* 310 */     for (int i = 0; i < this.groupnumber; i++) {
/* 311 */       usersetgroup[i] = (this.groupnames[i] + " : ");
/* 312 */       for (int j = 0; j < 20; j++) {
/* 313 */         if (this.group[j] == i)
/*     */         {
/*     */           int tmp104_103 = i;
/*     */           String[] tmp104_102 = usersetgroup; tmp104_102[tmp104_103] = (tmp104_102[tmp104_103] + ProbabilityCalculator.RESIDUE[j] + " ");
/*     */         }
/*     */       }
/* 316 */       text = text + usersetgroup[i] + " ;\n";
/*     */     }
/*     */ 
/* 319 */     text = text + "\nplease confirm your groups setting.\n";
/* 320 */     return text;
/*     */   }
/*     */ 
/*     */   public void recalculatePc()
/*     */   {
/* 325 */     this.pc.setDefault(this.ifdefault);
/* 326 */     this.pc.setNumberofgroup(this.groupnumber);
/*     */ 
/* 331 */     this.pc.setGroup(this.group);
/* 332 */     this.pc.setGroupNames(this.groupnames);
/*     */   }
/*     */ 
/*     */   public boolean showDialog(Component parent, String title)
/*     */   {
/* 339 */     this.ok = false;
/*     */ 
/* 341 */     Frame owner = null;
/*     */ 
/* 343 */     if ((parent instanceof Frame)) {
/* 344 */       owner = (Frame)parent;
/*     */     }
/*     */     else {
/* 347 */       owner = (Frame)SwingUtilities.getAncestorOfClass(Frame.class, 
/* 348 */         parent);
/*     */     }
/*     */ 
/* 351 */     this.dialog = new JDialog(owner, true);
/* 352 */     this.dialog.add(this);
/* 353 */     this.dialog.getRootPane().setDefaultButton(this.okButton);
/* 354 */     this.dialog.pack();
/*     */ 
/* 357 */     this.dialog.setLocation(250, 200);
/* 358 */     this.dialog.setTitle(title);
/* 359 */     this.dialog.setVisible(true);
/*     */ 
/* 361 */     return this.ok;
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.GroupChooser
 * JD-Core Version:    0.6.2
 */