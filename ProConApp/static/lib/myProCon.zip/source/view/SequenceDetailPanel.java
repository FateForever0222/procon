/*    */ package source.view;
/*    */ 
/*    */ import java.awt.Font;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Graphics2D;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ public class SequenceDetailPanel extends JPanel
/*    */ {
/*    */   private String sequenceString;
/*    */   private int sequenceNumber;
/*    */   private int linegap;
/* 73 */   private static int LINECOLUMN = 50;
/*    */ 
/*    */   public SequenceDetailPanel()
/*    */   {
/* 14 */     this.linegap = 40;
/*    */   }
/*    */ 
/*    */   public void paintComponent(Graphics g) {
/* 18 */     super.paintComponents(g);
/* 19 */     Graphics2D g2 = (Graphics2D)g;
/*    */ 
/* 23 */     g2.setFont(new Font("Dialog", 1, 14));
/* 24 */     g2.drawString("sequence " + Integer.toString(this.sequenceNumber + 1) + 
/* 25 */       " detail:", 50, 50);
/* 26 */     if (this.sequenceString != null) {
/* 27 */       for (int i = 0; i < this.sequenceString.length() / LINECOLUMN; i++) {
/* 28 */         g2.setFont(new Font("Dialog", 1, 12));
/* 29 */         g2.drawString("position " + Integer.toString(i * LINECOLUMN + 1) + 
/* 30 */           " - " + Integer.toString(i * LINECOLUMN + LINECOLUMN) + 
/* 31 */           ": ", 50, 100 + this.linegap * i);
/* 32 */         g2.setFont(new Font("Dialog", 0, 12));
/* 33 */         for (int j = 0; j < LINECOLUMN; j++) {
/* 34 */           g2
/* 35 */             .drawString(this.sequenceString.substring(i * LINECOLUMN + 
/* 36 */             j, i * LINECOLUMN + j + 1), 200 + 10 * j, 
/* 37 */             100 + i * this.linegap);
/*    */         }
/*    */       }
/*    */ 
/* 41 */       g2.setFont(new Font("Dialog", 1, 12));
/* 42 */       g2.drawString("position " + 
/* 43 */         Integer.toString(this.sequenceString.length() / LINECOLUMN * 
/* 44 */         LINECOLUMN + 1) + " - " + 
/* 45 */         Integer.toString(this.sequenceString.length()) + ": ", 50, 
/* 46 */         100 + this.linegap * (this.sequenceString.length() / LINECOLUMN) + 1);
/*    */ 
/* 48 */       g2.setFont(new Font("Dialog", 0, 12));
/* 49 */       for (int j = 0; j < this.sequenceString.length() % LINECOLUMN; j++)
/* 50 */         g2.drawString(this.sequenceString
/* 51 */           .substring(this.sequenceString.length() / LINECOLUMN * 
/* 52 */           LINECOLUMN + j, 
/* 53 */           this.sequenceString.length() / LINECOLUMN * 
/* 54 */           LINECOLUMN + j + 1), 200 + 10 * j, 
/* 55 */           100 + this.sequenceString.length() / LINECOLUMN * this.linegap);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void resetString(String sequenceString, int sequenceNumber) {
/* 60 */     this.sequenceString = sequenceString;
/* 61 */     this.sequenceNumber = sequenceNumber;
/* 62 */     this.linegap = (420 / (sequenceString.length() / LINECOLUMN));
/*    */ 
/* 64 */     repaint();
/*    */   }
/*    */ 
/*    */   public int getReference() {
/* 68 */     return this.sequenceNumber;
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.SequenceDetailPanel
 * JD-Core Version:    0.6.2
 */