/*     */ package source.view;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.table.TableModel;
/*     */ import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class SequenceListPanel extends JPanel
/*     */ {
/*     */   private SequenceDetailPanel detailPanel;
/*     */   private ProbabilityCalculator pc;
/*     */   private JTable table;
/*     */   private JScrollPane pane;
/*     */ 
/*     */   public SequenceListPanel(SequenceDetailPanel detailPanel)
/*     */   {
/*  24 */     this.detailPanel = detailPanel;
/*     */ 
/*  28 */     Object[][] rows = new Object[40][2];
/*  29 */     String[] columns = { "no.", "sequence name" };
/*  30 */     TableModel model = new DefaultTableModel(rows, columns);
/*  31 */     this.table = new JTable(model);
/*     */ 
/*  33 */     this.table.setPreferredScrollableViewportSize(new Dimension(300, 550));
/*     */ 
/*  35 */     Font f = new Font("Dialog", 0, 11);
/*  36 */     this.table.setFont(f);
/*     */ 
/*  38 */     this.table.getTableHeader().setFont(f);
/*     */ 
/*  40 */     TableColumn column1 = this.table.getColumnModel().getColumn(1);
/*  41 */     column1.setPreferredWidth(400);
/*     */ 
/*  43 */     this.pane = new JScrollPane(this.table);
/*     */ 
/*  46 */     this.pane = new JScrollPane(this.table);
/*     */ 
/*  48 */     add(this.pane, "Center");
/*     */   }
/*     */ 
/*     */   public void resetList(ProbabilityCalculator pc)
/*     */   {
/*  53 */     this.pc = pc;
/*     */ 
/*  55 */     int sequencenumber = pc.getSeqNumber();
/*  56 */     ArrayList listname = pc.getSeqNames();
/*     */ 
/*  58 */     String[][] rows2 = new String[sequencenumber][2];
/*     */ 
/*  60 */     for (int i = 0; i < sequencenumber; i++) {
/*  61 */       rows2[i][0] = Integer.toString(i + 1);
/*  62 */       rows2[i][1] = ((String)listname.get(i));
/*     */     }
/*     */ 
/*  65 */     String[] columns = { "no.", "sequence name" };
/*  66 */     TableModel model2 = new DefaultTableModel(rows2, columns) {
/*     */       public boolean isCellEditable(int row, int column) {
/*  68 */         return false;
/*     */       }
/*     */     };
/*  71 */     this.table.setModel(model2);
/*     */ 
/*  73 */     this.table.getTableHeader().setFont(new Font("Dialog", 0, 11));
/*     */ 
/*  75 */     TableColumn column1 = this.table.getColumnModel().getColumn(1);
/*  76 */     column1.setPreferredWidth(400);
/*     */ 
/*  78 */     this.table.addMouseListener(new MouseAdapter() {
/*     */       public void mouseClicked(MouseEvent e) {
/*  80 */         SequenceListPanel.this.tableClickActionPerformed(SequenceListPanel.this.table);
/*     */       }
/*     */     });
/*  88 */     this.table.repaint();
/*  89 */     this.table.updateUI();
/*     */   }
/*     */ 
/*     */   public void tableClickActionPerformed(JTable table)
/*     */   {
/*  95 */     int numRow = table.getSelectedRow();
/*  96 */     System.out.println("numRow = " + numRow);
/*  97 */     char[][] sequence = this.pc.getSeq();
/*  98 */     char[] sequenceline = sequence[numRow];
/*     */ 
/* 100 */     String sequenceString = new String(sequenceline);
/*     */ 
/* 102 */     this.detailPanel.resetString(sequenceString, numRow);
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.SequenceListPanel
 * JD-Core Version:    0.6.2
 */