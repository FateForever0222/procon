/*     */ package source.view;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.awt.geom.Ellipse2D;
/*     */ import java.awt.geom.Ellipse2D.Double;
/*     */ import java.awt.geom.Point2D;
import java.awt.geom.QuadCurve2D;
/*     */ //import java.awt.geom.QuadCurve2D.Double;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.JPanel;
/*     */ import source.model.MutObjNew;
/*     */ import source.model.MutualInformation;
/*     */ import source.model.MyLink;
/*     */ import source.model.MyNode;
/*     */ import source.model.ProbabilityCalculator;
import source.model.Triplet;
/*     */ 
/*     */ public class TripletDiagramPanel extends JPanel
/*     */ {
/*     */   private TripletListPanel listpanel;
/*     */   private ArrayList<MyLink> linklist;
/*     */   private ArrayList<MyLink> mulinklist;
/*     */   private ArrayList<MyNode> nodelist;
/*     */   private ArrayList<MyNode> munodelist;
/*     */   private double random1;
/*     */   private double random2;
/*     */   private MyNode current;
/*     */ 
/*     */   public TripletDiagramPanel(TripletListPanel listpanel)
/*     */   {
/*  29 */     this.listpanel = listpanel;
/*  30 */     this.nodelist = new ArrayList();
/*  31 */     this.linklist = new ArrayList();
/*  32 */     this.munodelist = new ArrayList();
/*  33 */     this.mulinklist = new ArrayList();
/*  34 */     this.random1 = Math.random();
/*  35 */     this.random2 = Math.random();
/*     */ 
/*  37 */     this.current = null;
/*  38 */     addMouseListener(new MouseHandler());
/*  39 */     addMouseMotionListener(new MouseMotionHandler());
/*     */   }
/*     */ 
/*     */   public void paintComponent(Graphics g)
/*     */   {
/*  44 */     super.paintComponents(g);
/*  45 */     Graphics2D g2 = (Graphics2D)g;
/*     */ 
/*  48 */     ProbabilityCalculator pc = this.listpanel.getPc();
/*  49 */     String head1 = "current reference sequence is: " + 
/*  50 */       Integer.toString(pc.getReference() + 1);
/*  51 */     g2.setFont(new Font("Dialog", 1, 14));
/*  52 */     g2.drawString(head1, 40, 20);
/*     */ 
/*  54 */     if (this.linklist.size() != 0)
/*     */     {
/*  56 */       String head2 = "triplets found among the covariant pairs: (You may drag the sites to make it clear)";
/*  57 */       g2.setFont(new Font("Dialog", 0, 13));
/*  58 */       g2.drawString(head2, 40, 40);
/*  59 */       for (int i = 0; i < this.linklist.size(); i++) {
/*  60 */         MyLink link = (MyLink)this.linklist.get(i);
/*     */ 
/*  63 */         double x1 = link.getNode1().getX();
/*  64 */         double y1 = link.getNode1().getY();
/*  65 */         double x2 = link.getNode2().getX();
/*  66 */         double y2 = link.getNode2().getY();
/*     */ 
/*  68 */         Ellipse2D e1 = new Ellipse2D.Double(x1 - 2.5D, y1 - 2.5D, 5.0D, 5.0D);
/*  69 */         Ellipse2D e2 = new Ellipse2D.Double(x2 - 2.5D, y2 - 2.5D, 5.0D, 5.0D);
/*     */ 
/*  71 */         g2.setPaint(Color.BLACK);
/*  72 */         g2.fill(e1);
/*  73 */         g2.fill(e2);
/*     */ 
/*  75 */         g2.setPaint(Color.RED);
/*     */ 
/*  80 */         double xt = (x1 + x2) * 0.5D + 100.0D * this.random1 - 50.0D;
/*     */ 
/*  82 */         double yt = (y1 + y2) * 0.5D + 60.0D * this.random2 - 30.0D;
/*     */ 
/*  84 */         g2.draw(new QuadCurve2D.Double(x1, y1, xt, yt, x2, y2));
/*     */ 
/*  86 */         g2.setFont(new Font("Dialog", 1, 12));
/*  87 */         g2.setPaint(Color.BLACK);
/*  88 */         g2.drawString(pc.calculateSite(link.getNode1().getSite()), link
/*  89 */           .getNode1().getX() + 10, link.getNode1().getY() + 10);
/*  90 */         g2.drawString(pc.calculateSite(link.getNode2().getSite()), link
/*  91 */           .getNode2().getX() + 10, link.getNode2().getY() + 10);
/*     */       }
/*     */     }
/*     */ 
/*  95 */     if (this.mulinklist.size() != 0)
/*     */     {
/*  97 */       String head3 = "Covariant pairs with p values less than 0.01 : (You may drag the sites to make it clear)";
/*  98 */       g2.setFont(new Font("Dialog", 0, 13));
/*  99 */       g2.drawString(head3, 40, 300);
/*     */ 
/* 101 */       for (int i = 0; i < this.mulinklist.size(); i++) {
/* 102 */         MyLink link = (MyLink)this.mulinklist.get(i);
/*     */ 
/* 105 */         double x1 = link.getNode1().getX();
/* 106 */         double y1 = link.getNode1().getY();
/* 107 */         double x2 = link.getNode2().getX();
/* 108 */         double y2 = link.getNode2().getY();
/*     */ 
/* 110 */         Ellipse2D e1 = new Ellipse2D.Double(x1 - 2.5D, y1 - 2.5D, 5.0D, 5.0D);
/* 111 */         Ellipse2D e2 = new Ellipse2D.Double(x2 - 2.5D, y2 - 2.5D, 5.0D, 5.0D);
/*     */ 
/* 113 */         g2.setPaint(Color.BLACK);
/* 114 */         g2.fill(e1);
/* 115 */         g2.fill(e2);
/*     */ 
/* 117 */         g2.setPaint(Color.BLUE);
/*     */ 
/* 122 */         double xt = (x1 + x2) * 0.5D + this.random1 * 50.0D;
/*     */ 
/* 124 */         double yt = (y1 + y2) * 0.5D + this.random2 * 30.0D;
/*     */ 
/* 126 */         g2.draw(new QuadCurve2D.Double(x1, y1, xt, yt, x2, y2));
/*     */ 
/* 128 */         g2.setFont(new Font("Dialog", 1, 12));
/* 129 */         g2.setPaint(Color.BLACK);
/* 130 */         g2.drawString(pc.calculateSite(link.getNode1().getSite()), link
/* 131 */           .getNode1().getX() + 10, link.getNode1().getY() + 10);
/* 132 */         g2.drawString(pc.calculateSite(link.getNode2().getSite()), link
/* 133 */           .getNode2().getX() + 10, link.getNode2().getY() + 10);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void calculateSites()
/*     */   {
/* 140 */     ArrayList displaylist = this.listpanel.getDisplayList();
/*     */ 
/* 142 */     boolean flag1 = false;
/* 143 */     boolean flag2 = false;
/* 144 */     boolean flag3 = false;
/*     */ 
/* 146 */     for (int i = 0; i < displaylist.size(); i++) {
/* 147 */       Triplet tp = (Triplet)displaylist.get(i);
/*     */ 
/* 149 */       flag1 = false;
/* 150 */       flag2 = false;
/* 151 */       flag3 = false;
/*     */ 
/* 153 */       MyNode node1 = new MyNode(tp.getS1(), 
/* 154 */         (int)(600.0D * 
/* 154 */         Math.random() + 50.0D), (int)(300.0D * Math.random() + 50.0D));
/* 155 */       MyNode node2 = new MyNode(tp.getS2(), 
/* 156 */         (int)(600.0D * 
/* 156 */         Math.random() + 50.0D), (int)(300.0D * Math.random() + 50.0D));
/* 157 */       MyNode node3 = new MyNode(tp.getS3(), 
/* 158 */         (int)(600.0D * 
/* 158 */         Math.random() + 50.0D), (int)(300.0D * Math.random() + 50.0D));
/*     */ 
/* 160 */       if (this.nodelist.size() != 0) {
/* 161 */         for (int j = 0; j < this.nodelist.size(); j++)
/*     */         {
/* 163 */           MyNode node = (MyNode)this.nodelist.get(j);
/* 164 */           if (node.getSite() == tp.getS1()) {
/* 165 */             flag1 = true;
/* 166 */             node1 = node;
/* 167 */           } else if (node.getSite() == tp.getS2()) {
/* 168 */             flag2 = true;
/* 169 */             node2 = node;
/* 170 */           } else if (node.getSite() == tp.getS3()) {
/* 171 */             flag3 = true;
/* 172 */             node3 = node;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 177 */       if (!flag1)
/*     */       {
/* 179 */         this.nodelist.add(node1);
/*     */       }
/* 181 */       if (!flag2)
/*     */       {
/* 183 */         this.nodelist.add(node2);
/*     */       }
/* 185 */       if (!flag3)
/*     */       {
/* 187 */         this.nodelist.add(node3);
/*     */       }
/*     */ 
/* 190 */       MyLink link1 = new MyLink(node1, node2);
/* 191 */       MyLink link2 = new MyLink(node1, node3);
/* 192 */       MyLink link3 = new MyLink(node2, node3);
/*     */ 
/* 194 */       this.linklist.add(link1);
/* 195 */       this.linklist.add(link2);
/* 196 */       this.linklist.add(link3);
/*     */     }
/*     */ 
/* 199 */     System.out.println("nodelist.size = " + this.nodelist.size());
/* 200 */     System.out.println("linklist.size = " + this.linklist.size());
/*     */ 
/* 204 */     int columns = this.nodelist.size() / 3 + 1;
/* 205 */     int width = 600 / columns;
/*     */ 
/* 207 */     for (int i = 0; i < this.nodelist.size(); i++) {
/* 208 */       MyNode nodei = (MyNode)this.nodelist.get(i);
/* 209 */       if (i % 2 == 0)
/* 210 */         nodei.setPosition(
/* 211 */           (int)(width / 3 * Math.random() + i / 3 * 
/* 211 */           width + 150.0D), 
/* 212 */           (int)(50.0D * Math.random() + i % 3 * 70) + 50);
/*     */       else
/* 214 */         nodei.setPosition(
/* 215 */           (int)(-width / 3 * Math.random() + i / 3 * 
/* 215 */           width + 150.0D), 
/* 216 */           (int)(50.0D * Math.random() + i % 3 * 70) + 50);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void calculatemusites()
/*     */   {
/* 232 */     MutualInformation mi = this.listpanel.getMutualInformation();
/* 233 */     this.munodelist = new ArrayList();
/* 234 */     this.mulinklist = new ArrayList();
/*     */ 
/* 236 */     boolean flag1 = false;
/* 237 */     boolean flag2 = false;
/*     */ 
/* 239 */     if (mi != null) {
/* 240 */       MutObjNew[] mutlist = mi.getMutObj();
/* 241 */       for (int i = 0; i < 32; i++) {
/* 242 */         MyNode node1 = new MyNode();
/* 243 */         MyNode node2 = new MyNode();
/*     */ 
/* 245 */         flag1 = false;
/* 246 */         flag2 = false;
/*     */ 
/* 248 */         for (int j = 0; j < this.munodelist.size(); j++) {
/* 249 */           MyNode nodej = (MyNode)this.munodelist.get(j);
/* 250 */           if (nodej.getSite() == mutlist[i].getSite1()) {
/* 251 */             node1 = nodej;
/* 252 */             flag1 = true;
/*     */           }
/*     */ 
/* 255 */           if (nodej.getSite() == mutlist[i].getSite2()) {
/* 256 */             node2 = nodej;
/* 257 */             flag2 = true;
/*     */           }
/*     */         }
/*     */ 
/* 261 */         if (!flag1) {
/* 262 */           node1 = new MyNode(mutlist[i].getSite1());
/* 263 */           this.munodelist.add(node1);
/*     */         }
/*     */ 
/* 266 */         if (!flag2) {
/* 267 */           node2 = new MyNode(mutlist[i].getSite2());
/* 268 */           this.munodelist.add(node2);
/*     */         }
/*     */ 
/* 271 */         MyLink link = new MyLink(node1, node2, mutlist[i].getMuinf12());
/* 272 */         this.mulinklist.add(link);
/*     */       }
/*     */ 
/* 275 */       System.out.println("munodelist.size = " + this.munodelist.size());
/*     */ 
/* 277 */       int columns = this.munodelist.size() / 3 + 1;
/* 278 */       int width = 600 / columns;
/*     */ 
/* 280 */       for (int i = 0; i < this.munodelist.size(); i++) {
/* 281 */         MyNode nodei = (MyNode)this.munodelist.get(i);
/* 282 */         if (i % 2 == 0)
/* 283 */           nodei.setPosition(
/* 284 */             (int)(width / 3 * Math.random() + 
/* 284 */             i / 3 * width + 150.0D), 
/* 285 */             (int)(50.0D * Math.random() + i % 3 * 80) + 350);
/*     */         else
/* 287 */           nodei.setPosition(
/* 288 */             (int)(-width / 3 * Math.random() + 
/* 288 */             i / 3 * width + 150.0D), 
/* 289 */             (int)(50.0D * Math.random() + i % 3 * 80) + 350);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getDistance(MyNode node1, MyNode node2)
/*     */   {
/* 297 */     return (node1.getX() - node2.getX()) * (node1.getX() - node2.getX()) + 
/* 298 */       (node1
/* 298 */       .getY() - node2.getY()) * (
/* 299 */       node1.getY() - node2.getY());
/*     */   }
/*     */ 
/*     */   public MyNode find(Point2D point)
/*     */   {
/* 305 */     for (MyNode node : this.nodelist) {
/* 306 */       int x = node.getX();
/* 307 */       int y = node.getY();
/* 308 */       Ellipse2D e = new Ellipse2D.Double(x - 2.5D, y - 2.5D, 5.0D, 5.0D);
/* 309 */       if (e.contains(point)) {
/* 310 */         return node;
/*     */       }
/*     */     }
/* 313 */     for (MyNode node : this.munodelist) {
/* 314 */       int x = node.getX();
/* 315 */       int y = node.getY();
/* 316 */       Ellipse2D e = new Ellipse2D.Double(x - 2.5D, y - 2.5D, 5.0D, 5.0D);
/* 317 */       if (e.contains(point)) {
/* 318 */         return node;
/*     */       }
/*     */     }
/* 321 */     return null;
/*     */   }
/*     */   private class MouseHandler extends MouseAdapter {
/*     */     private MouseHandler() {
/*     */     }
/*     */     public void mousePressed(MouseEvent event) {
/* 327 */       TripletDiagramPanel.this.current = TripletDiagramPanel.this.find(event.getPoint());
/*     */     }
/*     */   }
/*     */ 
/*     */   private class MouseMotionHandler implements MouseMotionListener {
/*     */     private MouseMotionHandler() {
/*     */     }
/*     */ 
/* 335 */     public void mouseMoved(MouseEvent event) { if (TripletDiagramPanel.this.find(event.getPoint()) != null)
/* 336 */         TripletDiagramPanel.this.setCursor(Cursor.getPredefinedCursor(1));
/*     */       else
/* 338 */         TripletDiagramPanel.this.setCursor(Cursor.getPredefinedCursor(0));
/*     */     }
/*     */ 
/*     */     public void mouseDragged(MouseEvent event)
/*     */     {
/* 344 */       if (TripletDiagramPanel.this.current != null) {
/* 345 */         int x = event.getX();
/* 346 */         int y = event.getY();
/* 347 */         TripletDiagramPanel.this.current.setPosition(x, y);
/* 348 */         TripletDiagramPanel.this.repaint();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\妗��\SOD1 ���\ProCon-20121023.jar
 * Qualified Name:     source.view.TripletDiagramPanel
 * JD-Core Version:    0.6.2
 */