/*    */ package source.view;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.GridLayout;
/*    */ import javax.swing.JPanel;
/*    */ import source.model.MutualInformation;
/*    */ import source.model.ProbabilityCalculator;
/*    */ 
/*    */ public class MutualPanel extends JPanel
/*    */ {
/*    */   private ProbabilityCalculator pc;
/*    */   private MutualInformation mi;
/*    */   private CovariantDistributionPanel covariantDistributionPanel;
/*    */   private MutualFootPanel headpanel;
/*    */   private MutualListPanel listPanel;
/*    */   private MutualDiagramPanel diagramPanel;
/*    */   private MutualDetailPanel detailPanel;
/*    */   private TripletPanel tripletpanel;
/*    */   private StructurePanel structurepanel;
/*    */ 
/*    */   public MutualPanel(ProbabilityCalculator pc, CovariantDistributionPanel acovariantDistributionPanel, TripletPanel atripletpanel, StructurePanel astructurepanel)
/*    */   {
/* 16 */     this.pc = pc;
/* 17 */     this.covariantDistributionPanel = acovariantDistributionPanel;
/* 18 */     this.tripletpanel = atripletpanel;
/* 19 */     this.structurepanel = astructurepanel;
/*    */ 
/* 22 */     this.detailPanel = new MutualDetailPanel();
/* 23 */     this.diagramPanel = new MutualDiagramPanel(pc);
/* 24 */     this.listPanel = new MutualListPanel(pc, this.detailPanel, this.diagramPanel);
/* 25 */     this.headpanel = new MutualFootPanel(pc, this.listPanel, this.covariantDistributionPanel, this.tripletpanel, this.structurepanel);
/* 26 */     setLayout(new BorderLayout());
/*    */ 
/* 30 */     JPanel WestPanel = new JPanel();
/* 31 */     WestPanel.setLayout(new BorderLayout());
/* 32 */     WestPanel.add(this.headpanel, "North");
/* 33 */     WestPanel.add(this.listPanel, "Center");
/*    */ 
/* 35 */     add(WestPanel, "West");
/*    */ 
/* 37 */     JPanel panel = new JPanel();
/* 38 */     panel.setLayout(new GridLayout(2, 1, 3, 3));
/* 39 */     panel.add(this.diagramPanel);
/* 40 */     panel.add(this.detailPanel);
/*    */ 
/* 43 */     add(panel, "Center");
/*    */   }
/*    */ 
/*    */   public void resetPc(ProbabilityCalculator pc)
/*    */   {
/* 50 */     this.pc = pc;
/* 51 */     this.diagramPanel.resetPc(pc);
/* 52 */     this.headpanel.resetPc(pc);
/* 53 */     this.listPanel.resetPc(pc);
/*    */ 
/* 55 */     this.mi = new MutualInformation(pc, pc.getGapPercent(), 
/* 56 */       pc.getPValue1(), pc.getPValue2());
/*    */ 
/* 58 */     this.covariantDistributionPanel.setMutualInformation(this.mi);
/* 59 */     this.covariantDistributionPanel.resetPc(pc);
/*    */ 
/* 62 */     this.tripletpanel.initialPc(pc);
/* 63 */     this.tripletpanel.setMutualInformation(this.mi);
/*    */ 
/* 65 */     this.tripletpanel.resetPc(pc);
/*    */ 
/* 69 */     this.structurepanel.initialPc(pc);
/*    */ 
/* 71 */     this.structurepanel.setMutualInformation(this.mi);
/* 72 */     this.structurepanel.resetPc(pc);
/*    */ 
/* 76 */     this.listPanel.setMutualInformation(this.mi);
/* 77 */     this.listPanel.resetList();
/*    */   }
/*    */ 
/*    */   public void resetListPanel()
/*    */   {
/* 87 */     this.listPanel.resetList();
/* 88 */     this.headpanel.resetReference(this.pc.getReference());
/* 89 */     this.tripletpanel.resetTriplets();
/* 90 */     this.structurepanel.resetTriplets();
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.MutualPanel
 * JD-Core Version:    0.6.2
 */