/*     */ package source.view;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSeparator;
/*     */ import javax.swing.JTextField;
/*     */ import org.biojava.bio.structure.Structure;
/*     */ import org.biojava.bio.structure.io.PDBFileReader;
/*     */ import org.jmol.api.JmolSimpleViewer;
/*     */ import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class StructureDisplayPanel extends JPanel
/*     */ {
/*     */   private ProbabilityCalculator pc;
/*     */   private String savepdbpath;
/*     */   private JmolPanel jmolpanel;
/*     */   private JPanel headpanel;
/*     */   private JTextField pdbfield;
/*     */   private Structure structure;
/*     */   private JmolSimpleViewer viewer;
/*     */   private JLabel messagelabel;
/*     */ 
/*     */   public StructureDisplayPanel(ProbabilityCalculator pc)
/*     */   {
/*  33 */     this.pc = pc;
/*  34 */     this.jmolpanel = new JmolPanel();
/*  35 */     this.viewer = this.jmolpanel.getViewer();
/*  36 */     this.jmolpanel.setPreferredSize(new Dimension(300, 300));
/*     */ 
/*  38 */     this.headpanel = new JPanel();
/*     */ 
/*  40 */     this.messagelabel = new JLabel("please enter a PDB ID: ");
/*     */ 
/*  42 */     this.headpanel.add(this.messagelabel);
/*  43 */     this.pdbfield = new JTextField("", 4);
/*  44 */     this.headpanel.add(this.pdbfield);
/*  45 */     JButton okbutton = new JButton("download from PDB");
/*     */ 
/*  47 */     okbutton.addActionListener(new ActionListener()
/*     */     {
/*     */       public void setStructure(Structure s)
/*     */       {
/*  54 */         String pdb = s.toPDB();
/*     */ 
/*  56 */         StructureDisplayPanel.this.structure = s;
/*     */ 
/*  64 */         StructureDisplayPanel.this.viewer.openStringInline(pdb);
/*  65 */         StructureDisplayPanel.this.viewer.evalString("select *;");
/*     */       }
/*     */ 
/*     */       public boolean downLoadFile(String fileurl, String savepath)
/*     */       {
/*  84 */         File f = new File(savepath);
/*  85 */         if (f.exists()) {
/*  86 */           return true;
/*     */         }
/*     */         try
/*     */         {
/*  90 */           URL url = new URL(fileurl);
/*  91 */           URLConnection conn = url.openConnection();
/*  92 */           conn.connect();
/*  93 */           HttpURLConnection httpconn = (HttpURLConnection)conn;
/*  94 */           int httpStatusCode = httpconn.getResponseCode();
/*  95 */           if (httpStatusCode != 200)
/*     */           {
/*  98 */             System.out.println("connect   to   " + fileurl + 
/*  99 */               "   failed,return   code:" + httpStatusCode);
/* 100 */             return false;
/*     */           }
/* 102 */           int filelen = conn.getContentLength();
/* 103 */           InputStream is = conn.getInputStream();
/* 104 */           byte[] tmpbuf = new byte[1024];
/* 105 */           File savefile = new File(savepath);
/* 106 */           if (!savefile.exists())
/* 107 */             savefile.createNewFile();
/* 108 */           FileOutputStream fos = new FileOutputStream(savefile);
/* 109 */           int readnum = 0;
/* 110 */           if (filelen < 0)
/*     */           {
/* 114 */             while (readnum > -1) {
/* 115 */               readnum = is.read(tmpbuf);
/* 116 */               if (readnum > 0)
/* 117 */                 fos.write(tmpbuf, 0, readnum);
/*     */             }
/*     */           } else {
/* 120 */             int readcount = 0;
/* 121 */             while ((readcount < filelen) && (readnum != -1)) {
/* 122 */               readnum = is.read(tmpbuf);
/* 123 */               if (readnum > -1) {
/* 124 */                 fos.write(tmpbuf, 0, readcount);
/* 125 */                 readcount += readnum;
/*     */               }
/*     */             }
/* 128 */             if (readcount < filelen) {
/* 129 */               System.out.println("download   error");
/* 130 */               is.close();
/* 131 */               fos.close();
/* 132 */               savefile.delete();
/* 133 */               return false;
/*     */             }
/*     */           }
/* 136 */           fos.flush();
/* 137 */           fos.close();
/* 138 */           is.close();
/*     */         } catch (Exception e) {
/* 140 */           e.printStackTrace();
/* 141 */           return false;
/*     */         }
/* 143 */         return true;
/*     */       }
/*     */ 
/*     */       public void actionPerformed(ActionEvent event)
/*     */       {
/* 148 */         StructureDisplayPanel.this.messagelabel.setText("downloading...   ");
/* 149 */         StructureDisplayPanel.this.messagelabel.repaint();
/*     */ 
/* 151 */         String pdbid = StructureDisplayPanel.this.pdbfield.getText();
/*     */ 
/* 153 */         String fileurl = "http://www.rcsb.org/pdb/download/downloadFile.do?fileFormat=pdb&compression=NO&structureId=" + 
/* 154 */           pdbid;
/* 155 */         File directory = new File("..");
/* 156 */         StructureDisplayPanel.this.savepdbpath = new String();
/*     */         try {
/* 158 */           if (System.getProperty("os.name").substring(0, 7).equals("Windows"))
/* 159 */             StructureDisplayPanel.this.savepdbpath = 
/* 160 */               (directory.getCanonicalPath() + "\\PDB\\" + pdbid + 
/* 160 */               ".pdb");
/*     */           else
/* 162 */             StructureDisplayPanel.this.savepdbpath = 
/* 163 */               (directory.getCanonicalPath() + "/PDB/" + pdbid + 
/* 163 */               ".pdb");
/*     */         } catch (IOException e) {
/* 165 */           e.printStackTrace();
/*     */         }
/*     */ 
/* 168 */         if (downLoadFile(fileurl, StructureDisplayPanel.this.savepdbpath)) {
/* 169 */           System.out.println("checkPDB()= " + StructureDisplayPanel.this.checkPDB());
/* 170 */           if (StructureDisplayPanel.this.checkPDB() < 0) {
/* 171 */             JOptionPane.showMessageDialog(StructureDisplayPanel.this, 
/* 172 */               "Warning! Your chosen structure does not contain the reference sequence!\n You should enter a new PDB id. Click to continue:");
/*     */ 
/* 174 */             StructureDisplayPanel.this.pdbfield.setText("");
/*     */           }
/*     */ 
/*     */           try
/*     */           {
/* 179 */             PDBFileReader pdbr = new PDBFileReader();
/*     */ 
/* 181 */             if (System.getProperty("os.name").substring(0, 7).equals("Windows")) {
/* 182 */               pdbr.setPath(directory.getCanonicalPath() + "//PDB//");
/*     */             }
/*     */             else {
/* 185 */               pdbr.setPath(directory.getCanonicalPath() + "/PDB/");
/*     */             }
/* 187 */             Structure struc = pdbr.getStructureById(pdbid);
/*     */ 
/* 189 */             setStructure(struc);
/*     */ 
/* 191 */             StructureDisplayPanel.this.pdbfield.setText("");
/* 192 */             StructureDisplayPanel.this.pdbfield.repaint();
/*     */ 
/* 194 */             StructureDisplayPanel.this.messagelabel.setText("PDB structure shown is: " + pdbid + 
/* 195 */               ";  you may enter a new PDB id:");
/* 196 */             StructureDisplayPanel.this.messagelabel.repaint();
/*     */           }
/*     */           catch (Exception e) {
/* 199 */             StructureDisplayPanel.this.messagelabel.setText("download error!   please enter a new PDB id:");
/*     */ 
/* 201 */             StructureDisplayPanel.this.messagelabel.repaint();
/* 202 */             e.printStackTrace();
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 207 */           StructureDisplayPanel.this.pdbfield.setText("");
/* 208 */           StructureDisplayPanel.this.pdbfield.repaint();
/* 209 */           StructureDisplayPanel.this.messagelabel.setText("download error!   please enter a new PDB id:");
/*     */ 
/* 211 */           StructureDisplayPanel.this.messagelabel.repaint();
/*     */         }
/*     */       }
/*     */     });
/* 218 */     this.headpanel.add(okbutton);
/* 219 */     setLayout(new BorderLayout());
/* 220 */     add(this.headpanel, "North");
/* 221 */     add(this.jmolpanel, "Center");
/*     */ 
/* 223 */     JSeparator s = new JSeparator(0);
/* 224 */     Dimension ps = s.getPreferredSize();
/* 225 */     s.setPreferredSize(new Dimension(ps.width, 20));
/* 226 */     add(s, "South");
/*     */ 
/* 228 */     JSeparator s2 = new JSeparator(1);
/* 229 */     Dimension ps2 = s2.getPreferredSize();
/* 230 */     s2.setPreferredSize(new Dimension(30, ps2.height));
/* 231 */     add(s2, "West");
/*     */ 
/* 233 */     JSeparator s3 = new JSeparator(1);
/* 234 */     Dimension ps3 = s3.getPreferredSize();
/* 235 */     s3.setPreferredSize(new Dimension(10, ps3.height));
/* 236 */     add(s3, "East");
/*     */   }
/*     */ 
/*     */   public void displayMutual(String site1, String site2)
/*     */   {
/* 243 */     if ((checkSite(site1)) && (checkSite(site2)))
/*     */     {
/* 246 */       this.viewer
/* 247 */         .evalString(" select *; color black;  label off; monitor off; spacefill off; select *A; backbone on; color backbone blue;  select *.ca and " + 
/* 250 */         site1 + 
/* 251 */         ":A; spacefill 200; color atoms red; label %r%m; color label green;set fontsize 6;" + 
/* 252 */         " select *.ca and " + 
/* 253 */         site2 + 
/* 254 */         ":A; spacefill 200; color atoms red; label %r%m; color label green;set fontsize 6;" + 
/* 255 */         " center (*.ca and " + 
/* 256 */         site1 + 
/* 257 */         ":A), (*.ca and " + 
/* 258 */         site2 + 
/* 259 */         ":A);  " + 
/* 260 */         " set measures Angstroms; font measures 10.0 SansSerif Plain; spin on;" + 
/* 261 */         " measure (*.ca and " + 
/* 262 */         site1 + 
/* 263 */         ":A) (*.ca and " + 
/* 264 */         site2 + ":A);");
/*     */     }
/*     */     else
/*     */     {
/* 271 */       JOptionPane.showMessageDialog(this, 
/* 272 */         "Your chosen structure does not contain the mutual sites!");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void dispalyTriplet(String site1, String site2, String site3)
/*     */   {
/* 280 */     System.out.println("site1 = " + site1 + "; site2 = " + site2 + 
/* 281 */       "; site3 = " + site3);
/* 282 */     if ((checkSite(site1)) && (checkSite(site2)) && (checkSite(site3))) {
/* 283 */       this.viewer
/* 284 */         .evalString("select *; color black; label off; monitor off; spacefill off;  select *A; backbone on; color backbone blue; select *.ca and " + 
/* 287 */         site1 + 
/* 288 */         "A; spacefill 200; color atoms red; label %r%m; color label green;set fontsize 6;" + 
/* 289 */         " select *.ca and " + 
/* 290 */         site2 + 
/* 291 */         "A; spacefill 200; color atoms red; label %r%m; color label green;set fontsize 6;" + 
/* 292 */         " select *.ca and " + 
/* 293 */         site3 + 
/* 294 */         "A; spacefill 200; color atoms red; label %r%m; color label green;set fontsize 6;" + 
/* 295 */         " center (*.ca and " + 
/* 296 */         site1 + 
/* 297 */         ":A),(*.ca and " + 
/* 298 */         site2 + 
/* 299 */         ":A), (*.ca and " + 
/* 300 */         site3 + 
/* 301 */         ":A);" + 
/* 303 */         " set measures Angstroms;  font measures 10.0 SansSerif Plain; spin on;" + 
/* 304 */         " measure (*.ca and " + 
/* 305 */         site1 + 
/* 306 */         ":A) (*.ca and " + 
/* 307 */         site2 + 
/* 308 */         ":A); " + 
/* 309 */         " measure (*.ca and " + 
/* 310 */         site2 + 
/* 311 */         ":A) (*.ca and " + 
/* 312 */         site3 + 
/* 313 */         ":A); " + 
/* 314 */         " measure (*.ca and " + 
/* 315 */         site3 + 
/* 316 */         ":A) (*.ca and " + 
/* 317 */         site1 + ":A); ");
/*     */     }
/*     */     else
/*     */     {
/* 323 */       JOptionPane.showMessageDialog(this, 
/* 324 */         "Your chosen structure does not contain the triplet sites!");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void resetPc(ProbabilityCalculator pc) {
/* 329 */     this.pc = pc;
/* 330 */     this.viewer.evalString("");
/*     */   }
/*     */ 
/*     */   public int checkPDB()
/*     */   {
/* 335 */     String referencesequence = this.pc.getReferenceSequence();
/* 336 */     String pdbsequence = new String();
/*     */     try
/*     */     {
/* 339 */       BufferedReader reader = new BufferedReader(new FileReader(this.savepdbpath));
/* 340 */       String line = new String();
/*     */ 
/* 343 */       while ((line = reader.readLine()) != null)
/*     */       {
/* 345 */         if (line.substring(0, 6).equals("SEQRES"))
/*     */         {
/* 347 */           for (int j = 0; j < (line.length() - 18) / 4; j++)
/*     */           {
/* 349 */             for (int i = 0; i < 20; i++)
/*     */             {
/* 351 */               if (ProbabilityCalculator.TRI_RESIDUE[i].equals(line.substring(19 + j * 4, 19 + j * 4 + 3)))
/*     */               {
/* 353 */                 pdbsequence = pdbsequence + Character.toString(ProbabilityCalculator.RESIDUE[i]);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 361 */       System.out.println("pdbsequence = " + pdbsequence);
/* 362 */       System.out.println("referencesequence = " + referencesequence);
/* 363 */       if (pdbsequence.length() < referencesequence.length()) return -1;
/*     */ 
/* 365 */       for (int i = 0; i < pdbsequence.length() - referencesequence.length(); i++) {
/* 366 */         if (pdbsequence.substring(i, i + referencesequence.length()).equals(referencesequence)) return i;
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*     */     }
/*     */ 
/* 377 */     return -2;
/*     */   }
/*     */ 
/*     */   public boolean checkSite(String site)
/*     */   {
/* 382 */     String referencesequence = this.pc.getReferenceSequence();
/*     */     try {
/* 384 */       BufferedReader reader = new BufferedReader(new FileReader(this.savepdbpath));
/* 385 */       System.out.println("savepdbpath" + this.savepdbpath);
/* 386 */       String line = new String();
/*     */ 
/* 388 */       int s = Integer.parseInt(site);
/* 389 */       int t = getNumberofInt(s);
/*     */ 
/* 391 */       String residue = "";
/*     */ 
/* 393 */       while (((line = reader.readLine()) != null) && (residue.equals("")))
/*     */       {
/* 395 */         if ((line.substring(0, 4).equals("ATOM")) && (line.substring(13, 15).equals("CA")))
/*     */         {
/* 398 */           if (line.substring(26 - t, 26).equals(site))
/*     */           {
/* 400 */             System.out.println("!!!line.substring(26-t,26) = " + line.substring(26 - t, 26));
/* 401 */             for (int i = 0; i < 20; i++)
/*     */             {
/* 403 */               if (line.substring(17, 20).equals(ProbabilityCalculator.TRI_RESIDUE[i]))
/*     */               {
/* 405 */                 residue = Character.toString(ProbabilityCalculator.RESIDUE[i]);
/* 406 */                 break;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 414 */       if (residue.equals(referencesequence.substring(s - this.pc.getReferenceStart(), s - this.pc.getReferenceStart() + 1)))
/* 415 */         return true;
/*     */     }
/*     */     catch (Exception e) {
/* 418 */       System.out.println(e);
/*     */     }
/* 420 */     return false;
/*     */   }
/*     */ 
/*     */   private int getNumberofInt(int num)
/*     */   { int i =0, temp;
/* 427 */     for (; 
/* 428 */       num != 0; i++) {
/* 429 */       temp = num % 10;
/* 430 */       num /= 10;
/* 431 */       System.out.print(temp + " , ");
/*     */     }
/* 433 */     return i;
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\妗��\SOD1 ���\ProCon-20121023.jar
 * Qualified Name:     source.view.StructureDisplayPanel
 * JD-Core Version:    0.6.2
 */