/*     */ package source.view;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.GridLayout;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class DisplayPanel extends JPanel
/*     */ {
/*     */   private String step;
/*     */   private ProbabilityCalculator pc;
/*     */   private SequencePanel sequencePanel;
/*     */   private EntropyPanel entropyPanel;
/*     */   private EntropyStatisticsPanel entropyStatisticsPanel;
/*     */   private DistributionPanel distributionPanel;
/*     */   private MutualPanel mutualPanel;
/*     */   private TripletPanel tripletPanel;
/*     */   private StructurePanel structurePanel;
/*     */   private CovariantDistributionPanel covariantDistributionPanel;
/*     */   private InfoPanel infoPanel;
/*     */   private JPanel aboutpanel;
/*     */ 
/*     */   public DisplayPanel(ProbabilityCalculator pc)
/*     */   {
/*  33 */     super(new GridLayout(1, 1));
/*  34 */     this.pc = pc;
/*     */ 
/*  36 */     final JTabbedPane tabbedPane = new JTabbedPane();
/*     */ 
/*  39 */     this.entropyPanel = new EntropyPanel(pc);
/*  40 */     this.entropyStatisticsPanel = new EntropyStatisticsPanel(pc);
/*  41 */     this.distributionPanel = new DistributionPanel(pc);
/*     */ 
/*  43 */     this.tripletPanel = new TripletPanel(pc);
/*  44 */     this.structurePanel = new StructurePanel(pc);
/*  45 */     this.covariantDistributionPanel = new CovariantDistributionPanel(pc);
/*     */ 
/*  47 */     this.mutualPanel = new MutualPanel(pc, this.covariantDistributionPanel, 
/*  48 */       this.tripletPanel, this.structurePanel);
/*     */ 
/*  50 */     this.sequencePanel = new SequencePanel(this.mutualPanel, pc);
/*     */ 
/*  52 */     this.aboutpanel = new JPanel();
/*     */ 
/*  54 */     this.infoPanel = new InfoPanel();
/*  55 */     this.aboutpanel.setLayout(new BorderLayout());
/*  56 */     this.aboutpanel.add(this.infoPanel, "Center");
/*     */ 
/*  58 */     this.infoPanel.setOpaque(false);
/*     */ 
/*  61 */     tabbedPane.addTab("alignment", null, this.sequencePanel, "");
/*     */ 
/*  63 */     tabbedPane.addTab("information content", null, this.entropyPanel, "");
/*     */ 
/*  65 */     tabbedPane.addTab("information statistics", null, this.entropyStatisticsPanel, 
/*  66 */       "");
/*     */ 
/*  68 */     tabbedPane.addTab("aa distribution", null, this.distributionPanel, "");
/*     */ 
/*  70 */     tabbedPane.addTab("covariant aas", null, this.mutualPanel, "");
/*     */ 
/*  72 */     tabbedPane.addTab("covariance distribution", null, 
/*  73 */       this.covariantDistributionPanel, "");
/*     */ 
/*  75 */     tabbedPane.addTab("triplets", null, this.tripletPanel, "");
/*     */ 
/* 107 */     tabbedPane.addTab("structure", null, this.structurePanel, "");
/* 108 */     tabbedPane.setMnemonicAt(4, 53);
/*     */ 
/* 110 */     tabbedPane.addTab("about", null, this.aboutpanel, "");
/* 111 */     this.infoPanel.repaint();
/*     */ 
/* 113 */     add(tabbedPane);
/*     */ 
/* 116 */     tabbedPane.setTabLayoutPolicy(1);
/*     */ 
/* 120 */     tabbedPane.addChangeListener(new ChangeListener()
/*     */     {
/*     */       public void stateChanged(ChangeEvent e)
/*     */       {
/* 124 */         int i = tabbedPane.getSelectedIndex();
/*     */ 
/* 126 */         if (i == 0)
/* 127 */           DisplayPanel.this.sequencePanel.repaint();
/* 128 */         if (i == 1)
/* 129 */           DisplayPanel.this.entropyPanel.repaint();
/* 130 */         if (i == 2)
/* 131 */           DisplayPanel.this.entropyStatisticsPanel.repaint();
/* 132 */         if (i == 3)
/* 133 */           DisplayPanel.this.distributionPanel.repaint();
/* 134 */         if (i == 4)
/* 135 */           DisplayPanel.this.mutualPanel.repaint();
/* 136 */         tabbedPane.revalidate();
/* 137 */         tabbedPane.repaint();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   protected JComponent makeTextPanel(String text)
/*     */   {
/* 144 */     JPanel panel = new JPanel(false);
/* 145 */     JLabel filler = new JLabel(text);
/* 146 */     filler.setHorizontalAlignment(0);
/* 147 */     panel.setLayout(new GridLayout(1, 1));
/* 148 */     panel.add(filler);
/* 149 */     return panel;
/*     */   }
/*     */ 
/*     */   protected static ImageIcon createImageIcon(String path)
/*     */   {
/* 172 */     URL imgURL = DisplayPanel.class.getResource(path);
/* 173 */     if (imgURL != null) {
/* 174 */       return new ImageIcon(imgURL);
/*     */     }
/* 176 */     System.err.println("Couldn't find file: " + path);
/* 177 */     return null;
/*     */   }
/*     */ 
/*     */   public void paintComponent(Graphics g)
/*     */   {
/* 183 */     if ((this.step == null) || (this.step.isEmpty())) {
/* 184 */       g.drawString("Please input the FASTA file first", 100, 100);
/*     */     }
/*     */ 
/* 197 */     updateUI();
/*     */   }
/*     */ 
/*     */   public void resetPc(ProbabilityCalculator pc) {
/* 201 */     this.pc = pc;
/* 202 */     System.out.println("New pc! pc.getResNumber() = " + pc.getResNumber());
/*     */ 
/* 208 */     this.sequencePanel.resetPc(pc);
/* 209 */     this.entropyPanel.resetPc(pc);
/* 210 */     this.entropyStatisticsPanel.resetPc(pc);
/* 211 */     this.distributionPanel.resetPc(pc);
/* 212 */     this.mutualPanel.resetPc(pc);
/* 213 */     this.covariantDistributionPanel.resetPc(pc);
/*     */   }
/*     */ 
/*     */   public void setStep(String step)
/*     */   {
/* 220 */     this.step = step;
/*     */   }
/*     */ }

