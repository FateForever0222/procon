/*    */ package source.view;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.io.PrintStream;
/*    */ import javax.swing.AbstractAction;
/*    */ 
/*    */ class TestAction extends AbstractAction
/*    */ {
/*    */   TestAction(String name)
/*    */   {
/* 12 */     super(name);
/*    */   }
/*    */ 
/*    */   public void actionPerformed(ActionEvent event) {
/* 16 */     System.out.println(getValue("Name") + "selected");
/*    */   }
/*    */ }

/* Location:           C:\Documents and Settings\yyang\桌面\SOD1 分析\ProCon-20121023.jar
 * Qualified Name:     source.view.TestAction
 * JD-Core Version:    0.6.2
 */