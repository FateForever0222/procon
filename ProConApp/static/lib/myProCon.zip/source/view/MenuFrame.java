/*     */ package source.view;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Container;
/*     */ import java.awt.Image;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.KeyStroke;
/*     */ import source.model.ProbabilityCalculator;
/*     */ 
/*     */ public class MenuFrame extends JFrame
/*     */ {
/*     */   private String nameOfFASTAFile;
/*     */   private Container container;
/*     */   private JLabel label;
/*     */   private JFileChooser chooser;
/*     */   private GapPercentChooser gappercentchooser;
/*     */   private PvalueChooser pvaluechooser;
/*     */   private GroupChooser groupchooser;
/*     */   private JPanel panel;
/*     */   private ButtonGroup stepGroup;
/*     */   private DisplayPanel displayPanel;
/*     */   private DistributionDiagramPanel distributionPanel;
/*     */   private ProbabilityCalculator pc;
/*     */   private static final int DEFAULT_WIDTH = 1100;
/*     */   private static final int DEFAULT_HEIGHT = 800;
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public MenuFrame()
/*     */   {
/*  30 */     setTitle("ProCon - Protein Conservation");
/*  31 */     setSize(1100, 800);
/*     */ 
/*  36 */     File directory = new File("..");
/*  37 */     Toolkit kit = Toolkit.getDefaultToolkit();
/*     */     try
/*     */     {
/*  40 */       Image image = kit.getImage(directory.getCanonicalPath() + "/bin/procon_logo.gif ");
/*  41 */       setIconImage(image);
/*     */     }
/*     */     catch (IOException e) {
/*  44 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  48 */     setResizable(false);
/*     */ 
/*  54 */     JMenuBar menubar = new JMenuBar();
/*  55 */     setJMenuBar(menubar);
/*     */ 
/*  57 */     JMenu fileMenu = new JMenu("file");
/*  58 */     menubar.add(fileMenu);
/*     */ 
/*  63 */     JMenuItem openItem = new JMenuItem("open a FASTA file");
/*  64 */     fileMenu.add(openItem);
/*  65 */     openItem.addActionListener(new FileOpenListener());
/*     */ 
/*  67 */     openItem.setAccelerator(KeyStroke.getKeyStroke(79, 
/*  68 */       2));
/*  69 */     fileMenu.addSeparator();
/*     */ 
/*  71 */     JMenuItem exitItem = new JMenuItem("exit");
/*  72 */     fileMenu.add(exitItem);
/*     */ 
/*  74 */     exitItem.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent event) {
/*  76 */         System.exit(0);
/*     */       }
/*     */     });
/*  80 */     this.chooser = new JFileChooser();
/*     */ 
/*  85 */     JMenu setMenu = new JMenu("settings");
/*  86 */     menubar.add(setMenu);
/*     */ 
/*  88 */     JMenuItem gapPercentItem = new JMenuItem("gap percentage");
/*  89 */     setMenu.add(gapPercentItem);
/*  90 */     gapPercentItem.addActionListener(new GapPercentchooserSetListener());
/*     */ 
/*  92 */     JMenuItem pvalueItem = new JMenuItem("p value");
/*  93 */     setMenu.add(pvalueItem);
/*  94 */     pvalueItem.addActionListener(new PvaluechooserSetListener());
/*     */ 
/*  96 */     JMenuItem groupItem = new JMenuItem("aa group");
/*  97 */     setMenu.add(groupItem);
/*  98 */     groupItem.addActionListener(new GroupSetListener());
/*     */ 
/* 104 */     this.panel = new JPanel();
/* 105 */     setPanel();
/* 106 */     add(this.panel);
/*     */ 
/* 110 */     this.pc = new ProbabilityCalculator();
/*     */ 
/* 112 */     this.displayPanel = new DisplayPanel(this.pc);
/* 113 */     this.panel.add(this.displayPanel, "Center");
/*     */ 
/* 115 */     this.label = new JLabel(
/* 116 */       "Welcom to ProCon, Please choose a FASTA input file.");
/* 117 */     this.panel.add(this.label, "South");
/*     */   }
/*     */ 
/*     */   private void setPanel()
/*     */   {
/* 287 */     this.panel.setLayout(new BorderLayout());
/*     */   }
/*     */ 
/*     */   private class FileOpenListener
/*     */     implements ActionListener
/*     */   {
/*     */     private FileOpenListener()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent event)
/*     */     {
/* 131 */       File directory = new File("..");
/*     */       try {
/* 133 */         if (System.getProperty("os.name").substring(0, 7).equals("Windows"))
/* 134 */           MenuFrame.this.chooser.setCurrentDirectory(new File(directory
/* 136 */             .getCanonicalPath() + 
/* 137 */             "\\examples"));
/*     */         else
/* 139 */           MenuFrame.this.chooser.setCurrentDirectory(new File(directory
/* 140 */             .getCanonicalPath() + 
/* 141 */             "/examples"));
/*     */       } catch (IOException e) {
/* 143 */         e.printStackTrace();
/*     */       }
/* 145 */       int result = MenuFrame.this.chooser.showOpenDialog(MenuFrame.this);
/*     */ 
/* 147 */       if (result == 0) {
/* 148 */         MenuFrame.this.nameOfFASTAFile = MenuFrame.this.chooser.getSelectedFile().getPath();
/* 149 */         System.out.println(MenuFrame.this.nameOfFASTAFile);
/*     */         try
/*     */         {
/* 152 */           MenuFrame.this.pc = new ProbabilityCalculator(MenuFrame.this.nameOfFASTAFile);
/*     */ 
/* 155 */           if (!MenuFrame.this.pc.getAvailable())
/*     */           {
/* 157 */             JOptionPane.showMessageDialog(
/* 158 */               MenuFrame.this, 
/* 159 */               "The file input is illegal, Please check the FASTA format: \n Please use \">\" to seperate the sequence, \"-\" or \".\" to denote gap");
/*     */           }
/*     */           else {
/* 162 */             MenuFrame.this.displayPanel.resetPc(MenuFrame.this.pc);
/*     */ 
/* 164 */             String textString = new String();
/* 165 */             textString = " The FASTA file in processing is " + 
/* 166 */               MenuFrame.this.nameOfFASTAFile + "; \n sequence number = " + 
/* 167 */               MenuFrame.this.pc.getSeqNumber() + "; residues number = " + 
/* 168 */               MenuFrame.this.pc.getResNumber() + "; gap percentage = " + 
/* 169 */               MenuFrame.this.pc.getGapPercent() * 100.0D + "%";
/* 170 */             JOptionPane.showMessageDialog(MenuFrame.this, textString);
/* 171 */             MenuFrame.this.label.setText(textString);
/* 172 */             MenuFrame.this.panel.repaint();
/*     */           }
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 177 */           JOptionPane.showMessageDialog(
/* 178 */             MenuFrame.this, 
/* 179 */             "some exception found, please check your input sequences:\n 1. current version handles only no more than 4000 sequences; \n 2. the default gap percentage value is 10%, you can change it in \"Settings\".");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class GapPercentchooserSetListener
/*     */     implements ActionListener
/*     */   {
/*     */     private GapPercentchooserSetListener()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent arg0)
/*     */     {
/* 199 */       if (MenuFrame.this.pc.getSeqNumber() != 0) {
/* 200 */         MenuFrame.this.gappercentchooser = new GapPercentChooser(MenuFrame.this.pc);
/* 201 */         if (MenuFrame.this.gappercentchooser.showDialog(MenuFrame.this, 
/* 202 */           "gap percentage setting"))
/*     */         {
/* 204 */           MenuFrame.this.pc.setGapPercent(MenuFrame.this.gappercentchooser.getGapPercent());
/*     */ 
/* 206 */           MenuFrame.this.displayPanel.resetPc(MenuFrame.this.pc);
/*     */ 
/* 208 */           String textString = new String();
/* 209 */           textString = " The FASTA file in processing is " + 
/* 210 */             MenuFrame.this.nameOfFASTAFile + "; \n sequence number = " + 
/* 211 */             MenuFrame.this.pc.getSeqNumber() + "; residues number = " + 
/* 212 */             MenuFrame.this.pc.getResNumber() + "; gap percentage = " + 
/* 213 */             MenuFrame.this.pc.getGapPercent() * 100.0D + "%";
/* 214 */           JOptionPane.showMessageDialog(MenuFrame.this, 
/* 215 */             "New gap percentage = " + MenuFrame.this.pc.getGapPercent() * 100.0D + "%");
/* 216 */           MenuFrame.this.label.setText(textString);
/* 217 */           MenuFrame.this.panel.repaint();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class GroupSetListener
/*     */     implements ActionListener
/*     */   {
/*     */     private GroupSetListener()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent arg0)
/*     */     {
/* 263 */       if (MenuFrame.this.pc.getSeqNumber() != 0) {
/* 264 */         MenuFrame.this.groupchooser = new GroupChooser(MenuFrame.this.pc);
/*     */ 
/* 266 */         if (MenuFrame.this.groupchooser.showDialog(MenuFrame.this, "aa group setting")) {
/* 267 */           MenuFrame.this.pc.reCalculate();
/* 268 */           MenuFrame.this.displayPanel.resetPc(MenuFrame.this.pc);
/* 269 */           JOptionPane.showMessageDialog(MenuFrame.this, 
/* 270 */             "Calculation is done according to the new amino acid group setting.");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class PvaluechooserSetListener
/*     */     implements ActionListener
/*     */   {
/*     */     private PvaluechooserSetListener()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent arg0)
/*     */     {
/* 234 */       if (MenuFrame.this.pc.getSeqNumber() != 0) {
/* 235 */         MenuFrame.this.pvaluechooser = new PvalueChooser(MenuFrame.this.pc);
/*     */ 
/* 237 */         if (MenuFrame.this.pvaluechooser.showDialog(MenuFrame.this, "p value setting")) {
/* 238 */           MenuFrame.this.pc.setPValue1(MenuFrame.this.pvaluechooser.getPvalue1());
/* 239 */           MenuFrame.this.pc.setPValue2(MenuFrame.this.pvaluechooser.getPvalue2());
/*     */ 
/* 241 */           MenuFrame.this.displayPanel.resetPc(MenuFrame.this.pc);
/*     */ 
/* 243 */           JOptionPane.showMessageDialog(MenuFrame.this, "New p value1 = " + 
/* 244 */             MenuFrame.this.pc.getPValue1() + " p value2 = " + MenuFrame.this.pc.getPValue2());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Documents and Settings\yyang\妗��\SOD1 ���\ProCon-20121023.jar
 * Qualified Name:     source.view.MenuFrame
 * JD-Core Version:    0.6.2
 */