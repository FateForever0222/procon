/*    */ package source.controller;
/*    */ 
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ import source.view.MenuFrame;
/*    */ 
/*    */ public class MenuController
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 31 */     if (timeCompare(getCurrentTime(), "2020-06-01 00:00:00") < 0)
/*    */     {
/* 33 */       MenuFrame proCon = new MenuFrame();
/* 34 */       proCon.setDefaultCloseOperation(3);
/* 35 */       proCon.setVisible(true);
/*    */     }
/*    */   }
/*    */ 
/*    */   public static String getCurrentTime()
/*    */   {
/* 41 */     Date currentTime = new Date();
/* 42 */     SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 43 */     String dateString = formatter.format(currentTime);
/* 44 */     return dateString;
/*    */   }
/*    */ 
/*    */   public static int timeCompare(String t1, String t2) {
/* 48 */     SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 49 */     Calendar c1 = Calendar.getInstance();
/* 50 */     Calendar c2 = Calendar.getInstance();
/*    */     try {
/* 52 */       c1.setTime(formatter.parse(t1));
/* 53 */       c2.setTime(formatter.parse(t2));
/*    */     } catch (ParseException e) {
/* 55 */       e.printStackTrace();
/*    */     }
/* 57 */     int result = c1.compareTo(c2);
/* 58 */     return result;
/*    */   }
/*    */ }

