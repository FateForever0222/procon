/*    */ package source.controller;
/*    */ 
/*    */ import java.awt.Cursor;
/*    */ import java.awt.Desktop;
/*    */ import java.awt.Desktop.Action;
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ import javax.swing.JLabel;
/*    */ 
/*    */ public class RunBrowser
/*    */ {
/*    */   private Desktop desktop;
/*    */   private URI uri;
/*    */   private String netSite;
/*    */   private Cursor hander;
/*    */ 
/*    */   public RunBrowser()
/*    */   {
/* 26 */     this.desktop = Desktop.getDesktop();
/*    */   }
/*    */ 
/*    */   public boolean checkBroswer()
/*    */   {
/* 33 */     if ((Desktop.isDesktopSupported()) && 
/* 34 */       (this.desktop.isSupported(Desktop.Action.BROWSE))) {
/* 35 */       return true;
/*    */     }
/* 37 */     return false;
/*    */   }
/*    */ 
/*    */   public void runBroswer(String netsite)
/*    */   {
/* 45 */     this.netSite = netsite;
/*    */     try {
/* 47 */       this.uri = new URI(this.netSite);
/*    */     } catch (URISyntaxException ex) {
/* 49 */       ex.printStackTrace();
/*    */     }
/*    */     try {
/* 52 */       this.desktop.browse(this.uri);
/*    */     } catch (IOException ex) {
/* 54 */       ex.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public void changeMouse(JLabel label)
/*    */   {
/* 62 */     this.hander = new Cursor(12);
/* 63 */     label.setCursor(this.hander);
/*    */   }
/*    */ }

